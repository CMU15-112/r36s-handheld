import inspect
import os
import time

from cmu_graphics import shape_logic
from cmu_graphics.dist import VENDORED
from cmu_graphics import mvc_checker
from cmu_graphics.shape_logic import TRANSLATED_KEY_NAMES, _ShapeMetaclass


class Signal:
    def __init__(self):
        self.receivers = []

    def connect(self, receiver):
        self.receivers.append(receiver)

    def send_robust(self, *args, **kwargs):
        for receiver in self.receivers:
            try:
                receiver(*args, **kwargs)
            except Exception:
                print('\nAn error occurred in a signal receiver')
                import traceback

                traceback.print_exc()


onStepEvent = Signal()
onMainLoopEvent = Signal()

EPSILON = 10e-7


def almostEqual(x, y, epsilon=EPSILON):
    return abs(x - y) <= epsilon


def rounded(d):
    sign = 1 if (d >= 0) else -1
    d = abs(d)
    n = int(d)
    if d - n >= 0.5:
        n += 1
    return sign * n


def round(*args):
    raise Exception(
        t(
            "Use our rounded(n) instead of Python 3's round(n)\n  Python 3's round(n) does not work as one might expect!\n  If you still want Python 3's round, use pythonRound"
        )
    )


def dsin(angle):
    return math.sin(math.radians(angle))


def dcos(angle):
    return math.cos(math.radians(angle))


def setLanguage(language):
    sli.setLanguage(language)


_print = print


def print(*args, **kwargs):
    return _print(*args, **kwargs)


def Robot(*args, **kwargs):
    raise NotImplementedError()


def assertEqual(*args, **kwargs):
    raise NotImplementedError()


class Shape(object, metaclass=_ShapeMetaclass):
    # This represents the attributes and methods handled by JS that the user
    # can call/get/set
    _js_attrs = {
        'left',
        'right',
        'top',
        'bottom',
        'centerX',
        'centerY',
        'width',
        'height',
        'fill',
        'opacity',
        'border',
        'borderWidth',
        'dashes',
        'align',
        'rotateAngle',
        'visible',
        'group',  # Not sure if this should be documented?
        'toBack',
        'toFront',
        'contains',
        'hits',
        'containsShape',
        'hitsShape',
        'rotate',
    }

    # This represents the valid keyword arguments passed to the constructor
    _init_attrs = {
        'fill',
        'border',
        'borderWidth',
        'opacity',
        'rotateAngle',
        'dashes',
        'align',
        'visible',
        'db',
    }

    def __init__(self, clsName, argNames, args, kwargs):
        if app is not None and app._app._isMvc:
            shapeName = self.__class__.__name__
            raise NotImplementedError(
                f'Whoops! {shapeName} objects are not available in CPCS Mode. Did you want draw{shapeName}?'
            )

        global SHAPES_CREATED
        SHAPES_CREATED += 1

        isMvc = False
        if 'isMvc' in kwargs:
            isMvc = kwargs['isMvc']
            del kwargs['isMvc']

        for attr in list(kwargs.keys()):
            en_attr = toEnglish(attr, 'shape-attr')
            if attr != en_attr and en_attr is not None:
                kwargs[en_attr] = kwargs[attr]
                del kwargs[attr]

            if en_attr not in self._init_attrs:
                raise Exception(
                    t(
                        "{{error}}: {{callSpec}} got an unexpected keyword argument '{{arg}}'",
                        {
                            'error': t('TypeError'),
                            'callSpec': t(clsName) + '()',
                            'arg': attr,
                        },
                    )
                )

        self._shape = slInitShape(clsName, argNames, args, kwargs, isMvc)
        self._shape.studentShape = self

    def __setattr__(self, attr, val):
        if attr[0] == '_':
            self.__dict__[attr] = val
        else:
            en_attr = toEnglish(attr, 'shape-attr')
            if en_attr in self._js_attrs:
                sli.slSetWithTypeCheck(self._shape, en_attr, val)
            else:
                self.__dict__[attr] = val
        return val

    def __getattr__(self, attr):
        if attr[0] == '_':
            return self.__dict__[attr]

        en_attr = toEnglish(attr, 'shape-attr')
        if en_attr in self._js_attrs:
            return slGet(self._shape, en_attr)
        else:
            return self.__dict__[attr]

    def __repr__(self):
        return self._shape._toString()


class Rect(Shape):
    def __init__(self, *args, **kwargs):
        super().__init__('Rect', ['left', 'top', 'width', 'height'], args, kwargs)


class Image(Shape):
    _js_attrs = Shape._js_attrs | {'url'}
    _init_attrs = Shape._init_attrs | {'height', 'width'}

    def __init__(self, *args, **kwargs):
        super().__init__('Image', ['url', 'left', 'top'], args, kwargs)


class Oval(Shape):
    def __init__(self, *args, **kwargs):
        super().__init__(
            'Oval', ['centerX', 'centerY', 'width', 'height'], args, kwargs
        )


class Circle(Shape):
    _js_attrs = Shape._js_attrs | {'radius'}

    def __init__(self, *args, **kwargs):
        super().__init__('Circle', ['centerX', 'centerY', 'radius'], args, kwargs)


class RegularPolygon(Shape):
    _js_attrs = Shape._js_attrs | {'radius', 'points'}

    def __init__(self, *args, **kwargs):
        super().__init__(
            'RegularPolygon', ['centerX', 'centerY', 'radius', 'points'], args, kwargs
        )


class Star(Shape):
    _js_attrs = Shape._js_attrs | {'radius', 'points', 'roundness'}
    _init_attrs = Shape._init_attrs | {'roundness'}

    def __init__(self, *args, **kwargs):
        super().__init__(
            'Star', ['centerX', 'centerY', 'radius', 'points'], args, kwargs
        )


class Line(Shape):
    _js_attrs = Shape._js_attrs | {
        'x1',
        'y1',
        'x2',
        'y2',
        'lineWidth',
        'arrowStart',
        'arrowEnd',
    }
    _init_attrs = (Shape._init_attrs | {'lineWidth', 'arrowStart', 'arrowEnd'}) - {
        'align',
        'border',
        'borderWidth',
    }

    def __init__(self, *args, **kwargs):
        super().__init__('Line', ['x1', 'y1', 'x2', 'y2'], args, kwargs)


class Polygon(Shape):
    _js_attrs = Shape._js_attrs | {'addPoint', 'pointList', 'setCoord'}
    _init_attrs = Shape._init_attrs - {'align'}

    def isCoordName(self, attr):
        return (
            len(attr) >= 2 and (attr[0] == 'x' or attr[0] == 'y') and attr[1:].isdigit()
        )

    def validatePointIndex(self, attr):
        pointList = super().__getattr__('pointList')
        pointIndex = int(attr[1:]) - 1
        if pointIndex < 0:
            raise AttributeError(
                t(
                    "Polygon object cannot access '{{attr}}' because point numbers start from 1",
                    {'attr': attr},
                )
            )
        if pointIndex >= len(pointList):
            if len(pointList) == 1:
                error = t(
                    "Polygon object cannot access '{{attr}}' because it only has 1 point",
                    {'attr': attr},
                )
            else:
                error = t(
                    "Polygon object cannot access '{{attr}}' because it only has {{numPoints}} points",
                    {'attr': attr, 'numPoints': len(pointList)},
                )
            raise AttributeError(error)

    def getCoord(self, attr):
        self.validatePointIndex(attr)
        pointList = list(super().__getattr__('pointList'))
        pointIndex = int(attr[1:]) - 1
        varIndex = 0 if attr[0] == 'x' else 1
        return pointList[pointIndex][varIndex]

    def setCoord(self, attr, val):
        self.validatePointIndex(attr)
        pointIndex = int(attr[1:]) - 1
        varIndex = 0 if attr[0] == 'x' else 1
        setCoordFn = super().__getattr__('setCoord')
        return setCoordFn(attr, varIndex, pointIndex, val)

    def __getattr__(self, attr):
        if self.isCoordName(attr):
            return self.getCoord(attr)
        else:
            return super().__getattr__(attr)

    def __setattr__(self, attr, val):
        if self.isCoordName(attr):
            self.setCoord(attr, val)
        else:
            super().__setattr__(attr, val)

    def __init__(self, *args, **kwargs):
        super().__init__('Polygon', ['initialPoints'], [args], kwargs)


class Arc(Shape):
    _js_attrs = Shape._js_attrs | {'startAngle', 'sweepAngle'}
    _init_attrs = Shape._init_attrs - {'align'}

    def __init__(self, *args, **kwargs):
        super().__init__(
            'Arc',
            ['centerX', 'centerY', 'width', 'height', 'startAngle', 'sweepAngle'],
            args,
            kwargs,
        )


class Label(Shape):
    _js_attrs = Shape._js_attrs | {'value', 'font', 'size', 'bold', 'italic'}
    _init_attrs = (Shape._init_attrs | {'bold', 'italic', 'size', 'font'}) - {'dashes'}

    def __init__(self, *args, **kwargs):
        super().__init__('Label', ['value', 'centerX', 'centerY'], args, kwargs)


class Group(Shape):
    _js_attrs = Shape._js_attrs | {
        'children',
        'add',
        'clear',
        'remove',
        'hitTest',
        # these attributes are not pass-through, so will throw an error if used
        'arrowEnd',
        'arrowStart',
        'url',
        'radius',
        'points',
        'roundness',
        'x1',
        'y1',
        'x2',
        'y2',
        'lineWidth',
        'startAngle',
        'sweepAngle',
        'value',
        'font',
        'size',
        'bold',
        'italic',
    }
    _init_attrs = {'visible', 'db'}

    def __init__(self, *args, **kwargs):
        if app is not None and app._app._isMvc:
            raise NotImplementedError(
                'Whoops! Group objects are not available in CPCS Mode.'
            )
        super().__init__('Group', [], [], kwargs)
        for shape in args:
            self.add(shape)

    def __iter__(self):
        return iter(self._shape)

    def __len__(self):
        return len(self._shape._shapes)


class Sound(object):
    number_of_sounds = 0

    def __init__(self, url):
        if not isinstance(url, str):
            callSpec = '{className}.{attr}'.format(className=t('Sound'), attr=t('url'))
            err = t(
                '{{error}}: {{callSpec}} should be {{typeName}} (but {{value}} is of type {{valueType}})',
                {
                    'error': t('TypeError'),
                    'callSpec': callSpec,
                    'typeName': 'string',
                    'value': repr(url),
                    'valueType': type(url).__name__,
                },
            )
            raise Exception(err)

        Sound.number_of_sounds += 1

        if url.startswith('file://'):
            url = url.split('//')[-1]

        if url.startswith('http'):
            try:
                response = webrequest.get(url)
                data = io.BytesIO(response.read()).getvalue()
            except Exception:
                raise Exception('Failed to load sound data')
        else:
            if hasattr(__main__, '__file__'):
                path = os.path.abspath(os.path.join(__main__.__file__, '..', url))
            else:
                path = os.path.abspath(os.path.join(os.getcwd(), url))
            with open(path, 'rb') as f:
                data = f.read()

        self._sound = wyvern.WyvernSound(data)

    def play(self, **kwargs):
        default_kwargs = {'loop': False, 'restart': False}

        for keyword in kwargs:
            english_keyword = toEnglish(keyword, 'shape-attr')
            if english_keyword not in default_kwargs:
                raise Exception(
                    "TypeError: %s.%s() got an unexpected keyword argument '%s'"
                    % (t('Sound'), t('play'), keyword)
                )
            default_kwargs[english_keyword] = kwargs[keyword]

        loop = default_kwargs['loop']
        restart = default_kwargs['restart']

        if not isinstance(loop, bool):
            raise Exception(
                'The loop argument to Sound.play must be True or False, got '
                + repr(loop)
            )
        if not isinstance(restart, bool):
            raise Exception(
                'The restart argument to Sound.play must be True or False, got '
                + repr(restart)
            )

        self._sound.play(loop, restart)

    def pause(self):
        self._sound.pause()

    def setVolume(self, volume: float):
        """
        Volume in the range of 0.0 to 1.0 (inclusive)\n
        If value < 0.0, the volume will not be changed\n
        If value > 1.0, the volume will be set to 1.0
        """
        self._sound.set_volume(volume)

    def getVolume(self):
        """
        Returns the volume (range: 0.0 - 1.0 (inclusive))
        """
        return self._sound.get_volume()


SHAPES = [
    Arc,
    Circle,
    Image,
    Label,
    Line,
    Oval,
    Polygon,
    Rect,
    RegularPolygon,
    Star,
]

enEventHandlerNamesMinusOnAppStart = [
    'onKeyPress',
    'onKeyHold',
    'onKeyRelease',
    'onMousePress',
    'onMouseDrag',
    'onMouseRelease',
    'onMouseMove',
    'onResize',
    'onStep',
    'redrawAll',
]

eventHandlerTranslationsMinusOnAppStart = list(
    enEventHandlerNamesMinusOnAppStart
)  # Make a copy

onAppStartTranslations = ['onAppStart']

for language, translations in shape_logic.TRANSLATED_USER_FUNCTION_NAMES.items():
    if language == 'keys':
        continue
    for appFnName in enEventHandlerNamesMinusOnAppStart:
        for appFnNameTranslation in translations.get(appFnName, []):
            if appFnNameTranslation not in eventHandlerTranslationsMinusOnAppStart:
                eventHandlerTranslationsMinusOnAppStart.append(appFnNameTranslation)

    for onAppStartTranslation in translations.get('onAppStart', []):
        if onAppStartTranslation not in onAppStartTranslations:
            onAppStartTranslations.append(onAppStartTranslation)


class NoMvc:
    def __enter__(self):
        self.oldMvc = app._app._isMvc
        app._app._isMvc = False

    def __exit__(self, excType, excValue, tb):
        app._app._isMvc = self.oldMvc


# Shapes whose drawing functions can make a shape_logic.LazyShape
_LAZY_SHAPE_NAMES = frozenset(('Rect', 'Oval', 'Circle'))


def _englishKwargs(shape, kwargs):
    """kwargs with English names, as Shape.__init__ translates them, or None
    if Shape.__init__ would reject one (or two have the same translation)."""
    result = {}
    for attr, value in kwargs.items():
        enAttr = toEnglish(attr, 'shape-attr')
        if enAttr not in shape._init_attrs or enAttr in result:
            return None
        result[enAttr] = value
    return result


# Styles for LazyShapes (or False for keyword arguments that need a real
# shape), by the shape, the keyword arguments, and the language. Checking
# keyword arguments (translating names, looking up colors) costs more than
# working out where a shape goes, and shapes that move every frame usually
# keep the same style. Keyword argument values are keyed with their types
# (see shape_logic.shapeTemplateKey), and calls with other values aren't
# remembered.
_lazyShapeStyles = {}


def _lazyShapePlan(shape, args, kwargs):
    language = shape_logic.cmuGraphicsLanguage
    try:
        key = (
            shape,
            language,
            tuple(kwargs),
            shape_logic._templateKeyParts(kwargs.values()),
        )
    except shape_logic._NotTemplatable:
        key = None
        style = None
    else:
        style = _lazyShapeStyles.get(key)
    if style is None:
        englishKwargs = _englishKwargs(shape, kwargs)
        style = (englishKwargs is not None) and shape_logic.lazyShapeStyle(
            englishKwargs
        )
        style = style or False
        if key is not None:
            if len(_lazyShapeStyles) >= 4096:
                _lazyShapeStyles.clear()
            _lazyShapeStyles[key] = style
    if style is False:
        return None
    return shape_logic.lazyShapePlan(shape.__name__, args, style)


def _makeDrawnShape(shape, args, kwargs, language):
    """Makes the shape that draw{shape}(*args, **kwargs) would have made, in
    the language it was called in, for a LazyShape that something needs the
    real shape for. The new shape isn't added to a group, and doesn't use up
    an id or count as another shape created: the LazyShape already did."""
    global SHAPES_CREATED
    appImpl = app._app
    drawing = shape_logic.activeDrawing
    saved = (
        appImpl._isMvc,
        shape_logic.cmuGraphicsLanguage,
        drawing.tlg,
        drawing.nextShapeId,
        drawing.addCounter,
        SHAPES_CREATED,
    )
    appImpl._isMvc = False
    shape_logic.cmuGraphicsLanguage = language
    drawing.tlg = None
    try:
        kwargs = dict(kwargs)
        kwargs['isMvc'] = True
        return shape(*args, **kwargs)._shape
    finally:
        (
            appImpl._isMvc,
            shape_logic.cmuGraphicsLanguage,
            drawing.tlg,
            drawing.nextShapeId,
            drawing.addCounter,
            SHAPES_CREATED,
        ) = saved


def makeDrawFn(shape):
    canBeLazy = shape.__name__ in _LAZY_SHAPE_NAMES

    def drawFn(*args, **kwargs):
        appImpl = app._app
        if not appImpl._isMvc:
            raise Exception(
                f'You called draw{shape.__name__} (a CPCS Mode function) outside of redrawAll.'
            )
        if not appImpl.inRedrawAll:
            raise MvcException('Cannot draw (modify the view) outside of redrawAll')
        if canBeLazy:
            plan = _lazyShapePlan(shape, args, kwargs)
            if plan:
                global SHAPES_CREATED
                SHAPES_CREATED += 1
                language = shape_logic.cmuGraphicsLanguage
                shape_logic.addLazyShape(
                    plan, lambda: _makeDrawnShape(shape, args, kwargs, language)
                )
                return
        # The same as `with NoMvc():`, which costs more than this, and this
        # runs for every shape drawn
        oldMvc = appImpl._isMvc
        appImpl._isMvc = False
        try:
            kwargs['isMvc'] = True
            shape(*args, **kwargs)
        finally:
            app._app._isMvc = oldMvc

    return drawFn


def makeInvisibleConstructor(shape):
    def constructor(*args, **kwargs):
        if not app._app._isMvc:
            raise Exception(
                f'You called {shape.__name__}Shape (a CPCS Mode function) outside of CPCS Mode. To run your app in CPCS Mode, use runApp().'
            )
        with NoMvc():
            result = shape(*args, **kwargs)
        result.visible = False
        return result

    return constructor


def createDrawingFunctions():
    g = globals()
    for shape in SHAPES:
        shapeName = shape.__name__
        if shapeName == 'Group':
            continue
        g['draw' + shapeName] = makeDrawFn(shape)
        g[shapeName + 'Shape'] = makeInvisibleConstructor(shape)


createDrawingFunctions()


class KeyName(str):
    def __init__(self, baseKey):
        self.__dict__['accentCombinations'] = accentCombinations(str(self))

    def __eq__(self, other):
        return other in self.accentCombinations

    def __setattr__(self, attr, value):
        raise AttributeError(f"'str' object has no attribute '{attr}'")


def translateKeyName(keyName, originalLanguage):
    if originalLanguage not in TRANSLATED_KEY_NAMES:
        return keyName
    return KeyName(TRANSLATED_KEY_NAMES[originalLanguage].get(keyName, keyName))


def cleanAndClose():
    try:
        # This is mainly used for cleaning up resources like temporary files.
        # Since you can't leak resources on web, this doesn't have a web equivalent.
        app._app.callUserFn('onAppStop', (), redraw=False)
    except Exception:
        pass
    os._exit(0)


def _safeMethod(appMethod):
    def m(*args, **kwargs):
        app = args[0]
        try:
            return appMethod(*args, **kwargs)
        except Exception:
            sys.excepthook(*sys.exc_info())
            app.stop()
            if app._running:
                app.drawErrorScreen()
            else:
                cleanAndClose()

    return m


class App(object):
    def printFullTracebacks(self):
        shape_logic.printFullTracebacks()

    def getScreenshot(self, path):
        with DRAWING_LOCK:
            self._ctx.save_png(path)

    def quit(self):
        self._running = False
        wyvern.quit()

    def getPosArgCount(self, fn):
        fn_code = fn.__code__
        pos_count = fn_code.co_argcount
        arg_names = fn_code.co_varnames
        return len(arg_names[:pos_count])

    def usesControl(self, fn):
        fn_code = fn.__code__
        return 'control' in fn_code.co_consts

    def getFnNameAndLanguage(self, enFnName, useActiveScreen):
        if enFnName in self.userGlobals:
            return enFnName, 'en'

        if app._app._initialScreen is not None and useActiveScreen:
            screenFnName = f'{self.activeScreen}_{enFnName}'
            if screenFnName in self.userGlobals:
                return screenFnName, 'en'

        for (
            language,
            translations,
        ) in shape_logic.TRANSLATED_USER_FUNCTION_NAMES.items():
            if language == 'keys':
                continue

            for fnTranslation in translations.get(enFnName, []):
                # We always use the non-screen version of the function first if
                # it exists in the code. This is ok, because non-screen
                # functions are not allowed when you're running an app with
                # screens (except for onAppStart)
                if fnTranslation in self.userGlobals:
                    return fnTranslation, language

                if app._app._initialScreen is not None and useActiveScreen:
                    screenFnName = f'{self.activeScreen}_{fnTranslation}'
                    if screenFnName in self.userGlobals:
                        return screenFnName, language

        return None, None

    def translateEventHandlerArgs(self, baseFnName, language, args):
        if baseFnName == 'onKeyHold':
            args = ([translateKeyName(x, language) for x in args[0]],)
        elif baseFnName in ('onKeyPress', 'onKeyRelease'):
            args = (translateKeyName(args[0], language), args[1])

        return args

    def getEventHandlerArgs(self, baseFnName, language, fn, args, kwargs):
        if language != 'en':
            args = self.translateEventHandlerArgs(baseFnName, language, args)

        if self._isMvc:
            args = (self._wrapper,) + args

        if baseFnName in (
            'onKeyPress',
            'onKeyRelease',
            'onKeyHold',
            'onMousePress',
            'onMouseRelease',
            'onMouseDrag',
        ):
            if self.getPosArgCount(fn) < len(args):
                args = args[:-1]
            elif (
                baseFnName in ('onKeyPress', 'onKeyRelease', 'onKeyHold')
                and self.shouldPrintCtrlWarning
                and self.usesControl(fn)
            ):
                print('INFO: To use the control key in your app without')
                print('enabling the inspector, set app.inspectorEnabled')
                print('to False. To stop this message from printing,')
                print('set app.inspectorEnabled to True.')
                self.shouldPrintCtrlWarning = False

        return args, kwargs

    @_safeMethod
    def callUserFn(
        self, baseFnName, args, kwargs=None, redraw=True, useActiveScreen=True
    ):
        if kwargs is None:
            kwargs = dict()

        fnName, language = self.getFnNameAndLanguage(baseFnName, useActiveScreen)
        if fnName is None:
            return

        fn = self.userGlobals[fnName]
        args, kwargs = self.getEventHandlerArgs(baseFnName, language, fn, args, kwargs)

        fn(*args, **kwargs)

        if redraw and self._isMvc and baseFnName != 'redrawAll':
            self.redrawAllWrapper()

    def redrawAllWrapper(self):
        # Before the event loop runs (like runApp's first redrawAll), run it
        # right away, so errors are handled the same way as without frame
        # skipping (an error before the window opens ends the program).
        if self._skipFrames and self._isMvc and self._running:
            # Run it when the next frame is drawn (see drawFrame)
            self._redrawAllPending = True
            return
        self.runRedrawAll()

    @_safeMethod
    def runPendingRedrawAll(self):
        # Errors from a deferred redrawAll (like an MVC violation) are handled
        # like errors from the event handler that would have run it
        self._redrawAllPending = False
        self.runRedrawAll()

    def runRedrawAll(self):
        # The same as self.group.clear(), without going through slGet/slApply
        self._tlg._shape.clear()
        shape_logic.startShapeTemplateFrame()

        checkerEnabled = not self.disableMvcChecker
        self.inRedrawAll = True
        try:
            checkerSeconds = 0
            hash1 = None
            if checkerEnabled:
                t0 = time.monotonic()
                hash1 = appHash()
                checkerSeconds += time.monotonic() - t0

            self.callUserFn('redrawAll', ())

            if checkerEnabled:
                t0 = time.monotonic()
                hash2 = appHash()
                checkerSeconds += time.monotonic() - t0
                if hash2 != hash1:
                    raise MvcException(
                        'You may not change the app state (the model) in redrawAll (the view)'
                    )

                if checkerSeconds >= 0.1 and self.slowMvcCheckerCount < 5:
                    self.slowMvcCheckerCount += 1
                    if self.slowMvcCheckerCount == 5:
                        print(
                            'WARNING: The MVC violation checker is taking a long time to run in '
                            'your program. This can happen when your model is very large.\n\n'
                            'You can disable the MVC violation checker (and potentially speed up '
                            'your program) by setting app.disableMvcChecker to True in onAppStart.'
                        )
        finally:
            self.inRedrawAll = False

    def drawErrorScreen(self):
        self._frameChanged = True
        if self._redrawAllPending:
            # With frame skipping, show what the event handlers before the
            # error drew (normally their redrawAll calls would have already
            # run), then the error screen over it. Clearing the flag first
            # means an error in that redrawAll can't come back here.
            self._redrawAllPending = False
            errorScreensBefore = self._errorScreensDrawn
            try:
                self.runRedrawAll()
            except Exception:
                pass  # The app has already stopped with an error
            if self._errorScreensDrawn != errorScreensBefore:
                return  # That redrawAll failed, and drew the error screen
        self._errorScreensDrawn += 1
        with NoMvc():
            Rect(0, 0, self.width, self.height, fill=None, border='red', borderWidth=2)
            Rect(
                10,
                self.height - 60,
                self.width - 20,
                50,
                fill='white',
                border='red',
                borderWidth=4,
            )
            Label(
                'Exception! App Stopped!',
                self.width / 2,
                self.height - 45,
                size=12,
                bold=True,
                font='Arial',
                fill='red',
            )
            Label(
                'See console for details',
                self.width / 2,
                self.height - 25,
                size=12,
                bold=True,
                font='Arial',
                fill='red',
            )

    def handleKeyPress(self, key, modifiers):
        self._modifiers = list(modifiers)

        if key is None:
            return
        if key == 'control':
            self.isCtrlKeyDown = True
            return
        if key == 'space' and 'shift' in modifiers:
            self.paused = not self.paused
            return

        self._allKeysDown.add(key)
        self.callUserFn('onKeyPress', (key, modifiers))

    def handleKeyRelease(self, key, modifiers):
        self._modifiers = list(modifiers)

        if key is None:
            return
        if key == 'control':
            self.isCtrlKeyDown = False
            return
        if key.upper() in self._allKeysDown:
            self._allKeysDown.remove(key.upper())
        if key.lower() in self._allKeysDown:
            self._allKeysDown.remove(key.lower())

        self.callUserFn('onKeyRelease', (key, modifiers))

    def backgroundShape(self):
        """The Rect that redrawAll draws the background with. It's in no
        group and drawing doesn't change it, so the one made for the last
        frame is drawn again if the app's size, background, and language are
        the same. It still takes up a shape id, like a new one would."""
        width, height = self.width, self.height
        fill = self.background or 'white'
        try:
            key = (
                shape_logic._templateKeyParts((width, height)),
                # Colors other than names are kept by identity (and kept alive
                # by the key, so the identity isn't reused)
                fill if type(fill) is str else (type(fill), id(fill), fill),
                shape_logic.cmuGraphicsLanguage,
            )
        except shape_logic._NotTemplatable:
            key = None
        cached = self._backgroundShape
        if key is not None and cached is not None and cached[0] == key:
            shape_logic.activeDrawing.nextShapeId += 1
            return cached[1]
        shape = shape_logic.Rect(
            {
                'noGroup': True,
                'top': 0,
                'left': 0,
                'width': width,
                'height': height,
                'fill': fill,
            }
        )
        self._backgroundShape = None if key is None else (key, shape)
        return shape

    def redrawAll(self, ctx):
        self.backgroundShape().draw(ctx)

        ctx.save()
        try:
            self._tlg._shape.draw(ctx)
        finally:
            ctx.restore()

        ctx.save()
        try:
            if self.shouldDrawInspector():
                self.inspector.draw(ctx)
        finally:
            ctx.restore()

        self.frameworkRedrew = True

    def drawFrame(self, ctx):
        """Draws the app to ctx for a 'redraw' event."""
        if self._skipFrames and self._isMvc:
            if self._redrawAllPending:
                self.runPendingRedrawAll()
                self._frameChanged = True
            showInspector = self.shouldDrawInspector()
            if not (self._frameChanged or showInspector or self._inspectorWasDrawn):
                # Nothing changed since the last frame, which ctx still holds
                return
            self._frameChanged = False
            self._inspectorWasDrawn = showInspector
        self.inspector.clearCache()
        self.redrawAll(ctx)

    def shouldDrawInspector(self):
        return self.inspectorEnabled and (
            self.paused or self.alwaysShowInspector or self.isCtrlKeyDown
        )

    def __init__(self):
        self.userGlobals = __main__.__dict__
        try:
            self.title, _ = os.path.splitext(
                os.path.basename(os.path.realpath(__main__.__file__))
            )
        except Exception:
            self.title = 'CMU CS Academy'

        self._width = 400
        self._height = 400
        self._allKeysDown = set()
        self._modifiers = []
        self.background = None

        self._stepsPerSecond = 30

        self._tlg = Group()
        sli.setTopLevelGroup(self._tlg)

        self.paused = False
        self._stopped = False
        self._running = False
        self.textInputs = []

        self.inspector = shape_logic.Inspector(self)
        self._inspectorEnabled = True
        self.shouldPrintCtrlWarning = True
        self.alwaysShowInspector = False
        self.isCtrlKeyDown = False
        self.showFontWarnings = True

        self._isMvc = False
        self._initialScreen = None

        # CMU_GRAPHICS_DISABLE_MVC_CHECKER=1 starts apps with the MVC violation
        # checker off, as if they set app.disableMvcChecker = True, for running
        # unmodified apps on slow devices. An app can still turn it back on.
        self._disableMvcChecker = (
            os.environ.get('CMU_GRAPHICS_DISABLE_MVC_CHECKER') == '1'
        )
        self.slowMvcCheckerCount = 0

        self._lastStepTime = None
        self._sizeChanged = False
        self._takeScreenshotPath = None
        self._screenshotTriggered = False

        self._cursorVisible = True
        self._fullscreen = False

        # Frame skipping, an opt-in mode for slow devices, set with the
        # CMU_GRAPHICS_SKIP_FRAMES=1 environment variable. It only affects
        # CPCS Mode (runApp). Normally redrawAll runs after every event
        # handler, even when several handlers run before the next frame is
        # drawn (like onStep and onKeyHold), and every frame is drawn even
        # if nothing changed. With frame skipping, redrawAll runs once, right
        # before the next frame is drawn, and frames where nothing could
        # have changed aren't drawn at all (the window keeps the last one).
        # So redrawAll runs fewer times, which students can see if it
        # prints or counts something.
        self._skipFrames = os.environ.get('CMU_GRAPHICS_SKIP_FRAMES') == '1'
        self._redrawAllPending = False
        self._frameChanged = True
        self._inspectorWasDrawn = False
        self._errorScreensDrawn = 0
        # See backgroundShape
        self._backgroundShape = None

    def get_group(self):
        return self._tlg

    def set_group(self, _):
        raise Exception('App.group is readonly')

    group = property(get_group, set_group)

    def get_stopped(self):
        return self._stopped

    def set_stopped(self, _):
        raise Exception('App.stopped is readonly')

    stopped = property(get_stopped, set_stopped)

    def getStepsPerSecond(self):
        return self._stepsPerSecond

    def setStepsPerSecond(self, value):
        shape_logic.checkNumber(sli.t('app'), 'stepsPerSecond', value, False)
        self._stepsPerSecond = value
        wyvern.set_steps_per_second(value)

    stepsPerSecond = property(getStepsPerSecond, setStepsPerSecond)

    def getDisableMvcChecker(self):
        return self._disableMvcChecker

    def setDisableMvcChecker(self, value):
        if not isinstance(value, bool):
            raise Exception('app.disableMvcChecker must be set to a boolean')
        self._disableMvcChecker = value

    disableMvcChecker = property(getDisableMvcChecker, setDisableMvcChecker)

    def getBackground(self):
        return sli.slGetAppProperty('background')

    def setBackground(self, value):
        self._frameChanged = True
        return sli.slSetAppProperty('background', value)

    background = property(getBackground, setBackground)

    def getMaxShapeCount(self):
        return sli.slGetAppProperty('maxShapeCount')

    def setMaxShapeCount(self, value):
        return sli.slSetAppProperty('maxShapeCount', value)

    maxShapeCount = property(getMaxShapeCount, setMaxShapeCount)

    def updateScreenSize(self):
        # Resize the window once the current event is handled, so setting
        # width and then height sends a single resize instead of two
        if self._running:
            self._sizeChanged = True

    def handleResize(self, newWidth, newHeight):
        if (newWidth, newHeight) == (self._width, self._height):
            return

        self._width = newWidth
        self._height = newHeight

        # Redraw even if onResize is not present in the user's globals
        self.callUserFn('onResize', (), redraw=False)
        if self._isMvc:
            self.redrawAllWrapper()

    def handleSetActiveScreen(self, newScreen, redraw=True):
        self.activeScreen = newScreen

        # Redraw even if onScreenActivate is not present in the user's globals
        self.callUserFn('onScreenActivate', (), redraw=False, useActiveScreen=True)
        if redraw:
            self.redrawAllWrapper()

    def getLeft(self):
        return 0

    def setLeft(self, value):
        raise Exception('App.left is readonly')

    left = property(getLeft, setLeft)

    def getRight(self):
        return self._width

    def setRight(self, value):
        self._width = value
        self.updateScreenSize()

    right = property(getRight, setRight)

    def getTop(self):
        return 0

    def setTop(self, value):
        raise Exception(t('App.top is readonly'))

    top = property(getTop, setTop)

    def getBottom(self):
        return self._height

    def setBottom(self, value):
        self._height = value
        self.updateScreenSize()

    bottom = property(getBottom, setBottom)

    def getWidth(self):
        return self._width

    def setWidth(self, value):
        self._width = value
        self.updateScreenSize()

    width = property(getWidth, setWidth)

    def getHeight(self):
        return self._height

    def setHeight(self, value):
        self._height = value
        self.updateScreenSize()

    height = property(getHeight, setHeight)

    def get_inspectorEnabled(self):
        return self._inspectorEnabled

    def set_inspectorEnabled(self, value):
        self.shouldPrintCtrlWarning = False
        self._inspectorEnabled = value

    inspectorEnabled = property(get_inspectorEnabled, set_inspectorEnabled)

    def get_showFontWarnings(self):
        return shape_logic.SHOW_FONT_WARNINGS

    def set_showFontWarnings(self, value):
        shape_logic.SHOW_FONT_WARNINGS = value

    showFontWarnings = property(get_showFontWarnings, set_showFontWarnings)

    def get_cursorVisible(self):
        return self._cursorVisible

    def set_cursorVisible(self, value):
        self._cursorVisible = value
        if self._running:
            wyvern.set_cursor_visible(value)

    cursorVisible = property(get_cursorVisible, set_cursorVisible)

    def stop(self):
        self._stopped = True

    def getTextInput(self, prompt='Enter some text'):
        if self.textInputs:
            return self.textInputs.pop(0)
        p = self.spawnModalProcess()
        packet = bytes(
            json.dumps({'title': self.title, 'prompt': prompt, 'getInput': True})
            + '\n',
            encoding='utf-8',
        )
        result, errors = p.communicate(packet)
        if p.returncode is not None and p.returncode != 0:
            print(errors.decode('utf-8'))
            raise Exception('Exception in getTextInput.')
        return result.decode('utf-8')

    def showMessage(self, prompt=''):
        p = self.spawnModalProcess()
        packet = bytes(
            json.dumps({'title': self.title, 'prompt': prompt, 'getInput': False})
            + '\n',
            encoding='utf-8',
        )
        unused_result, errors = p.communicate(packet)
        if p.returncode is not None and p.returncode != 0:
            print(errors.decode('utf-8'))
            raise Exception('Exception in showMessage.')

    def setTextInputs(self, *args):
        for arg in args:
            if not isinstance(arg, str):
                raise Exception(
                    'Arguments to setTextInputs must be strings. %r is not a string.'
                    % arg
                )
        self.textInputs = list(args)

    def spawnModalProcess(self):
        current_directory = os.path.dirname(os.path.realpath(__file__))
        modal_path = os.path.join(current_directory, 'modal.py')
        p = subprocess.Popen(
            [sys.executable, modal_path],
            stdout=subprocess.PIPE,
            stdin=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=current_directory,
        )
        return p

    def enableFullscreen(self):
        self._fullscreen = True
        if self._running:
            wyvern.set_fullscreen(True)

    def disableFullscreen(self):
        self._fullscreen = False
        if self._running:
            wyvern.set_fullscreen(False)

    def on_event(self, event, surface):
        try:
            self.handleEvent(event, surface)
        finally:
            if self._sizeChanged:
                self._sizeChanged = False
                wyvern.set_size(int(self._width), int(self._height))

    def handleEvent(self, event, surface):
        self._ctx = surface.canvas

        if event.event_type == 'resize':
            # The canvas was replaced with a blank one, even if the app's size
            # didn't change, so the next frame must be drawn
            self._frameChanged = True

        # The inspector keeps working after the app stops (e.g. on an error),
        # so track the mouse and control key even then
        if event.event_type in ('mouse_move', 'mouse_drag'):
            self.inspector.setMousePosition(event.mouse.x, event.mouse.y)
        elif event.event_type in ('key_press', 'key_release'):
            if event.key.key == 'control':
                self.isCtrlKeyDown = event.event_type == 'key_press'

        if self.stopped and event.event_type not in ('redraw', 'step'):
            return

        elif event.event_type == 'step':
            self._handleStep()

        elif event.event_type == 'redraw':
            if self._takeScreenshotPath is not None:
                if not self._screenshotTriggered:
                    self.callUserFn('onMousePress', (200, 200, 0))
                    self._screenshotTriggered = True
                else:
                    self.drawFrame(self._ctx)
                    self.getScreenshot(self._takeScreenshotPath)
                    self._running = False
                    self.quit()
                return
            self.drawFrame(self._ctx)

        elif event.event_type == 'mouse_press':
            self.callUserFn(
                'onMousePress', (event.mouse.x, event.mouse.y, event.mouse.button)
            )

        elif event.event_type == 'mouse_release':
            self.callUserFn(
                'onMouseRelease', (event.mouse.x, event.mouse.y, event.mouse.button)
            )

        elif event.event_type == 'mouse_move':
            self.callUserFn('onMouseMove', (event.mouse.x, event.mouse.y))

        elif event.event_type == 'mouse_drag':
            self.callUserFn(
                'onMouseDrag', (event.mouse.x, event.mouse.y, list(event.mouse.buttons))
            )

        elif event.event_type == 'key_press':
            self.handleKeyPress(event.key.key, event.key.modifiers)

        elif event.event_type == 'key_release':
            self.handleKeyRelease(event.key.key, event.key.modifiers)

        elif event.event_type == 'modifiers_changed':
            # Modifier keys don't send key events, but onKeyHold should see
            # them as soon as they're pressed or released
            self._modifiers = list(event.modifiers)

        elif event.event_type == 'resize':
            self.handleResize(event.resize.width, event.resize.height)

        elif event.event_type == 'set_active_screen':
            self.handleSetActiveScreen(event.new_screen)

    def _handleStep(self):
        # The event loop sends steps at stepsPerSecond (see setStepsPerSecond)
        now = time.monotonic()
        if self._lastStepTime is None:
            msPassed = 1000 / self.stepsPerSecond
        else:
            msPassed = (now - self._lastStepTime) * 1000
        self._lastStepTime = now

        if not (self.paused or self.stopped):
            self.callUserFn('onStep', ())
            if len(self._allKeysDown) > 0:
                self.callUserFn(
                    'onKeyHold', (list(self._allKeysDown), list(self._modifiers))
                )
            onStepEvent.send_robust(self.callUserFn, self._wrapper)

        onMainLoopEvent.send_robust(msPassed, self.callUserFn, self._wrapper)

    @_safeMethod
    def run(self, takeScreenshotPath=None):
        self._takeScreenshotPath = takeScreenshotPath
        self._screenshotTriggered = False
        self._running = True
        wyvern.set_steps_per_second(self.stepsPerSecond)

        try:
            wyvern.run(
                self.on_event,
                int(self.width),
                int(self.height),
                True,
                self.title,
                self._fullscreen,
                self._cursorVisible,
                # Set when running tests, so windows don't take focus
                visible=not os.environ.get('CMU_GRAPHICS_HIDDEN_WINDOW'),
            )
        finally:
            # The window is gone even if the event loop failed, so there's no
            # error screen to draw. self._running = False causes _safeMethod to exit
            # instead of drawing
            self._running = False
        cleanAndClose()


class MvcException(Exception):
    pass


class AppWrapper(object):
    readOnlyAttrs = set(
        [
            'bottom',
            'centerX',
            'centerY',
            'getTextInput',
            'showMessage',
            'left',
            'quit',
            'right',
            'run',
            'stop',
            'top',
            'setMaxShapeCount',
            'printFullTracebacks',
            'enableFullscreen',
            'disableFullscreen',
        ]
    )
    readWriteAttrs = set(
        [
            'height',
            'paused',
            'stepsPerSecond',
            'group',
            'title',
            'width',
            'background',
            'beatsPerMinute',
            'maxShapeCount',
            'inspectorEnabled',
            'showFontWarnings',
            'disableMvcChecker',
            'cursorVisible',
        ]
    )
    allAttrs = readOnlyAttrs | readWriteAttrs
    # allAttrs, plus every name that toEnglish(name, 'app-attr') could
    # translate to a different name (it returns any other name unchanged)
    translatableOrAppAttrs = frozenset(allAttrs).union(
        name
        for names in shape_logic.REVERSE_TRANSLATED_APP_ATTRS.values()
        for name in names
    )
    stateHashAttrs = readWriteAttrs - {'group', 'disableMvcChecker'}

    def __init__(self, app):
        self._app = app
        app._wrapper = self

    def __dir__(self):
        fields = set(AppWrapper.allAttrs)
        for field in self.__dict__:
            if field not in self._app.__dict__:
                fields.add(field)
        return sorted(fields)

    def __getattribute__(self, attr):
        # The framework reads app._app constantly, so skip translating it
        if attr == '_app':
            return object.__getattribute__(self, '_app')
        # The app's own variables, like app.score: names that no language
        # translates, and that aren't App attributes
        if attr not in AppWrapper.translatableOrAppAttrs:
            return object.__getattribute__(self, attr)
        attr = toEnglish(attr, 'app-attr')
        if attr == '_app' or attr not in AppWrapper.allAttrs:
            return object.__getattribute__(self, attr)
        return object.__getattribute__(self, '_app').__getattribute__(attr)

    def __setattr__(self, attr, value):
        attr = toEnglish(attr, 'app-attr')
        if (attr != '_app') and (getattr(self._app, 'inRedrawAll', False)):
            if attr == 'disableMvcChecker':
                raise MvcException(
                    'Cannot change app.disableMvcChecker in redrawAll — '
                    'set it in onAppStart instead'
                )
            if not self._app.disableMvcChecker:
                raise MvcException(f'Cannot change app.{attr} in redrawAll')
        if attr in AppWrapper.readOnlyAttrs:
            raise Exception(f'app.{attr} is read-only')
        if attr in AppWrapper.readWriteAttrs:
            return self._app.__setattr__(attr, value)
        return super().__setattr__(attr, value)


def appHash():
    try:
        return mvc_checker.appHash(app, AppWrapper.stateHashAttrs)
    except RecursionError:
        # Raised from None so students don't see a traceback through
        # hundreds of deepHash frames
        raise MvcException(
            'Your app state (the model) is too deeply nested for the MVC '
            'violation checker to check. You can disable the MVC violation '
            'checker by setting app.disableMvcChecker to True in onAppStart.'
        ) from None


def processRunAppArgs(args, kwargs):
    # Extract width and height (and their translations) from kwargs
    width = 400
    height = 400

    set_width = False
    set_height = False

    takeScreenshotPath = None

    remaining_kwargs = {}

    # Handle positional arguments for width and height
    if len(args) >= 1:
        width = args[0]
        set_width = True
    if len(args) >= 2:
        height = args[1]
        set_height = True
    if len(args) > 2:
        raise TypeError(
            f'{t("runApp")}() takes from 0 to 2 positional arguments but {len(args)} were given'
        )

    for param, value in kwargs.items():
        if toEnglish(param, 'shape-attr') == 'width':
            if set_width:
                raise TypeError(
                    f"{t('runApp')}() got multiple values for argument '{param}'"
                )
            width = value
            set_width = True
        elif toEnglish(param, 'shape-attr') == 'height':
            if set_height:
                raise TypeError(
                    f"{t('runApp')}() got multiple values for argument '{param}'"
                )
            height = value
            set_height = True
        elif param == 'takeScreenshotPath':
            takeScreenshotPath = value
        else:
            # Pass through any other keyword arguments to onAppStart
            remaining_kwargs[param] = value

    return width, height, takeScreenshotPath, remaining_kwargs


def runApp(*args, **kwargs):
    width, height, takeScreenshotPath, remaining_kwargs = processRunAppArgs(
        args, kwargs
    )

    # If we didn't call runAppWithScreens
    if app._app._initialScreen is None:
        for appFnName in (
            eventHandlerTranslationsMinusOnAppStart + onAppStartTranslations
        ):
            screenAppSuffix = f'_{appFnName}'
            for globalVarName in app._app.userGlobals:
                if globalVarName.endswith(screenAppSuffix):
                    raise Exception(
                        f'The name of your function "{globalVarName}" ends with "{screenAppSuffix}", which is only allowed if you are using "screens" in CPCS Mode. To run an app with screens, call runAppWithScreens() instead of runApp().'
                    )

    setupMvc()
    app.width = width
    app.height = height

    if SHAPES_CREATED > 1:
        raise Exception("""
****************************************************************************
Your code created a shape object (Rect, Oval, etc.) before calling runApp().

runApp (CPCS Mode) is not compatible with shape objects.

If you'd like to use CPCS Mode, please use drawing functions
(drawRect, drawOval, etc) in redrawAll.

Otherwise, please call cmu_graphics.run() in place of runApp.
****************************************************************************""")

    # Don't redraw on either of these calls to callUserFn, because we will
    # instead redraw below
    app._app.callUserFn(
        'onAppStart', (), remaining_kwargs, redraw=False, useActiveScreen=False
    )

    if app._app._initialScreen is not None:
        sortedGlobals = sorted(app._app.userGlobals)
        for onAppStartTranslation in onAppStartTranslations:
            for globalVarName in sortedGlobals:
                if globalVarName.endswith(f'_{onAppStartTranslation}'):
                    screenFn = app._app.userGlobals[globalVarName]
                    screenFn(app, **remaining_kwargs)

        setActiveScreen(app._app._initialScreen, fromRunApp=True)

    # Guarantee at least one call to redrawAll. For example, if your app
    # just sets up variables and draws a static image.
    app._app.redrawAllWrapper()

    run(takeScreenshotPath=takeScreenshotPath)


def setActiveScreen(screen, fromRunApp=False):
    if not app._app._isMvc:
        raise Exception(
            'You called setActiveScreen (a CPCS Mode function) outside of CPCS Mode. To run your app in CPCS Mode, use runApp() or runAppWithScreens().'
        )
    if (screen in [None, '']) or (not isinstance(screen, str)):
        raise Exception(f'{repr(screen)} is not a valid screen')

    redrawAllFnNames = ['redrawAll']
    redrawAllInCorrectLanguage = 'redrawAll'
    for language, translations in shape_logic.TRANSLATED_USER_FUNCTION_NAMES.items():
        if language == 'keys':
            continue
        for redrawAllTranslation in translations.get('redrawAll', []):
            if redrawAllTranslation not in redrawAllFnNames:
                redrawAllFnNames.append(redrawAllTranslation)
                if language == shape_logic.cmuGraphicsLanguage:
                    redrawAllInCorrectLanguage = redrawAllTranslation

    if not any(
        f'{screen}_{fnName}' in app._app.userGlobals for fnName in redrawAllFnNames
    ):
        raise Exception(
            t(
                "Screen '{{screen}}' requires '{{screen}}_{{redrawAllInCorrectLanguage}}()'",
                {
                    'screen': screen,
                    'redrawAllInCorrectLanguage': redrawAllInCorrectLanguage,
                },
            )
        )

    if fromRunApp:
        app._app.handleSetActiveScreen(screen, redraw=not fromRunApp)
    else:
        wyvern.set_active_screen(screen)


def runAppWithScreens(initialScreen, *args, **kwargs):
    userGlobals = app._app.userGlobals

    for appFnName in eventHandlerTranslationsMinusOnAppStart:
        if appFnName in userGlobals:
            raise Exception(f'Do not define {appFnName} when using screens')

    app._app._isMvc = True
    app._app._initialScreen = initialScreen
    runApp(*args, **kwargs)


def getImageSize(url):
    imageData = shape_logic.loadImage(url)
    width, height = imageData['width'], imageData['height']
    return width, height


def setupMvc():
    app._app._isMvc = True
    app._app.inRedrawAll = False
    del app._app.userGlobals['app']
    AppWrapper.readWriteAttrs.remove('paused')
    AppWrapper.allAttrs.remove('paused')


def processArgs(fname, params, args):
    # Check for too many positional arguments
    if len(args) > len(params):
        argStr = 'argument' if len(params) == 1 else 'arguments'
        raise TypeError(
            f'{fname}() takes {len(params)} positional {argStr} but more were given'
        )

    # Check for not enough positional arguments
    if len(params) > len(args):
        missingCount = len(params) - len(args)
        argStr = 'argument' if missingCount == 1 else 'arguments'
        paramsStr = ', '.join([repr(param) for param in params[len(args) :]])
        raise TypeError(
            f'{fname}() missing {missingCount} required positional {argStr}: {paramsStr}'
        )


def eventHandlerRepeater(f):
    sig = inspect.signature(f)
    params = tuple(sig.parameters.keys())

    def g(*args):
        testParams = params
        if app._app._isMvc:
            testParams = ('app',) + testParams
        processArgs(f.__name__, testParams, args)
        if app._app._isMvc:
            args = args[1:]
        f(*args)

    return g


@eventHandlerRepeater
def onSteps(n):
    for _ in range(n):
        app._app.callUserFn('onStep', ())


@eventHandlerRepeater
def onKeyHolds(keys, n):
    assert isinstance(keys, list), t('keys must be a list')
    for _ in range(n):
        app._app.callUserFn('onKeyHold', (keys, []))


@eventHandlerRepeater
def onKeyPresses(key, n):
    for _ in range(n):
        app._app.callUserFn('onKeyPress', (key, []))


def loop():
    run()


def run(*, takeScreenshotPath=None):
    if not app._app._isMvc:
        for cs3ModeHandler in ['redrawAll']:
            if cs3ModeHandler in __main__.__dict__:
                raise Exception(
                    f"You defined the event handler {cs3ModeHandler} which works with CPCS Mode, and then called cmu_graphics.run(), which doesn't work with CPCS Mode. Did you mean to call runApp instead?"
                )

    global MAINLOOP_RUN
    MAINLOOP_RUN = True

    if not os.environ.get('CI', False):
        threading.Thread(target=CSAcademyConsole().interact).start()

    try:
        app._app.run(takeScreenshotPath)
    except KeyboardInterrupt:
        cleanAndClose()


from code import InteractiveConsole


class CSAcademyConsole(InteractiveConsole):
    def __init__(self):
        self.__class__.__name__ = 'CS Academy Console'
        __main__.__dict__['exit'] = lambda: cleanAndClose()
        super().__init__(
            locals=__main__.__dict__, filename='<%s>' % self.__class__.__name__
        )

    # Override the default error handling functions to avoid using our own
    # excepthook function
    def showsyntaxerror(self, filename=None):
        type, value, tb = sys.exc_info()
        sys.last_type = type
        sys.last_value = value
        sys.last_traceback = tb
        if filename and type is SyntaxError:
            # Work hard to stuff the correct filename in the exception
            try:
                msg, (dummy_filename, lineno, offset, line) = value.args
            except ValueError:
                # Not the format we expect; leave it alone
                pass
            else:
                # Stuff in the right filename
                value = SyntaxError(msg, (filename, lineno, offset, line))
                sys.last_value = value

        lines = traceback.format_exception_only(type, value)
        self.write(''.join(lines))

    def showtraceback(self):
        sys.last_type, sys.last_value, last_tb = ei = sys.exc_info()
        sys.last_traceback = last_tb
        try:
            lines = traceback.format_exception(ei[0], ei[1], last_tb.tb_next)
            self.write(''.join(lines))
        finally:
            last_tb = ei = None

    # Override interact so we can exit on EOF
    def interact(self):
        super().interact()
        cleanAndClose()


import sys
import io
from datetime import datetime
from datetime import timedelta
import json
import subprocess
from cmu_graphics.libs import webrequest
import __main__


UPDATE_CONFIG_FILE_PATH = os.path.join(
    os.path.dirname(os.path.realpath(__file__)),
    'meta',
    'updates.json',
)


def get_update_info():
    if os.path.exists(UPDATE_CONFIG_FILE_PATH):
        with open(UPDATE_CONFIG_FILE_PATH, 'r') as f:
            return json.loads(f.read())
    return {}


def save_update_info(update_info):
    with open(UPDATE_CONFIG_FILE_PATH, 'w') as f:
        f.write(json.dumps(update_info))


def version_key(version):
    # Compare release numbers numerically, so that 2.0.10 is newer than 2.0.9.
    # A -N suffix (a post-release, like 3.0.2-1) comes after X.Y.Z and before
    # the next release. Raises ValueError for anything else.
    release, _, post = version.partition('-')
    key = tuple(int(part) for part in release.split('.'))
    return key + (int(post),) if post else key


def check_for_update():
    try:
        update_info = get_update_info()

        current_directory = os.path.dirname(os.path.realpath(__file__))
        with open(os.path.join(current_directory, 'meta', 'version.txt')) as f:
            version = f.read().strip()

        last_attempt = None
        if 'last_attempt' in update_info:
            last_attempt = datetime.fromtimestamp(update_info['last_attempt'])

        if last_attempt is None or (datetime.now() - last_attempt > timedelta(days=1)):
            most_recent_version = (
                webrequest.get(
                    'https://s3.amazonaws.com/cmu-cs-academy.lib.prod/desktop-cmu-graphics/version.txt'
                )
                .read()
                .decode('ascii')
                .strip()
            )

            update_info['last_attempt'] = datetime.now().timestamp()
            update_info['most_recent_version'] = most_recent_version
            save_update_info(update_info)
        else:
            most_recent_version = update_info.get('most_recent_version', version)

        if version_key(most_recent_version) > version_key(version):
            print(
                f'\n\nYou are running cmu-graphics version {version}, but a newer version {most_recent_version} is available.'
            )
            if VENDORED:
                print('Visit https://academy.cs.cmu.edu/desktop to upgrade.')
            else:
                print('Run "pip install --upgrade cmu-graphics" to upgrade.')
            print('\n\n')
    except Exception:
        pass


if 'CMU_GRAPHICS_NO_UPDATE' not in __main__.__dict__:
    check_for_update()


def print_debug_info():
    import platform

    current_directory = os.path.dirname(os.path.realpath(__file__))
    with open(os.path.join(current_directory, 'meta', 'version.txt')) as f:
        version = f.read().strip()
    print('=' * 80)
    print('CMU Graphics Version:', version)
    print('Platform:', sys.platform)
    print('Python Version:', '.'.join(platform.python_version_tuple()))
    print('Executable Path:', sys.executable)
    print('Python path:', sys.path)
    print('Working Directory:', current_directory)
    print('=' * 80)


if 'CMU_GRAPHICS_DEBUG' in __main__.__dict__:
    print_debug_info()

import math

from cmu_graphics.deps import wyvern
from random import *
from cmu_graphics.utils import *
import atexit
import threading
import traceback

DRAWING_LOCK = threading.RLock()

sli = shape_logic.ShapeLogicInterface()
slInitShape = sli.slInitShape
slGet = sli.slGet
rgb = sli.rgb
gradient = sli.gradient
# Bound directly rather than through sli, which only forwards the call
toEnglish = shape_logic.toEnglish
accentCombinations = sli.accentCombinations
t = sli.t

SHAPES_CREATED = 0
MAINLOOP_RUN = False


# Checks to see if a user created shapes but did not call
# cmu_graphics.run()
def check_for_exit_without_run():
    global SHAPES_CREATED, MAINLOOP_RUN

    # The app's top level group is created even if the user creates no
    # shapes on their own
    if SHAPES_CREATED > 1 and not MAINLOOP_RUN:
        print("""
                         (
                    (    (
                    ((  (*(
                    (*( (*/
                    (**.***,
                    (***************((((((((((((((((
                    (********************************
                    (*******************************(
                    (*******************************(
                    (*******************************(
                    /*******************************(
                    (/******************(((((((     ((
                (*****(****************,
                /**********(************(
            ((***************(*********
                (*****(/*********(*****(
                    (**********/(/***(*/
                    (****************(
                        (/***********(
                            (*******(
                            (**(
""")
        print(
            ' ** To run your animation, add cmu_graphics.run() to the bottom of your file **\n'
        )


app = None
app = AppWrapper(App())
atexit.register(check_for_exit_without_run)
