"""
GRAND PRIX 2.5D  -  an F1-inspired racer built with CMU Graphics

Weekend format
  1. Menu      : pick difficulty and your race tyre compound
  2. Qualifying: up to 3 timed laps on soft tyres, best lap sets the grid
                 (going beyond the kerbs invalidates the lap)
  3. Race      : 5 laps against 7 AI drivers, standing start with lights

Physics
  - Speed-dependent grip with downforce, braking and engine/drag model
  - Turning rate is limited by steering lock at low speed and by
    tyre grip at high speed (asking for more = understeer + scrubbing)
  - 4 tyre temperatures (heat from cornering/braking/sliding, cooling with
    airflow), each compound has an operating window
  - Tyre wear lowers grip, overheating speeds up wear
  - Fuel load makes the car heavier early in the race
  - ERS battery: deploy for extra power, harvested under braking

AI drivers
  - Plan their path with A* search over a track-aligned lattice
    (layers along the track x lanes across it). Edge costs reward the
    pre-computed minimum-curvature racing line and heavily penalise
    cells that other cars are predicted to occupy (time-aware), so the
    bots naturally follow, defend and overtake.
  - Follow the A* path with pure-pursuit steering
  - Speed comes from a braking-aware speed profile of the racing line,
    scaled by their skill, current tyre grip and fuel load.

Controls
  Up / W        throttle           Down / S   brake (hold at a stop = reverse)
  Left / A      steer left         Right / D  steer right
  Space         ERS deploy         C          change camera
  R             reset car to track P          pause
  X             let the AI drive   Esc        back to menu

Joystick (R36S layout, via joystick.py)
  Left stick / D-pad   steer (analog), push up = throttle, down = brake
  A / R2        throttle           B / L2     brake
  R1            ERS deploy         Y          change camera
  X             let the AI drive   L1         reset car to track
  Start         pause / confirm    Select     end qualifying / menu (paused)
  Menu: D-pad left/right = difficulty, up/down = tyre, A/Start = go

Run:  python3 f1_racer.py   (from the folder that contains cmu_graphics)
"""

from cmu_graphics import *
import math
import random
import heapq
import time
import os
#import joystick

WIDTH, HEIGHT = 640, 480

# --------------------------------------------------------------------------
# Generic helpers
# --------------------------------------------------------------------------


def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


def lerp(a, b, t):
    return a + (b - a) * t


def wrapAngle(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a < -math.pi:
        a += 2 * math.pi
    return a


def fmtTime(t):
    if t is None:
        return '--:--.---'
    m = int(t // 60)
    s = t - 60 * m
    return f'{m}:{s:06.3f}'


def mixColor(c1, c2, t):
    t = clamp(t, 0, 1)
    return rgb(int(lerp(c1[0], c2[0], t)), int(lerp(c1[1], c2[1], t)),
               int(lerp(c1[2], c2[2], t)))


# --------------------------------------------------------------------------
# Track geometry
# --------------------------------------------------------------------------

DS = 4.0            # metres between centreline samples
HW = 7.0            # half width of the asphalt
CURB = 1.4          # kerb width beyond the asphalt edge
RUNOFF = 13.0       # grass run-off before the barrier
WALL = HW + RUNOFF  # lateral distance of the barrier from the centreline
TRACK_SCALE = 0.85

# An original circuit, counter-clockwise, metres
CONTROL_POINTS = [
    (0, 0), (180, 0), (360, 0), (520, 0), (600, 20), (630, 80),
    (600, 140), (520, 160), (450, 175), (430, 230), (470, 280),
    (560, 300), (650, 330), (690, 410), (650, 480), (560, 490),
    (500, 440), (440, 400), (330, 400), (220, 430), (130, 470),
    (40, 460), (-30, 400), (-20, 330), (40, 280), (40, 220),
    (-30, 180), (-110, 150), (-150, 80), (-120, 20), (-60, 0),
]


def catmullRom(p0, p1, p2, p3, t):
    t2, t3 = t * t, t * t * t
    return tuple(0.5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * t +
                        (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 +
                        (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)
                 for k in range(2))


class Track:
    def __init__(self):
        pts = [(x * TRACK_SCALE, y * TRACK_SCALE) for (x, y) in CONTROL_POINTS]
        dense = []
        n = len(pts)
        for i in range(n):
            p0, p1, p2, p3 = pts[i - 1], pts[i], pts[(i + 1) % n], pts[(i + 2) % n]
            for j in range(40):
                dense.append(catmullRom(p0, p1, p2, p3, j / 40))
        # resample uniformly by arc length
        cum = [0.0]
        for i in range(1, len(dense) + 1):
            a, b = dense[i - 1], dense[i % len(dense)]
            cum.append(cum[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
        total = cum[-1]
        self.n = int(total // DS)
        self.length = self.n * DS
        step = total / self.n
        self.cx, self.cy = [], []
        j = 0
        for i in range(self.n):
            target = i * step
            while cum[j + 1] < target:
                j += 1
            a, b = dense[j], dense[(j + 1) % len(dense)]
            t = (target - cum[j]) / max(1e-9, cum[j + 1] - cum[j])
            self.cx.append(lerp(a[0], b[0], t))
            self.cy.append(lerp(a[1], b[1], t))
        N = self.n
        self.tx, self.ty, self.nx, self.ny = [], [], [], []
        for i in range(N):
            dx = self.cx[(i + 1) % N] - self.cx[i - 1]
            dy = self.cy[(i + 1) % N] - self.cy[i - 1]
            d = math.hypot(dx, dy)
            self.tx.append(dx / d)
            self.ty.append(dy / d)
            self.nx.append(-dy / d)   # left normal
            self.ny.append(dx / d)
        self.s = [i * DS for i in range(N)]
        # centreline curvature (signed, + = left turn)
        self.curv = []
        for i in range(N):
            h1 = math.atan2(self.ty[i - 2], self.tx[i - 2])
            h2 = math.atan2(self.ty[(i + 2) % N], self.tx[(i + 2) % N])
            self.curv.append(wrapAngle(h2 - h1) / (4 * DS))
        self.edges = {}
        for w in (HW, HW + CURB, WALL, WALL + 0.6, HW + 2.5):
            self.edges[w] = self.offsetPoints(w)
        self.buildRacingLine()
        self.buildSpeedProfile()
        self.buildScenery()
        # lattice lanes used by the A* planner
        maxOff = HW - 1.6
        self.lanes = [-maxOff + k * (2 * maxOff / (LANES - 1)) for k in range(LANES)]
        self.maxOff = maxOff

    def offsetPoints(self, w):
        left = [(self.cx[i] + self.nx[i] * w, self.cy[i] + self.ny[i] * w) for i in range(self.n)]
        right = [(self.cx[i] - self.nx[i] * w, self.cy[i] - self.ny[i] * w) for i in range(self.n)]
        return left, right

    def point(self, i, off):
        i %= self.n
        return (self.cx[i] + self.nx[i] * off, self.cy[i] + self.ny[i] * off)

    def buildRacingLine(self):
        # Elastic-band minimisation of curvature, constrained to the track
        N = self.n
        lim = HW - 1.4
        off = [0.0] * N
        for it in range(900):
            # Gauss-Seidel style relaxation towards the neighbour midpoint
            for i in range(N):
                a = (self.cx[i - 3] + self.nx[i - 3] * off[i - 3], self.cy[i - 3] + self.ny[i - 3] * off[i - 3])
                k = (i + 3) % N
                b = (self.cx[k] + self.nx[k] * off[k], self.cy[k] + self.ny[k] * off[k])
                mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
                d = (mx - self.cx[i]) * self.nx[i] + (my - self.cy[i]) * self.ny[i]
                off[i] = clamp(lerp(off[i], d, 0.6), -lim, lim)
        # light smoothing of the offsets
        for _ in range(3):
            off = [(off[i - 1] + 2 * off[i] + off[(i + 1) % N]) / 4 for i in range(N)]
        self.rlOff = off
        self.rlx = [self.cx[i] + self.nx[i] * off[i] for i in range(N)]
        self.rly = [self.cy[i] + self.ny[i] * off[i] for i in range(N)]
        # racing-line curvature via circumcircle of points i-3, i, i+3
        rk = []
        for i in range(N):
            ax, ay = self.rlx[i - 3], self.rly[i - 3]
            bx, by = self.rlx[i], self.rly[i]
            k = (i + 3) % N
            cx_, cy_ = self.rlx[k], self.rly[k]
            cross = (bx - ax) * (cy_ - by) - (by - ay) * (cx_ - bx)
            dab = math.hypot(bx - ax, by - ay)
            dbc = math.hypot(cx_ - bx, cy_ - by)
            dac = math.hypot(cx_ - ax, cy_ - ay)
            rk.append(2 * cross / max(1e-6, dab * dbc * dac))
        self.rlCurv = [(rk[i - 1] + rk[i] + rk[(i + 1) % N]) / 3 for i in range(N)]
        self.rlDs = [math.hypot(self.rlx[(i + 1) % N] - self.rlx[i],
                                self.rly[(i + 1) % N] - self.rly[i]) for i in range(N)]

    def buildSpeedProfile(self):
        N = self.n
        safety = 0.96
        v = []
        for i in range(N):
            k = abs(self.rlCurv[i])
            denom = k - LAT_DF * safety
            if denom <= 0:
                v.append(V_TOP)
            else:
                v.append(min(V_TOP, math.sqrt(LAT_BASE * safety / denom)))
        # braking (backwards) and acceleration (forwards) passes, twice
        # around the loop so the start/finish wrap is handled
        for _ in range(2):
            for i in range(N - 1, -1, -1):
                j = (i + 1) % N
                vb = math.sqrt(v[j] ** 2 + 2 * brakeDecel(v[j], 1.0) * 0.92 * self.rlDs[i])
                if vb < v[i]:
                    v[i] = vb
        for _ in range(2):
            for i in range(N):
                j = (i + 1) % N
                va = math.sqrt(v[i] ** 2 + 2 * max(0.5, engineAccel(v[i], False)) * self.rlDs[i])
                if va < v[j]:
                    v[j] = va
        self.vProf = v
        self.idealLap = sum(self.rlDs[i] / v[i] for i in range(N))
        # where kerbs go: corners
        self.kerb = [abs(self.curv[i]) > 0.012 or abs(self.curv[i - 2]) > 0.012
                     or abs(self.curv[(i + 2) % N]) > 0.012 for i in range(N)]

    def buildScenery(self):
        rnd = random.Random(7)
        self.trees = []
        tries = 0
        while len(self.trees) < 160 and tries < 4000:
            tries += 1
            i = rnd.randrange(self.n)
            side = rnd.choice((-1, 1))
            off = side * (WALL + rnd.uniform(6, 60))
            x, y = self.point(i, off)
            # must stay clear of every part of the circuit
            ok = True
            for k in range(0, self.n, 3):
                if (self.cx[k] - x) ** 2 + (self.cy[k] - y) ** 2 < (WALL + 4) ** 2:
                    ok = False
                    break
            if ok:
                self.trees.append((x, y, rnd.uniform(5, 9), rnd.choice((0, 1, 2))))
        # grandstands along the main straight (right/outside side)
        self.stands = []
        for s in range(0, 400, 50):
            i = int(s / DS) % self.n
            x, y = self.point(i, -(WALL + 6))
            self.stands.append((i, x, y))

    def nearestIndex(self, x, y, guess=None):
        N = self.n
        if guess is None:
            rng = range(N)
        else:
            rng = [(guess + k) % N for k in range(-6, 12)]
        best, bi = 1e18, 0
        for i in rng:
            d = (self.cx[i] - x) ** 2 + (self.cy[i] - y) ** 2
            if d < best:
                best, bi = d, i
        return bi


# --------------------------------------------------------------------------
# Car / tyre physics
# --------------------------------------------------------------------------

LAT_BASE = 14.0     # lateral grip (m/s^2) at zero speed
LAT_DF = 0.0034     # extra lateral grip per (m/s)^2 from downforce
BRAKE_BASE = 13.0
BRAKE_DF = 0.0036
POWER = 700.0       # "power over mass" (accel = POWER / v)
ERS_POWER = 170.0
TRACTION = 11.0
DRAG = 0.00085
V_TOP = 95.0
STEER_LOCK_R = 6.0  # minimum turning radius (m)
TRACK_TEMP = 38.0
FUEL_PER_LAP = 0.18

COMPOUNDS = {
    'S': {'name': 'SOFT', 'grip': 1.07, 'lo': 84, 'hi': 108, 'wear': 1.00, 'col': (230, 40, 40)},
    'M': {'name': 'MEDIUM', 'grip': 1.035, 'lo': 91, 'hi': 116, 'wear': 0.60, 'col': (250, 210, 40)},
    'H': {'name': 'HARD', 'grip': 1.00, 'lo': 99, 'hi': 126, 'wear': 0.36, 'col': (240, 240, 240)},
}


def engineAccel(v, ers):
    p = POWER + (ERS_POWER if ers else 0)
    return min(TRACTION, p / max(v, 1.0)) - DRAG * v * v - 0.15


def brakeDecel(v, grip):
    return (BRAKE_BASE + BRAKE_DF * v * v) * min(grip, 1.05)


def latGrip(v, grip):
    return (LAT_BASE + LAT_DF * v * v) * grip


class Car:
    def __init__(self, name, code, color, isPlayer=False):
        self.name, self.code = name, code
        self.color = color
        self.colRGB = rgb(*color)
        self.darkRGB = rgb(*(int(c * 0.6) for c in color))
        self.isPlayer = isPlayer
        self.ai = None
        self.resetTyres('M', 80)
        self.fuel = 1.0
        self.ers = 1.0

    def resetTyres(self, comp, temp):
        self.compound = comp
        self.temps = [temp] * 4       # FL, FR, RL, RR
        self.wear = [0.0] * 4

    def place(self, track, idx, lat, speed=0.0):
        self.idx = idx % track.n
        self.x, self.y = track.point(self.idx, lat)
        self.heading = math.atan2(track.ty[self.idx], track.tx[self.idx])
        self.v = speed
        self.steer = 0.0
        self.throttle = self.brake = 0.0
        self.usingErs = False
        self.slide = 0.0
        self.aLat = self.aLong = 0.0
        self.lat = lat
        self.sAlong = track.s[self.idx]
        self.crossings = 0
        self.passedHalf = True
        self.lapStart = None
        self.lapTimes = []
        self.lastLap = None
        self.bestLap = None
        self.lapValid = True
        self.offTrack = False
        self.surface = 'track'
        self.finished = False
        self.finishTime = None
        self.cp = {}
        self.lastCp = None
        self.cpIdx = self.idx // CP_EVERY
        self.stuckTime = 0.0
        self.crashFlash = 0.0
        self.visualYaw = 0.0
        self.updateTrackPos(track)

    # ---- tyres -----------------------------------------------------------
    def tyreGrip(self):
        c = COMPOUNDS[self.compound]
        tf = 0.0
        for T in self.temps:
            if T < c['lo']:
                d = c['lo'] - T
            elif T > c['hi']:
                d = T - c['hi']
            else:
                d = 0
            tf += max(0.72, 1 - 0.0085 * d)
        tf /= 4
        w = sum(self.wear) / 4
        wf = 1 - 0.30 * w - 0.9 * max(0.0, w - 0.65) ** 2
        return c['grip'] * tf * wf

    def massFactor(self):
        return 1.0 + 0.07 * self.fuel

    def updateTyres(self, dt):
        c = COMPOUNDS[self.compound]
        aLat, aLong = self.aLat, self.aLong
        work = abs(aLat) + 0.8 * abs(aLong) + 32 * self.slide
        latShare = clamp(abs(aLat) / 25, 0, 1) * 0.45
        outerRight = aLat > 0       # turning left loads the right side
        v = abs(self.v)
        offGrass = self.surface == 'grass'
        for k in range(4):
            front = k < 2
            right = k % 2 == 1
            share = 1.0
            share += latShare if right == outerRight else -latShare
            if aLong < 0:
                share += 0.3 if front else -0.2
            else:
                share += -0.1 if front else 0.2
            heat = 0.152 * work * share
            cool = (self.temps[k] - TRACK_TEMP) * (0.022 + 0.00036 * v)
            if offGrass:
                cool *= 1.6
            self.temps[k] += (heat - cool) * dt
            over = max(0.0, self.temps[k] - c['hi'])
            wearRate = 0.000085 * c['wear'] * work * share * (1 + 0.06 * over)
            self.wear[k] = min(1.0, self.wear[k] + wearRate * dt)

    # ---- dynamics ----------------------------------------------------------
    def maxYawRequest(self, v, grip):
        av = max(abs(v), 0.5)
        return min(av / STEER_LOCK_R, 1.12 * latGrip(av, grip) / av)

    def physics(self, dt, track, throttle, brake, steer, ers):
        self.throttle, self.brake = throttle, brake
        grip = self.tyreGrip() / self.massFactor()
        if self.surface == 'grass':
            grip *= 0.62
        elif self.surface == 'kerb':
            grip *= 0.96
        v = self.v
        # ERS
        self.usingErs = ers and self.ers > 0.01 and throttle > 0.5 and v > 8
        if self.usingErs:
            self.ers = max(0.0, self.ers - dt / 9.0)
        # longitudinal
        if brake > 0.05 and v > 0.5:
            a = -brakeDecel(v, grip) * brake / self.massFactor()
            self.ers = min(1.0, self.ers + dt * 0.12 * brake)
        elif brake > 0.05:
            a = -5.0 * brake if v > -9 else 0       # reverse gear
        else:
            a = throttle * engineAccel(max(v, 0), self.usingErs) / self.massFactor()
            if throttle < 0.05:
                a = -math.copysign(DRAG * v * v + 0.6, v)
        if self.surface == 'grass':
            a -= 0.014 * v * abs(v) + math.copysign(1.2, v)
        newV = v + a * dt
        if v > 0 and newV < 0:
            newV = 0.0          # stop before engaging reverse
        elif v < 0 and newV > 0 and brake < 0.05 and throttle < 0.05:
            newV = 0.0
        self.v = clamp(newV, -9.0, 110.0)
        self.aLong = a
        # lateral / steering
        yawMax = self.maxYawRequest(self.v, grip)
        yawReq = steer * yawMax * (1 if self.v >= 0 else -1)
        av = max(abs(self.v), 0.5)
        latReq = abs(yawReq) * av
        latMax = latGrip(av, grip)
        if latReq > latMax and av > 3:
            yaw = math.copysign(latMax / av, yawReq)
            self.slide = min(1.0, latReq / latMax - 1.0)
        else:
            yaw = yawReq
            self.slide = max(0.0, self.slide - dt * 3)
        if self.slide > 0 and self.v > 0:
            self.v = max(0.0, self.v - self.slide * 16 * dt)
        self.heading = wrapAngle(self.heading + yaw * dt)
        self.aLat = yaw * self.v
        self.visualYaw = lerp(self.visualYaw, clamp(steer * self.slide * 0.35, -0.3, 0.3), 0.2)
        self.x += math.cos(self.heading) * self.v * dt
        self.y += math.sin(self.heading) * self.v * dt
        self.updateTyres(dt)
        self.updateTrackPos(track)
        # barrier
        if abs(self.lat) > WALL - 1.0:
            side = 1 if self.lat > 0 else -1
            self.x, self.y = track.point(self.idx, side * (WALL - 1.2))
            th = math.atan2(track.ty[self.idx], track.tx[self.idx])
            rel = wrapAngle(self.heading - th)
            self.heading = wrapAngle(th + rel * 0.3)
            if self.v > 12:
                self.crashFlash = 1.0
            self.v *= 0.45
            self.updateTrackPos(track)

    def updateTrackPos(self, track):
        N = track.n
        prev = self.idx
        self.idx = track.nearestIndex(self.x, self.y, self.idx)
        i = self.idx
        dx, dy = self.x - track.cx[i], self.y - track.cy[i]
        self.lat = dx * track.nx[i] + dy * track.ny[i]
        self.sAlong = (track.s[i] + dx * track.tx[i] + dy * track.ty[i]) % track.length
        a = abs(self.lat)
        self.surface = 'track' if a <= HW else 'kerb' if a <= HW + CURB else 'grass'
        if a > HW + CURB + 0.6:
            self.offTrack = True
            self.lapValid = False
        else:
            self.offTrack = False
        if int(N * 0.45) <= i <= int(N * 0.55):
            self.passedHalf = True
        crossedForward = prev > N * 0.9 and i < N * 0.1
        crossedBack = prev < N * 0.1 and i > N * 0.9
        if crossedForward and self.passedHalf:
            self.crossings += 1
            self.passedHalf = False
        elif crossedBack:
            self.crossings -= 1
            self.passedHalf = True
        cpi = i // CP_EVERY
        if cpi != self.cpIdx:
            if cpi == (self.cpIdx + 1) % ((N - 1) // CP_EVERY + 1):
                key = self.crossings * 1000 + cpi
                if key not in self.cp and SESSION_CLOCK[0] is not None:
                    self.cp[key] = SESSION_CLOCK[0]
                    self.lastCp = key
            self.cpIdx = cpi

    @property
    def metric(self):
        return (self.crossings - 1) * TRACK.length + self.sAlong

    def wheelYaw(self):
        return self.steer * 0.35


CP_EVERY = 25
SESSION_CLOCK = [None]   # shared session time used for checkpoint stamps
TRACK = None


# --------------------------------------------------------------------------
# AI: A* planner on a track lattice + pure pursuit
# --------------------------------------------------------------------------

LANES = 9
PLAN_STEP = 2          # samples per lattice layer (8 m)
PLAN_LAYERS = 14       # ~112 m look-ahead
LINE_WEIGHT = 0.55
CAR_COST = 90.0


class BotDriver:
    def __init__(self, skill, aggression, rnd):
        self.skill = skill
        self.aggression = aggression
        self.rnd = rnd
        self.path = None
        self.planTimer = rnd.uniform(0, 0.15)
        self.reaction = rnd.uniform(0.15, 0.45)
        self.wantErs = False
        self.blockedAhead = None
        self.nodesExpanded = 0

    def plan(self, car, cars, track):
        """A* over (layer, lane). Layer k is PLAN_STEP*k samples ahead."""
        N = track.n
        lanes = track.lanes
        NL = len(lanes)
        start = car.idx
        startOff = clamp(car.lat, -track.maxOff, track.maxOff)
        stepLen = PLAN_STEP * DS
        horizon = PLAN_LAYERS * stepLen
        others = []
        myM = car.metric
        L = track.length
        for o in cars:
            if o is car:
                continue
            d = o.metric - myM
            d = (d + L / 2) % L - L / 2       # handle lapped cars
            if -10 < d < horizon + 30:
                others.append((d, o.lat, max(o.v, 0)))
        vSelf = max(car.v, 15.0)
        startKey = (0, -1)
        g = {startKey: 0.0}
        parent = {}
        heap = [(horizon, 0.0, 0, -1)]
        goal = None
        expanded = 0
        while heap:
            f, gc, k, j = heapq.heappop(heap)
            if gc > g.get((k, j), 1e18):
                continue
            expanded += 1
            if k == PLAN_LAYERS:
                goal = (k, j)
                break
            off = startOff if j < 0 else lanes[j]
            if j < 0:
                cand = range(NL)
                maxShift = 2.6
            else:
                cand = (j - 1, j, j + 1)
                maxShift = 99
            nk = k + 1
            idx = (start + nk * PLAN_STEP) % N
            along = nk * stepLen
            t = along / vSelf
            rl = track.rlOff[idx]
            for nj in cand:
                if nj < 0 or nj >= NL:
                    continue
                noff = lanes[nj]
                doff = noff - off
                if abs(doff) > maxShift:
                    continue
                cost = math.hypot(stepLen, doff)
                cost += LINE_WEIGHT * abs(noff - rl)
                for (od, olat, ov) in others:
                    pred = od + ov * t
                    gap = abs(pred - along)
                    if gap < 8.0 and abs(olat - noff) < 2.7:
                        cost += CAR_COST * (1.0 - gap / 10.0)
                ng = gc + cost
                key = (nk, nj)
                if ng < g.get(key, 1e18):
                    g[key] = ng
                    parent[key] = (k, j)
                    # admissible heuristic: every remaining layer costs >= stepLen
                    heapq.heappush(heap, (ng + (PLAN_LAYERS - nk) * stepLen, ng, nk, nj))
        self.nodesExpanded = expanded
        if goal is None:
            self.path = None
            return
        seq = []
        node = goal
        while node in parent:
            k, j = node
            seq.append((k, lanes[j]))
            node = parent[node]
        seq.reverse()
        pts = [(car.x, car.y)]
        for (k, off) in seq:
            pts.append(track.point(start + k * PLAN_STEP, off))
        self.path = pts
        self.pathOffs = [startOff] + [o for (_, o) in seq]

    def control(self, car, cars, track, dt, clock):
        self.planTimer -= dt
        if self.planTimer <= 0 or self.path is None:
            self.plan(car, cars, track)
            self.planTimer = 0.15
        if self.path is None:
            return 0.3, 0.0, 0.0, False
        v = max(car.v, 0.0)
        # ----- steering: pure pursuit on the A* path ---------------------
        Ld = clamp(0.42 * v, 9.0, 38.0)
        tx, ty = self.path[-1]
        acc = 0.0
        for k in range(1, len(self.path)):
            ax, ay = self.path[k - 1]
            bx, by = self.path[k]
            seg = math.hypot(bx - ax, by - ay)
            if acc + seg >= Ld:
                t = (Ld - acc) / max(seg, 1e-6)
                tx, ty = lerp(ax, bx, t), lerp(ay, by, t)
                break
            acc += seg
        # distance from the car to path start may differ a little; use direct angle
        alpha = wrapAngle(math.atan2(ty - car.y, tx - car.x) - car.heading)
        Lr = max(math.hypot(tx - car.x, ty - car.y), 1.0)
        desiredYaw = 2 * max(v, 3.0) * math.sin(alpha) / Lr
        grip = car.tyreGrip() / car.massFactor()
        steer = clamp(desiredYaw / car.maxYawRequest(max(v, 3.0), grip), -1, 1)
        # ----- speed: braking-aware profile ---------------------------------
        N = track.n
        gripScale = math.sqrt(grip / 1.0)
        target = 1e9
        for k in (1, 3, 6):
            target = min(target, track.vProf[(car.idx + k) % N])
        target *= self.skill * gripScale
        # penalise deviating from the racing line in corners
        dev = abs(car.lat - track.rlOff[car.idx])
        target *= 1 - 0.012 * dev * min(1.0, abs(track.rlCurv[car.idx]) * 60)
        # don't run into the car ahead if we could not find a way around
        self.blockedAhead = None
        myM = car.metric
        for o in cars:
            if o is car:
                continue
            d = (o.metric - myM + track.length / 2) % track.length - track.length / 2
            if 0 < d < 18 and abs(o.lat - car.lat) < 2.3:
                follow = o.v + (d - 7) * 0.6
                if follow < target:
                    target = follow
                    self.blockedAhead = o
        if car.surface == 'grass':
            target = min(target, 40)
        err = target - v
        if err > 0:
            throttle, brake = clamp(err / 2.5, 0.0, 1.0), 0.0
        else:
            throttle, brake = 0.0, clamp(-err / 3.0, 0.0, 1.0)
        # ERS on straights
        ahead = track.vProf[(car.idx + 20) % N]
        ers = throttle > 0.9 and v > 35 and ahead > v + 8 and car.ers > 0.25 * (1.2 - self.aggression)
        # stuck recovery
        if v < 2.0 and clock > 3:
            car.stuckTime += dt
        else:
            car.stuckTime = 0.0
        if car.stuckTime > 2.5:
            car.x, car.y = track.point(car.idx + 3, track.rlOff[(car.idx + 3) % N])
            car.heading = math.atan2(track.ty[(car.idx + 3) % N], track.tx[(car.idx + 3) % N])
            car.v = 5.0
            car.stuckTime = 0.0
            car.updateTrackPos(track)
            self.path = None
        return throttle, brake, steer, ers


# --------------------------------------------------------------------------
# Field of drivers (fictional)
# --------------------------------------------------------------------------

DRIVERS = [
    ('Viktor Halden', 'HAL', (30, 70, 200)),
    ('Marco Bellini', 'BEL', (200, 20, 30)),
    ('Kenji Arata', 'ARA', (0, 170, 150)),
    ('Lucas Ferreira', 'FER', (255, 130, 0)),
    ('Oskar Lind', 'LIN', (0, 110, 60)),
    ('Theo Marchand', 'MAR', (240, 100, 180)),
    ('Sam Okafor', 'OKA', (120, 120, 135)),
]
PLAYER_COLOR = (255, 190, 0)
DIFFICULTY = {
    'EASY': 0.875,
    'MEDIUM': 0.925,
    'HARD': 0.965,
}
RACE_LAPS = 5
QUALI_LAPS = 3


def buildField(app):
    rnd = random.Random()
    cars = []
    player = Car('You', 'YOU', PLAYER_COLOR, isPlayer=True)
    cars.append(player)
    base = DIFFICULTY[app.difficulty]
    for k, (name, code, col) in enumerate(DRIVERS):
        c = Car(name, code, col)
        skill = base + 0.03 - k * 0.0085 + rnd.uniform(-0.006, 0.006)
        c.ai = BotDriver(min(0.995, skill), rnd.uniform(0.3, 1.0), rnd)
        c.raceCompound = rnd.choice(['S', 'M', 'M', 'H', 'H'])
        cars.append(c)
    return player, cars


# --------------------------------------------------------------------------
# Simulation of a session
# --------------------------------------------------------------------------


def stepCar(app, car, dt, cars, clock, frozen=False):
    if frozen:
        car.updateTyres(dt)
        return
    if car.isPlayer and not car.finished and not app.autopilot:
        k = app.keys | app.joyKeys
        throttle = 1.0 if ('up' in k or 'w' in k) else 0.0
        brake = 1.0 if ('down' in k or 's' in k) else 0.0
        # left stick / D-pad: analog throttle (up) and brake (down)
        sy = app.joyAxes[1]
        throttle = max(throttle, stickAmount(-sy))
        brake = max(brake, stickAmount(sy))
        left = 'left' in k or 'a' in k
        right = 'right' in k or 'd' in k
        target = (1 if left else 0) - (1 if right else 0)
        sx = app.joyAxes[0]
        if target == 0 and abs(sx) > JOY_DEADZONE:
            # analog steering: positive steer is to the left
            target = -math.copysign(stickAmount(abs(sx)), sx)
        rate = 3.2 if target != 0 else 6.0
        if target != 0 and car.steer * target < 0:
            rate = 7.0
        car.steer += clamp(target - car.steer, -rate * dt, rate * dt)
        ers = 'space' in k
        car.physics(dt, TRACK, throttle, brake, car.steer, ers)
    else:
        if car.ai is None:      # autopilot / finished player: the AI drives
            car.ai = BotDriver(0.9, 0.5, random.Random())
        th, br, st, ers = car.ai.control(car, cars, TRACK, dt, clock)
        car.steer += clamp(st - car.steer, -8 * dt, 8 * dt)
        car.physics(dt, TRACK, th, br, car.steer, ers)


JOY_DEADZONE = 0.15


def stickAmount(v):
    """Map a stick value in [-1, 1] to [0, 1] in its positive direction,
    with a dead zone so a resting stick reads as 0."""
    if v <= JOY_DEADZONE:
        return 0.0
    return clamp((v - JOY_DEADZONE) / (1 - JOY_DEADZONE), 0.0, 1.0)


def resolveCollisions(cars):
    n = len(cars)
    for a in range(n):
        A = cars[a]
        for b in range(a + 1, n):
            B = cars[b]
            dx, dy = B.x - A.x, B.y - A.y
            if abs(dx) > 7 or abs(dy) > 7:
                continue
            # two circles per car along its heading
            for (ax, ay) in carCircles(A):
                for (bx, by) in carCircles(B):
                    ddx, ddy = bx - ax, by - ay
                    d = math.hypot(ddx, ddy)
                    if 0 < d < 2.0:
                        push = (2.0 - d) / 2
                        ux, uy = ddx / d, ddy / d
                        A.x -= ux * push
                        A.y -= uy * push
                        B.x += ux * push
                        B.y += uy * push
                        # exchange some speed - the one behind is slowed
                        ha = (math.cos(A.heading), math.sin(A.heading))
                        if ux * ha[0] + uy * ha[1] > 0.3:     # B is ahead of A
                            if A.v > B.v:
                                dv = A.v - B.v
                                A.v -= dv * 0.6
                                B.v += dv * 0.2
                        else:
                            hb = (math.cos(B.heading), math.sin(B.heading))
                            if -(ux * hb[0] + uy * hb[1]) > 0.3 and B.v > A.v:
                                dv = B.v - A.v
                                B.v -= dv * 0.6
                                A.v += dv * 0.2


def carCircles(c):
    ch, sh = math.cos(c.heading), math.sin(c.heading)
    return ((c.x + ch * 1.4, c.y + sh * 1.4), (c.x - ch * 1.4, c.y - sh * 1.4))


def standings(cars):
    def key(c):
        if c.finished:
            return (0, -c.crossings, c.finishTime)
        return (1, -c.metric, 0)
    return sorted(cars, key=key)


def gapToLeader(car, leader):
    if car is leader:
        return 0.0
    if car.lastCp is None:
        return None
    t1 = car.cp.get(car.lastCp)
    t0 = leader.cp.get(car.lastCp)
    if t0 is None or t1 is None:
        return None
    return t1 - t0


def simulateBotQualiLap(car, track):
    """Generator: drives a bot alone on a flying lap. Yields after each chunk."""
    car.resetTyres('S', 92)
    car.fuel = 0.1
    car.ers = 1.0
    car.place(track, track.n - 70, track.rlOff[track.n - 70], track.vProf[track.n - 70] * 0.9)
    car.ai.path = None
    t = 0.0
    dt = 1 / 60
    started = None
    steps = 0
    saveClock = SESSION_CLOCK[0]
    while t < 200:
        SESSION_CLOCK[0] = None
        before = car.crossings
        th, br, st, ers = car.ai.control(car, [car], track, dt, 10.0)
        car.steer += clamp(st - car.steer, -8 * dt, 8 * dt)
        car.physics(dt, track, th, br, car.steer, ers)
        t += dt
        if car.crossings != before:
            if started is None:
                started = t
                car.lapValid = True
            else:
                lap = t - started
                car.qualiTime = lap * (1 + car.ai.rnd.uniform(-0.002, 0.004))
                SESSION_CLOCK[0] = saveClock
                return
        steps += 1
        if steps % 40 == 0:
            SESSION_CLOCK[0] = saveClock
            yield
    car.qualiTime = 999.0
    SESSION_CLOCK[0] = saveClock


def qualiGenerator(bots, track):
    for b in bots:
        yield from simulateBotQualiLap(b, track)


# --------------------------------------------------------------------------
# App state & session flow
# --------------------------------------------------------------------------


def onAppStart(app):
    global TRACK
    app.stepsPerSecond = 1000
    # The game state (cars, track, AI plans) is large; hashing all of it
    # twice per frame to verify MVC purity would halve the frame rate.
    app.disableMvcChecker = True
    if TRACK is None:
        TRACK = Track()
    app.track = TRACK
    app.keys = set()
    app.joyKeys = set()        # keys currently held down via the joystick
    app.joyHeld = dict()       # button -> key it is holding in app.joyKeys
    app.joyAxes = [0.0, 0.0, 0.0, 0.0]
    app.joyDirs = set()        # digital stick/D-pad directions last step
    app.difficulty = 'MEDIUM'
    app.raceCompound = 'M'
    app.mode = 'menu'
    app.paused = False
    app.camMode = 0
    app.lastTime = time.time()
    app.messages = []
    app.menuT = 0.0
    app.fps = 60
    app.fpsAcc = [0, time.time()]
    buildStaticColors(app)
    buildMinimap(app)
    app.compRGB = {k: rgb(*c['col']) for k, c in COMPOUNDS.items()}
    app.autopilot = False      # X: let the AI drive your car
    app.realT = 0.0
    # Skip the title screen: go straight to qualifying with the defaults
    # (MEDIUM difficulty, MEDIUM race tyres).
    startQualifying(app)


def startQualifying(app):
    app.player, app.cars = buildField(app)
    p = app.player
    p.resetTyres('S', 85)
    p.fuel = 0.1
    p.place(TRACK, TRACK.n - 45, 0.0, 0.0)
    p.qualiTime = None
    p.timedLaps = 0
    app.mode = 'quali'
    app.clock = 0.0
    app.paused = False
    SESSION_CLOCK[0] = 0.0
    app.camYaw = p.heading
    app.qualiGen = qualiGenerator(app.cars[1:], TRACK)
    app.qualiGenDone = False
    app.messages = []
    addMsg(app, 'QUALIFYING - set your fastest lap', 4)
    addMsg(app, 'Best of 3 timed laps. Stay inside the kerbs!', 4)


def advanceQualiSim(app, chunks):
    if app.qualiGenDone:
        return
    for _ in range(chunks):
        try:
            next(app.qualiGen)
        except StopIteration:
            app.qualiGenDone = True
            return


def finishQualifying(app):
    while not app.qualiGenDone:
        advanceQualiSim(app, 50)
    p = app.player
    if p.qualiTime is None:
        p.qualiTime = 999.0
    app.qualiOrder = sorted(app.cars, key=lambda c: c.qualiTime)
    app.mode = 'qualiResults'


def startRace(app):
    T = TRACK
    order = app.qualiOrder
    for pos, c in enumerate(order):
        back = 14 + pos * 9.0
        idx = int((T.length - back) / DS) % T.n
        lat = 3.0 if pos % 2 == 0 else -3.0
        c.place(T, idx, lat, 0.0)
        c.passedHalf = True
        c.fuel = 1.0
        c.ers = 1.0
        if c.isPlayer:
            c.resetTyres(app.raceCompound, 82)
            c.ai = None
        else:
            c.resetTyres(c.raceCompound, 82)
            c.ai.path = None
            c.ai.planTimer = random.uniform(0, 0.15)
        c.gridPos = pos + 1
    app.mode = 'race'
    app.clock = 0.0
    app.lightsT = 0.0
    app.lightsOutAt = 5.7 + random.uniform(0.2, 1.5)
    app.raceStarted = False
    SESSION_CLOCK[0] = None
    app.camYaw = app.player.heading
    app.messages = []
    app.raceOver = False
    app.prevPos = order.index(app.player) + 1


def addMsg(app, text, dur=2.5, color='white'):
    app.messages.append([text, dur, color])
    app.messages = app.messages[-3:]


def onKeyPress(app, key):
    k = key.lower()
    app.keys.add(k)
    if app.mode == 'menu':
        if k in ('1', '2', '3'):
            app.difficulty = ['EASY', 'MEDIUM', 'HARD'][int(k) - 1]
        elif k in ('s', 'm', 'h'):
            app.raceCompound = k.upper()
        elif k == 'enter' or k == 'space':
            startQualifying(app)
    elif app.mode in ('quali', 'race'):
        if k == 'p':
            app.paused = not app.paused
        elif k == 'c':
            app.camMode = (app.camMode + 1) % 3
        elif k == 'x':
            app.autopilot = not app.autopilot
            addMsg(app, 'AI is driving your car (X to take over)' if app.autopilot
                   else 'You have control', 2.5, rgb(80, 200, 255))
        elif k == 'escape':
            app.mode = 'menu'
        elif k == 'r':
            resetPlayer(app)
        elif k == 'f' and app.mode == 'quali' and app.player.qualiTime is not None:
            finishQualifying(app)
    elif app.mode == 'qualiResults':
        if k == 'enter' or k == 'space':
            startRace(app)
        elif k == 'escape':
            app.mode = 'menu'
    elif app.mode == 'raceResults':
        if k in ('enter', 'space', 'escape'):
            app.mode = 'menu'


def onKeyRelease(app, key):
    app.keys.discard(key.lower())


# --------------------------------------------------------------------------
# Joystick input: buttons are translated into the same key names the
# keyboard uses, so the game logic in onKeyPress / stepCar handles both.
# --------------------------------------------------------------------------

# R36S buttons: '0' B, '1' A, '2' X, '3' Y, '4' L1, '5' R1, '6' L2, '7' R2,
# '8' Select, '9' Start.  'H0'..'H3' are D-pad hats on other controllers.
JOY_HOLD_KEYS = {'1': 'up', '7': 'up',          # A / R2: throttle
                 '0': 'down', '6': 'down',      # B / L2: brake
                 '5': 'space',                  # R1: ERS
                 'H0': 'up', 'H2': 'down', 'H3': 'left', 'H1': 'right'}
JOY_PRESS_KEYS = {'3': 'c',     # Y: camera
                  '2': 'x',     # X: autopilot
                  '4': 'r'}     # L1: reset car


def joyButtonKey(app, button):
    """The keyboard key a joystick button stands for right now."""
    if button == '9':                                   # Start
        return 'p' if app.mode in ('quali', 'race') else 'enter'
    if button == '8':                                   # Select
        if app.mode in ('quali', 'race'):
            if app.paused:
                return 'escape'
            return 'f' if app.mode == 'quali' else None
        return 'escape' if app.mode != 'menu' else None
    if button == '1' and app.mode not in ('quali', 'race'):
        return 'enter'                                  # A also confirms
    return JOY_HOLD_KEYS.get(button) or JOY_PRESS_KEYS.get(button)


def menuNav(app, dx, dy):
    """D-pad in the menu: left/right picks difficulty, up/down the tyre."""
    if app.mode != 'menu':
        return
    if dx != 0:
        levels = ['EASY', 'MEDIUM', 'HARD']
        i = levels.index(app.difficulty)
        app.difficulty = levels[clamp(i + dx, 0, 2)]
    if dy != 0:
        comps = ['S', 'M', 'H']
        i = comps.index(app.raceCompound)
        app.raceCompound = comps[clamp(i + dy, 0, 2)]


def onJoyPress(app, button, joystick):
    hats = {'H0': (0, -1), 'H2': (0, 1), 'H3': (-1, 0), 'H1': (1, 0)}
    if app.mode == 'menu' and button in hats:
        menuNav(app, *hats[button])
        return
    key = joyButtonKey(app, button)
    if key is None:
        return
    if button in JOY_HOLD_KEYS and app.mode in ('quali', 'race'):
        app.joyHeld[button] = key
        app.joyKeys.add(key)
    else:
        onKeyPress(app, key)
        app.keys.discard(key)   # a tap, not a held key


def onJoyRelease(app, button, joystick):
    key = app.joyHeld.pop(button, None)
    if key is not None and key not in app.joyHeld.values():
        app.joyKeys.discard(key)


def onJoyAxis(app, value, axis, joystick):
    if 0 <= axis < len(app.joyAxes):
        app.joyAxes[axis] = value


def onDigitalJoyAxis(app, directions, joystick):
    # Only react to newly pushed directions, so holding the stick moves the
    # menu selection one step at a time.
    dirs = set(directions)
    for (axis, value) in dirs - app.joyDirs:
        if axis == 0:
            menuNav(app, value, 0)
        elif axis == 1:
            menuNav(app, 0, value)
    app.joyDirs = dirs


def resetPlayer(app):
    p = app.player
    T = TRACK
    i = (p.idx + 2) % T.n
    p.x, p.y = T.point(i, 0)
    p.heading = math.atan2(T.ty[i], T.tx[i])
    p.v = 0
    p.lapValid = False if app.mode == 'quali' else p.lapValid
    p.updateTrackPos(T)
    addMsg(app, 'Car reset to track', 2, 'orange')


def onStep(app):
    now = time.time()
    dt = clamp(now - app.lastTime, 0.0, 1 / 20)
    app.lastTime = now
    app.realT += dt
    app.fpsAcc[0] += 1
    if now - app.fpsAcc[1] > 1:
        app.fps = app.fpsAcc[0] / (now - app.fpsAcc[1])
        app.fpsAcc = [0, now]
    app.menuT += dt
    for m in app.messages:
        m[1] -= dt
    app.messages = [m for m in app.messages if m[1] > 0]
    if app.paused:
        return
    if app.mode == 'quali':
        stepQuali(app, dt)
    elif app.mode == 'race':
        stepRace(app, dt)


def substeps(dt):
    n = max(1, int(math.ceil(dt / (1 / 60))))
    return n, dt / n


def stepQuali(app, dt):
    p = app.player
    n, h = substeps(dt)
    for _ in range(n):
        app.clock += h
        SESSION_CLOCK[0] = app.clock
        before = p.crossings
        stepCar(app, p, h, [p], app.clock)
        if p.crossings > before:
            if p.lapStart is not None:
                lap = app.clock - p.lapStart
                p.timedLaps += 1
                if p.lapValid:
                    p.lastLap = lap
                    if p.qualiTime is None or lap < p.qualiTime:
                        p.qualiTime = lap
                        addMsg(app, f'PERSONAL BEST  {fmtTime(lap)}', 3, rgb(180, 90, 255))
                    else:
                        addMsg(app, f'Lap {fmtTime(lap)}', 3)
                else:
                    p.lastLap = lap
                    addMsg(app, f'Lap {fmtTime(lap)} DELETED (track limits)', 3, 'red')
                if p.timedLaps >= QUALI_LAPS:
                    finishQualifying(app)
                    return
            p.lapStart = app.clock
            p.lapValid = True
        if p.offTrack and p.lapStart is not None and not getattr(p, 'warned', False):
            addMsg(app, 'TRACK LIMITS - lap will be deleted', 2.5, 'red')
            p.warned = True
        if not p.offTrack:
            p.warned = False
    advanceQualiSim(app, 2)
    updateCamera(app, dt)


def stepRace(app, dt):
    p = app.player
    cars = app.cars
    if not app.raceStarted:
        app.lightsT += dt
        for c in cars:
            stepCar(app, c, dt, cars, 0, frozen=True)
            # revving: hold the brake for the player
        if app.lightsT >= app.lightsOutAt:
            app.raceStarted = True
            app.clock = 0.0
            SESSION_CLOCK[0] = 0.0
            addMsg(app, "LIGHTS OUT AND AWAY WE GO!", 3, rgb(120, 255, 120))
            for c in cars:
                c.lapStart = None
        updateCamera(app, dt)
        return
    n, h = substeps(dt)
    for _ in range(n):
        app.clock += h
        SESSION_CLOCK[0] = app.clock
        leaderDone = any(c.finished for c in cars)
        for c in cars:
            if c.ai is not None and app.clock < c.ai.reaction and not c.isPlayer:
                c.updateTyres(h)
                continue
            before = c.crossings
            stepCar(app, c, h, cars, app.clock)
            if c.crossings > before and not c.finished:
                if c.lapStart is not None:
                    lap = app.clock - c.lapStart
                    c.lastLap = lap
                    c.lapTimes.append(lap)
                    if c.bestLap is None or lap < c.bestLap:
                        c.bestLap = lap
                    c.fuel = max(0.0, c.fuel - FUEL_PER_LAP)
                    if c.isPlayer:
                        addMsg(app, f'Lap {len(c.lapTimes)}: {fmtTime(lap)}', 3)
                c.lapStart = app.clock
                if c.crossings > RACE_LAPS or (leaderDone and c.crossings > 1):
                    c.finished = True
                    c.finishTime = app.clock
                    if c.isPlayer:
                        endRace(app)
                        return
                elif c.isPlayer and c.crossings == RACE_LAPS:
                    addMsg(app, 'FINAL LAP!', 3, rgb(255, 220, 60))
        resolveCollisions(cars)
    pos = standings(cars).index(p) + 1
    if pos != app.prevPos:
        if pos < app.prevPos:
            addMsg(app, f'Up to P{pos}', 2, rgb(120, 255, 120))
        else:
            addMsg(app, f'Down to P{pos}', 2, rgb(255, 120, 120))
        app.prevPos = pos
    if p.crashFlash > 0:
        if p.crashFlash == 1.0:
            addMsg(app, 'Contact with the barrier!', 2, 'orange')
        p.crashFlash = max(0.0, p.crashFlash - dt * 2)
    updateCamera(app, dt)


def endRace(app):
    cars = app.cars
    order = standings(cars)
    leader = order[0]
    res = []
    lastGap = 0.0
    for c in order:
        if c.finished:
            if c is leader:
                gap = fmtTime(c.finishTime)
            elif c.crossings < leader.crossings:
                laps = leader.crossings - c.crossings
                gap = f'+{laps} LAP' + ('S' if laps > 1 else '')
            else:
                lastGap = c.finishTime - leader.finishTime
                gap = f'+{lastGap:.3f}s'
        else:
            deficit = (leader.crossings - 1) * TRACK.length - c.metric
            if deficit > TRACK.length:
                gap = f'+{int(deficit // TRACK.length)} LAP'
            else:
                est = deficit / max(30.0, abs(c.v) * 0.9) + (app.clock - leader.finishTime)
                est = max(est, lastGap + 0.1)
                lastGap = est
                gap = f'+{est:.3f}s'
        res.append((c, gap))
    app.results = res
    app.mode = 'raceResults'


# --------------------------------------------------------------------------
# Camera & projection (2.5D)
# --------------------------------------------------------------------------

CAMS = [  # height, distance behind, focal, horizon  (in pixels)
    (3.0, 7.8, 380, 188),
    (5.5, 14.0, 380, 168),
    (1.1, -1.6, 350, 240),   # cockpit / T-cam
]
NEAR = 0.6


def updateCamera(app, dt):
    p = app.player
    target = p.heading if p.v >= -0.5 else p.heading
    d = wrapAngle(target - app.camYaw)
    app.camYaw = wrapAngle(app.camYaw + d * clamp(dt * 7.0, 0, 1))


class Cam:
    def __init__(self, app):
        H, D, F, hor = CAMS[app.camMode]
        p = app.player
        self.yaw = app.camYaw
        self.c, self.s = math.cos(self.yaw), math.sin(self.yaw)
        self.x = p.x - self.c * D
        self.y = p.y - self.s * D
        self.h, self.F, self.hor = H, F, hor
        self.cx = WIDTH / 2

    def toCam(self, x, y, z=0.0):
        dx, dy = x - self.x, y - self.y
        return (dx * self.s - dy * self.c, dx * self.c + dy * self.s, z)

    def proj(self, r, f, z):
        k = self.F / f
        return (self.cx + r * k, self.hor + (self.h - z) * k)

    def polygon(self, camPts, fill, opacity=100):
        pts = clipNear(camPts)
        if len(pts) < 3:
            return
        flat = []
        minx = miny = 1e9
        maxx = maxy = -1e9
        F, cx, hor, h = self.F, self.cx, self.hor, self.h
        for (r, f, z) in pts:
            k = F / f
            sx = cx + r * k
            sy = hor + (h - z) * k
            if sx < minx: minx = sx
            if sx > maxx: maxx = sx
            if sy < miny: miny = sy
            if sy > maxy: maxy = sy
            flat.append(clamp(sx, -4000, 5000))
            flat.append(clamp(sy, -4000, 5000))
        if maxx < 0 or minx > WIDTH or maxy < 0 or miny > HEIGHT:
            return
        drawPolygon(*flat, fill=fill, opacity=opacity)


def clipNear(poly):
    allIn = True
    for p in poly:
        if p[1] < NEAR:
            allIn = False
            break
    if allIn:
        return poly
    out = []
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        ain = a[1] >= NEAR
        bin_ = b[1] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[1]) / (b[1] - a[1])
            out.append((a[0] + t * (b[0] - a[0]), NEAR, a[2] + t * (b[2] - a[2])))
    return out


def buildStaticColors(app):
    app.colSky = gradient(rgb(70, 130, 210), rgb(170, 205, 240), start='top')
    app.colGrass = rgb(58, 128, 52)
    app.colGrass2 = rgb(66, 140, 58)
    app.colRunoff = [rgb(72, 148, 62), rgb(64, 136, 56)]
    app.colRoad = [rgb(78, 80, 86), rgb(86, 88, 94)]
    app.colKerb = [rgb(220, 30, 30), rgb(245, 245, 245)]
    app.colLine = rgb(235, 235, 235)
    app.colWall = [rgb(30, 60, 160), rgb(235, 235, 235)]
    app.colWallTop = rgb(180, 180, 190)
    app.colMount = rgb(96, 120, 150)
    app.colMount2 = rgb(120, 146, 170)
    app.colTree = [rgb(30, 90, 40), rgb(40, 110, 45), rgb(25, 80, 50)]
    app.colTrunk = rgb(90, 60, 30)
    app.colTyre = rgb(22, 22, 24)
    app.colTyreSide = rgb(45, 45, 48)
    app.colCarbon = rgb(35, 35, 40)
    app.colShadow = rgb(20, 20, 20)
    app.colHelmet = rgb(250, 210, 40)
    app.colStand = rgb(150, 150, 160)
    app.colStandRoof = rgb(200, 40, 40)
    app.colCrowd = [rgb(200, 60, 60), rgb(60, 60, 200), rgb(230, 200, 60), rgb(240, 240, 240)]


# --------------------------------------------------------------------------
# Rendering the world
# --------------------------------------------------------------------------

CHUNK = 4      # samples per drawing chunk


def drawWorld(app):
    cam = Cam(app)
    T = TRACK
    N = T.n
    # sky and distant hills
    drawRect(0, 0, WIDTH, cam.hor + 2, fill=app.colSky)
    drawHills(app, cam)
    drawRect(0, cam.hor, WIDTH, HEIGHT - cam.hor, fill=app.colGrass)

    halfFov = (WIDTH / 2) / cam.F
    chunks = []
    for c0 in range(0, N, CHUNK):
        mid = (c0 + CHUNK // 2) % N
        r, f, _ = cam.toCam(T.cx[mid], T.cy[mid])
        if f < -30 or f > 900:
            continue
        if abs(r) > f * halfFov + 45:
            continue
        chunks.append((f, c0))
    chunks.sort(reverse=True)

    roadL, roadR = T.edges[HW]
    kerbL, kerbR = T.edges[HW + CURB]
    runL, runR = T.edges[HW + 2.5]
    wallL, wallR = T.edges[WALL]
    toCam = cam.toCam
    vertical = []     # (depth, kind, data) - drawn after the ground, far to near
    for (f, c0) in chunks:
        if f < 50:
            step = 1
        elif f < 160:
            step = 2
        elif f < 380:
            step = 4
        else:
            # far away: one quad covers two chunks
            if (c0 // CHUNK) % 2 == 1:
                continue
            step = 2 * CHUNK
        par = (c0 // CHUNK) % 2
        # runoff band (lighter grass) - only when close
        if f < 160:
            i, j = c0 % N, (c0 + CHUNK) % N
            cam.polygon([toCam(*runL[i]), toCam(*runL[j]), toCam(*runR[j]), toCam(*runR[i])],
                        app.colRunoff[par])
        for s in range(c0, c0 + max(CHUNK, step), step):
            i, j = s % N, (s + step) % N
            cam.polygon([toCam(*roadL[i]), toCam(*roadL[j]), toCam(*roadR[j]), toCam(*roadR[i])],
                        app.colRoad[par])
        # kerbs in corners
        if f < 220:
            ks = 1 if f < 70 else 2
            for s in range(c0, c0 + CHUNK, ks):
                i, j = s % N, (s + ks) % N
                if not T.kerb[i]:
                    continue
                col = app.colKerb[(s // ks) % 2]
                cam.polygon([toCam(*roadL[i]), toCam(*roadL[j]), toCam(*kerbL[j]), toCam(*kerbL[i])], col)
                cam.polygon([toCam(*roadR[i]), toCam(*roadR[j]), toCam(*kerbR[j]), toCam(*kerbR[i])], col)
        # barriers are vertical: draw later depth-sorted
        if f < 260:
            vertical.append((f + 1.0, 'wall', c0))
    # start / finish line
    drawStartLine(app, cam)
    # scenery
    for (x, y, size, kind) in T.trees:
        r, f, _ = toCam(x, y)
        if NEAR + 2 < f < 300 and abs(r) < f * halfFov + 10:
            vertical.append((f, 'tree', (r, f, size, kind)))
    for (i, x, y) in T.stands:
        r, f, _ = toCam(x, y)
        if NEAR + 4 < f < 500 and abs(r) < f * halfFov + 40:
            vertical.append((f, 'stand', i))
    for c in (app.cars if app.mode == 'race' else [app.player]):
        r, f, _ = toCam(c.x, c.y)
        if c.isPlayer and app.camMode == 2:
            continue
        if c.isPlayer or (-4 < f < 450 and abs(r) < f * halfFov + 6):
            vertical.append((f, 'car', c))
    vertical.sort(key=lambda e: -e[0])
    for (f, kind, data) in vertical:
        if kind == 'wall':
            drawWallChunk(app, cam, data, f)
        elif kind == 'tree':
            drawTree(app, cam, data)
        elif kind == 'stand':
            drawStand(app, cam, data)
        else:
            drawCar(app, cam, data, f)
    if app.camMode == 2:
        drawCockpit(app)


def drawCockpit(app):
    p = app.player
    col = p.colRGB
    W, H, cx = WIDTH, HEIGHT, WIDTH / 2
    # front tyres poking into view, turning with the steering
    st = p.steer * 18
    for sx in (100, W - 100):
        drawRect(sx, H - 96, 74, 120, fill=app.colTyre, align='center', rotateAngle=-st)
    # nose and cockpit sides
    drawPolygon(cx - 27, H - 120, cx + 27, H - 120, cx + 100, H, cx - 100, H, fill=col)
    drawPolygon(0, H - 32, 173, H - 72, 220, H, 0, H, fill=p.darkRGB)
    drawPolygon(W, H - 32, W - 173, H - 72, W - 220, H, W, H, fill=p.darkRGB)
    # halo
    drawRect(cx - 6, 240, 12, H - 240, fill=app.colCarbon)
    drawPolygon(cx - 153, H, cx - 133, 264, cx + 133, 264, cx + 153, H,
                cx + 137, H, cx + 120, 280, cx - 120, 280, cx - 137, H,
                fill=app.colCarbon)
    # steering wheel
    drawRect(cx, H - 32, 154, 56, fill=rgb(25, 25, 28), align='center', rotateAngle=p.steer * 60)
    drawLabel(f'{abs(p.v) * 3.6:.0f}', cx, H - 38, size=14, bold=True, fill=rgb(120, 255, 140),
              rotateAngle=p.steer * 60)


def drawHills(app, cam):
    pts = []
    for sx in range(-40, WIDTH + 81, 40):
        ang = cam.yaw - math.atan((sx - cam.cx) / cam.F)
        h = 0.75 * (28 + 18 * math.sin(ang * 3) + 12 * math.sin(ang * 7 + 1.3) + 6 * math.sin(ang * 13))
        pts += [sx, cam.hor - h]
    drawPolygon(*pts, WIDTH + 40, cam.hor + 2, -40, cam.hor + 2, fill=app.colMount)
    pts = []
    for sx in range(-40, WIDTH + 81, 40):
        ang = cam.yaw - math.atan((sx - cam.cx) / cam.F)
        h = 0.75 * (12 + 9 * math.sin(ang * 5 + 2) + 5 * math.sin(ang * 11))
        pts += [sx, cam.hor - h]
    drawPolygon(*pts, WIDTH + 40, cam.hor + 2, -40, cam.hor + 2, fill=app.colMount2)


def drawStartLine(app, cam):
    T = TRACK
    # checkered start line: 2 rows of squares at sample 0
    i = 0
    r, f, _ = cam.toCam(T.cx[i], T.cy[i])
    if not (-5 < f < 300):
        return
    tx, ty, nx, ny = T.tx[i], T.ty[i], T.nx[i], T.ny[i]
    squares = 7 if f < 120 else 3
    w = 2 * HW / squares
    for row in range(2):
        for k in range(squares):
            if (k + row) % 2 == 0 and squares == 7:
                continue
            a = -HW + k * w
            b = a + w
            d0, d1 = row * 1.0, row * 1.0 + 1.0
            pts = []
            for (lat, al) in ((a, d0), (b, d0), (b, d1), (a, d1)):
                pts.append(cam.toCam(T.cx[i] + nx * lat + tx * al, T.cy[i] + ny * lat + ty * al))
            cam.polygon(pts, 'white' if squares == 7 else rgb(200, 200, 200))
        if squares == 3:
            break


def drawWallChunk(app, cam, c0, f):
    T = TRACK
    N = T.n
    wallL, wallR = T.edges[WALL]
    step = 2 if f < 60 else 4
    for s in range(c0, c0 + CHUNK, step):
        i, j = s % N, (s + step) % N
        col = app.colWall[(s // step) % 2] if f < 60 else app.colWall[0]
        for side in (wallL, wallR):
            a = cam.toCam(*side[i])
            b = cam.toCam(*side[j])
            cam.polygon([(a[0], a[1], 0), (b[0], b[1], 0), (b[0], b[1], 1.1), (a[0], a[1], 1.1)], col)


def drawTree(app, cam, data):
    r, f, size, kind = data
    k = cam.F / f
    sx = cam.cx + r * k
    base = cam.hor + cam.h * k
    top = cam.hor + (cam.h - size) * k
    w = size * 0.45 * k
    tw = max(1, 0.35 * k)
    if f < 90:
        drawRect(sx - tw / 2, base - (base - top) * 0.3, tw, (base - top) * 0.3, fill=app.colTrunk)
    drawPolygon(sx, top, sx + w, base - (base - top) * 0.22, sx - w, base - (base - top) * 0.22,
                fill=app.colTree[kind])


def drawStand(app, cam, i):
    T = TRACK
    N = T.n
    a = T.point(i - 5, -(WALL + 4))
    b = T.point(i + 5, -(WALL + 4))
    a2 = T.point(i - 5, -(WALL + 14))
    b2 = T.point(i + 5, -(WALL + 14))
    A, B = cam.toCam(*a), cam.toCam(*b)
    A2, B2 = cam.toCam(*a2), cam.toCam(*b2)
    # sloped seating: front low, back high
    cam.polygon([(A[0], A[1], 1.5), (B[0], B[1], 1.5), (B2[0], B2[1], 9), (A2[0], A2[1], 9)], app.colStand)
    if A[1] < 90:
        for row in range(3):
            z0 = 2.5 + row * 2.2
            t0 = (z0 - 1.5) / 7.5
            t1 = t0 + 0.12
            P = [(lerp(A[0], A2[0], t0), lerp(A[1], A2[1], t0), z0),
                 (lerp(B[0], B2[0], t0), lerp(B[1], B2[1], t0), z0),
                 (lerp(B[0], B2[0], t1), lerp(B[1], B2[1], t1), z0 + 0.9),
                 (lerp(A[0], A2[0], t1), lerp(A[1], A2[1], t1), z0 + 0.9)]
            cam.polygon(P, app.colCrowd[(i + row) % 4])
    cam.polygon([(A2[0], A2[1], 9), (B2[0], B2[1], 9), (B2[0], B2[1], 11.5), (A2[0], A2[1], 11.5)], app.colStandRoof)
    if A[1] < 150:
        cam.polygon([(A[0], A[1], 0), (B[0], B[1], 0), (B[0], B[1], 1.5), (A[0], A[1], 1.5)], app.colCarbon)


# Car model: boxes in car-local coords (forward, left, up) + size + colour key
CAR_PARTS = [
    # cx,   cy,   cz,  lx,  ly,  lz, colour
    (2.75, 0.0, 0.16, 0.50, 2.00, 0.14, 'carbon'),     # front wing
    (1.75, 0.0, 0.34, 1.60, 0.36, 0.30, 'team'),       # nose
    (0.30, 0.0, 0.40, 1.60, 0.80, 0.55, 'team'),       # cockpit/chassis
    (-0.60, 0.0, 0.38, 1.70, 1.60, 0.46, 'dark'),      # sidepods
    (-0.50, 0.0, 0.78, 1.80, 0.50, 0.40, 'team'),      # engine cover
    (0.45, 0.0, 0.80, 0.34, 0.30, 0.28, 'helmet'),
    (-2.35, 0.0, 0.92, 0.45, 1.50, 0.26, 'team'),      # rear wing
    (1.65, 0.86, 0.34, 0.68, 0.40, 0.68, 'tyre'),      # wheels
    (1.65, -0.86, 0.34, 0.68, 0.40, 0.68, 'tyre'),
    (-1.55, 0.86, 0.36, 0.74, 0.50, 0.72, 'tyre'),
    (-1.55, -0.86, 0.36, 0.74, 0.50, 0.72, 'tyre'),
]
CAR_PARTS_LOW = [CAR_PARTS[0], CAR_PARTS[3], CAR_PARTS[4], CAR_PARTS[6],
                 CAR_PARTS[7], CAR_PARTS[8], CAR_PARTS[9], CAR_PARTS[10]]
CAR_PARTS_FAR = [
    (0.0, 0.0, 0.40, 5.2, 1.9, 0.62, 'team'),
    (-2.35, 0.0, 0.92, 0.45, 1.50, 0.26, 'dark'),
]

# faces of a unit box: (normal, corner indices). Corners indexed by bits (x,y,z)
BOX_FACES = [
    ((1, 0, 0), (1, 3, 7, 5)),
    ((-1, 0, 0), (0, 4, 6, 2)),
    ((0, 1, 0), (2, 6, 7, 3)),
    ((0, -1, 0), (0, 1, 5, 4)),
    ((0, 0, 1), (4, 5, 7, 6)),
]


def drawCar(app, cam, car, depth):
    yaw = car.heading + car.visualYaw
    ch, sh = math.cos(yaw), math.sin(yaw)
    camX, camY, camH = cam.x, cam.y, cam.h
    cols = {'team': car.colRGB, 'dark': car.darkRGB, 'carbon': app.colCarbon,
            'tyre': app.colTyre, 'helmet': app.colHelmet}
    # shadow
    sp = []
    for (fx, ly) in ((2.9, 1.0), (2.9, -1.0), (-2.6, -1.1), (-2.6, 1.1)):
        wx = car.x + ch * fx - sh * ly
        wy = car.y + sh * fx + ch * ly
        sp.append(cam.toCam(wx, wy, 0.02))
    if depth < 120:
        cam.polygon(sp, app.colShadow, 45)
    parts = CAR_PARTS if depth < 16 or car.isPlayer else CAR_PARTS_LOW if depth < 80 else CAR_PARTS_FAR
    drawList = []
    for (pcx, pcy, pcz, lx, ly, lz, ck) in parts:
        wx = car.x + ch * pcx - sh * pcy
        wy = car.y + sh * pcx + ch * pcy
        _, pf, _ = cam.toCam(wx, wy)
        drawList.append((pf, pcx, pcy, pcz, lx, ly, lz, ck, wx, wy))
    drawList.sort(key=lambda e: -e[0])
    for (pf, pcx, pcy, pcz, lx, ly, lz, ck, wx, wy) in drawList:
        hx, hy, hz = lx / 2, ly / 2, lz / 2
        corners = []
        for b in range(8):
            ox = hx if b & 1 else -hx
            oy = hy if b & 2 else -hy
            oz = hz if b & 4 else -hz
            X = wx + ch * ox - sh * oy
            Y = wy + sh * ox + ch * oy
            corners.append(cam.toCam(X, Y, pcz + oz))
        col = cols[ck]
        if min(c[1] for c in corners) > NEAR:
            # fast path: silhouette (convex hull) in the side shade + lit top face
            F, ccx, hor, H = cam.F, cam.cx, cam.hor, cam.h
            pts2 = [(ccx + r * F / f, hor + (H - z) * F / f) for (r, f, z) in corners]
            hull = convexHull(pts2)
            flat = [v for pt in hull for v in pt]
            drawPolygon(*flat, fill=shade(app, ck, col, car, 0.0, 0.0))
            if camH > pcz + hz and ck != 'tyre':
                top = [pts2[k] for k in (4, 5, 7, 6)]
                drawPolygon(*[v for pt in top for v in pt], fill=col)
            continue
        for (nrm, idxs) in BOX_FACES:
            # world-space normal
            nX = ch * nrm[0] - sh * nrm[1]
            nY = sh * nrm[0] + ch * nrm[1]
            nZ = nrm[2]
            # face centre to camera vector
            fcx = wx + ch * (nrm[0] * hx) - sh * (nrm[1] * hy)
            fcy = wy + sh * (nrm[0] * hx) + ch * (nrm[1] * hy)
            fcz = pcz + nrm[2] * hz
            if (camX - fcx) * nX + (camY - fcy) * nY + (camH - fcz) * nZ <= 0:
                continue
            fill = col
            if nZ == 0:
                fill = shade(app, ck, col, car, nX, nY)
            cam.polygon([corners[k] for k in idxs], fill)
    # brake lights / ERS glow
    if car.brake > 0.3 or car.usingErs:
        wx = car.x - ch * 2.62
        wy = car.y - sh * 2.62
        r, f, z = cam.toCam(wx, wy, 0.62)
        if f > NEAR:
            sx, sy = cam.proj(r, f, z)
            rad = clamp(0.07 * cam.F / f, 1.5, 7)
            drawCircle(sx, sy, rad, fill='red' if car.brake > 0.3 else rgb(80, 200, 255))


SHADE_CACHE = {}


def convexHull(pts):
    pts = sorted(pts)

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def shade(app, ck, col, car, nX, nY):
    # simple directional light from the sun direction (world)
    lx, ly = 0.6, 0.8
    lit = 0.62 + 0.38 * max(0.0, nX * lx + nY * ly)
    key = (ck, car.code if ck in ('team', 'dark') else '', int(lit * 10))
    c = SHADE_CACHE.get(key)
    if c is None:
        base = {'team': car.color, 'dark': tuple(int(v * 0.6) for v in car.color),
                'carbon': (35, 35, 40), 'tyre': (22, 22, 24), 'helmet': (250, 210, 40)}[ck]
        q = int(lit * 10) / 10
        c = rgb(*(int(v * q) for v in base))
        SHADE_CACHE[key] = c
    return c


# --------------------------------------------------------------------------
# HUD
# --------------------------------------------------------------------------


def drawHUD(app):
    p = app.player
    race = app.mode == 'race'
    # --- timing tower (race) or session box (quali)
    if race:
        drawTower(app)
    else:
        drawQualiBox(app)
    # --- top centre lap info
    cx = WIDTH / 2
    drawRect(cx - 82, 6, 164, 42, fill='black', opacity=55)
    if race:
        lap = clamp(p.crossings, 1, RACE_LAPS)
        drawLabel(f'LAP {lap}/{RACE_LAPS}', cx + 10, 18, size=14, bold=True, fill='white')
        pos = standings(app.cars).index(p) + 1
        drawLabel(f'P{pos}', cx - 60, 27, size=20, bold=True, fill=rgb(255, 220, 60))
    else:
        drawLabel(f'TIMED LAP {min(p.timedLaps + 1, QUALI_LAPS)}/{QUALI_LAPS}' if p.lapStart is not None
                  else 'OUT LAP', cx, 18, size=13, bold=True, fill='white')
    cur = (app.clock - p.lapStart) if (p.lapStart is not None and (not race or app.raceStarted)) else None
    curCol = 'white' if (p.lapValid or race) else rgb(255, 90, 90)
    drawLabel(fmtTime(cur), cx + (10 if race else 0), 36, size=13, fill=curCol, bold=True)
    drawLabel(f'LAST {fmtTime(p.lastLap)}', cx - 82, 58, size=10, fill='white',
              align='left', bold=True)
    best = p.bestLap if race else p.qualiTime
    drawLabel(f'BEST {fmtTime(best)}', cx + 82, 58, size=10, fill=rgb(200, 140, 255),
              align='right', bold=True)
    drawMinimap(app)
    drawTelemetry(app)
    drawTyres(app)
    # messages
    y = 104
    for (text, t, col) in app.messages:
        op = clamp(t * 100, 0, 100)
        drawRect(cx - 150, y - 11, 300, 22, fill='black', opacity=op * 0.5)
        drawLabel(text, cx, y, size=12, bold=True, fill=col, opacity=op)
        y += 26
    if race and not app.raceStarted:
        drawLights(app)
    if app.autopilot:
        drawLabel('AUTOPILOT  (X)', cx, 74 if race else 88, size=11, bold=True, fill=rgb(80, 200, 255))
    if not race and not p.lapValid and p.lapStart is not None:
        drawLabel('LAP INVALID', cx, 74, size=11, bold=True, fill=rgb(255, 80, 80))
    if app.paused:
        drawRect(0, 0, WIDTH, HEIGHT, fill='black', opacity=50)
        drawLabel('PAUSED', cx, HEIGHT / 2 - 20, size=34, bold=True, fill='white')
        drawLabel('P resume   Esc menu   C camera   R reset car', cx, HEIGHT / 2 + 16,
                  size=13, fill='white')
        drawLabel('Joystick:  Start resume   Select menu   Y camera   L1 reset car',
                  cx, HEIGHT / 2 + 36, size=12, fill=rgb(200, 200, 200))
    # wrong way
    T = TRACK
    th = math.atan2(T.ty[p.idx], T.tx[p.idx])
    if abs(wrapAngle(p.heading - th)) > 2.0 and abs(p.v) > 1:
        drawLabel('WRONG WAY', cx, HEIGHT / 2 - 50, size=26, bold=True, fill='red')
    drawLabel(f'{app.fps:.0f} fps', WIDTH - 6, HEIGHT - 116, size=9, fill='white', align='right')


def drawLights(app):
    t = app.lightsT
    n = clamp(int(t - 0.5), 0, 5)
    gap = 40
    x0 = WIDTH / 2 - 2 * gap
    drawRect(x0 - 28, 92, 4 * gap + 56, 66, fill='black', opacity=80)
    for k in range(5):
        x = x0 + k * gap
        drawRect(x - 14, 98, 28, 54, fill=rgb(25, 25, 25))
        on = k < n
        drawCircle(x, 112, 10, fill='red' if on else rgb(60, 20, 20))
        drawCircle(x, 138, 10, fill='red' if on else rgb(60, 20, 20))


def drawTower(app):
    order = standings(app.cars)
    leader = order[0]
    x, y = 6, 6
    drawRect(x, y, 150, 22 + 17 * len(order), fill='black', opacity=65)
    drawLabel('RACE', x + 8, y + 11, size=11, bold=True, fill='white', align='left')
    drawLabel(f'{app.clock:5.1f}s', x + 142, y + 11, size=10, fill='white', align='right')
    for k, c in enumerate(order):
        yy = y + 29 + k * 17
        if c.isPlayer:
            drawRect(x + 2, yy - 8, 146, 16, fill=rgb(255, 255, 255), opacity=25)
        drawRect(x + 22, yy - 6, 3, 12, fill=c.colRGB if not c.isPlayer else rgb(255, 220, 60))
        drawLabel(f'{k + 1}', x + 15, yy, size=10, bold=True, fill='white', align='right')
        drawLabel(c.code, x + 30, yy, size=10, bold=True, fill='white', align='left')
        drawCircle(x + 70, yy, 5, fill=app.compRGB[c.compound], border='black', borderWidth=1)
        if c.finished:
            g = 'FIN'
        elif k == 0:
            g = 'Leader'
        else:
            gp = gapToLeader(c, leader)
            if c.crossings < leader.crossings - 1 or (leader.metric - c.metric) > TRACK.length:
                g = '+1 LAP'
            else:
                g = '' if gp is None else f'+{gp:.1f}'
        drawLabel(g, x + 142, yy, size=10, fill='white', align='right')


def drawQualiBox(app):
    x, y = 6, 6
    p = app.player
    drawRect(x, y, 150, 68, fill='black', opacity=65)
    drawLabel('QUALIFYING', x + 8, y + 11, size=11, bold=True, fill='white', align='left')
    drawLabel(f'{app.difficulty}', x + 142, y + 11, size=9, fill='white', align='right')
    drawLabel(f'Timed laps left: {QUALI_LAPS - p.timedLaps}', x + 8, y + 28, size=10, fill='white', align='left')
    drawLabel(f'Ideal lap: {fmtTime(TRACK.idealLap)}', x + 8, y + 43, size=9, fill=rgb(180, 180, 180), align='left')
    if p.qualiTime is not None:
        drawLabel('F / Select = end session', x + 8, y + 58, size=9, fill=rgb(180, 180, 180), align='left')
    elif not app.qualiGenDone:
        drawLabel('rivals on track...', x + 8, y + 58, size=9, fill=rgb(150, 150, 150), align='left')


def buildMinimap(app):
    T = TRACK
    xs, ys = T.cx, T.cy
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    bw, bh = 134, 100
    sc = min(bw / (maxx - minx), bh / (maxy - miny))
    ox = WIDTH - 12 - bw / 2 - (minx + maxx) / 2 * sc
    oy = 12 + bh / 2 + (miny + maxy) / 2 * sc
    pts = []
    for i in range(0, T.n, 6):
        pts += [ox + xs[i] * sc, oy - ys[i] * sc]
    app.mini = (sc, ox, oy, pts)


def drawMinimap(app):
    T = TRACK
    sc, ox, oy, pts = app.mini
    drawRect(WIDTH - 152, 4, 148, 116, fill='black', opacity=45)
    drawPolygon(*pts, fill=None, border=rgb(230, 230, 230), borderWidth=3)
    sx, sy = ox + T.cx[0] * sc, oy - T.cy[0] * sc
    drawRect(sx - 1, sy - 5, 3, 10, fill='red')
    for c in app.cars if app.mode == 'race' else [app.player]:
        if c.isPlayer:
            continue
        drawCircle(ox + c.x * sc, oy - c.y * sc, 3, fill=c.colRGB, border='white', borderWidth=1)
    p = app.player
    drawCircle(ox + p.x * sc, oy - p.y * sc, 4.5, fill=rgb(255, 220, 60), border='black', borderWidth=1)


GEARS = [0, 19, 29, 39, 49, 59, 69, 80, 200]


def drawTelemetry(app):
    p = app.player
    x0, y0 = WIDTH - 166, HEIGHT - 106
    drawRect(x0, y0, 160, 100, fill='black', opacity=60)
    kmh = abs(p.v) * 3.6
    drawLabel(f'{kmh:3.0f}', x0 + 52, y0 + 34, size=30, bold=True, fill='white')
    drawLabel('KM/H', x0 + 52, y0 + 56, size=9, fill=rgb(180, 180, 180))
    if p.v < -0.5:
        g, frac = 'R', 0.3
    else:
        gi = 1
        while gi < 8 and p.v > GEARS[gi]:
            gi += 1
        lo, hi = GEARS[gi - 1], GEARS[gi] if gi < 8 else 100
        frac = clamp((p.v - lo * 0.75) / max(1, hi - lo * 0.75), 0, 1)
        g = str(gi) if p.v > 0.3 else 'N'
    drawLabel(g, x0 + 126, y0 + 33, size=28, bold=True, fill=rgb(255, 220, 60))
    # rpm bar
    drawRect(x0 + 10, y0 + 7, 140, 5, fill=rgb(60, 60, 60))
    col = rgb(60, 220, 90) if frac < 0.5 else rgb(250, 60, 60) if frac < 0.8 else rgb(120, 120, 255)
    drawRect(x0 + 10, y0 + 7, max(1, 140 * frac), 5, fill=col)
    # throttle / brake
    drawRect(x0 + 10, y0 + 67, 62, 6, fill=rgb(50, 50, 50))
    drawRect(x0 + 10, y0 + 67, max(1, 62 * p.throttle), 6, fill=rgb(60, 220, 90))
    drawRect(x0 + 10, y0 + 77, 62, 6, fill=rgb(50, 50, 50))
    drawRect(x0 + 10, y0 + 77, max(1, 62 * p.brake), 6, fill=rgb(240, 60, 60))
    # ERS
    drawLabel('ERS', x0 + 82, y0 + 70, size=9, bold=True, fill=rgb(80, 200, 255), align='left')
    drawRect(x0 + 110, y0 + 66, 40, 8, fill=rgb(40, 40, 40))
    drawRect(x0 + 110, y0 + 66, max(1, 40 * p.ers), 8,
             fill=rgb(80, 200, 255) if not p.usingErs else rgb(200, 240, 255))
    drawLabel('FUEL', x0 + 82, y0 + 81, size=9, bold=True, fill=rgb(220, 220, 220), align='left')
    drawRect(x0 + 110, y0 + 77, 40, 8, fill=rgb(40, 40, 40))
    drawRect(x0 + 110, y0 + 77, max(1, 40 * p.fuel), 8, fill=rgb(220, 160, 60))
    grip = p.tyreGrip() / p.massFactor()
    surf = {'track': '', 'kerb': 'KERB', 'grass': 'OFF'}[p.surface]
    drawLabel(f'GRIP {grip * 100:3.0f}%  {surf}', x0 + 10, y0 + 93, size=9, fill='white',
              align='left', bold=True)
    if p.slide > 0.05:
        drawLabel('SLIDING', x0 + 150, y0 + 93, size=9, fill=rgb(255, 150, 50), align='right', bold=True)


def tempColor(T, lo, hi):
    if T < lo:
        return mixColor((60, 200, 90), (60, 120, 255), (lo - T) / 30)
    if T > hi:
        return mixColor((60, 200, 90), (240, 50, 30), (T - hi) / 25)
    return rgb(60, 200, 90)


def drawTyres(app):
    p = app.player
    c = COMPOUNDS[p.compound]
    x0, y0 = 6, HEIGHT - 112
    drawRect(x0, y0, 164, 106, fill='black', opacity=60)
    drawCircle(x0 + 15, y0 + 14, 9, fill=rgb(*c['col']))
    drawCircle(x0 + 15, y0 + 14, 5, fill='black')
    drawLabel(c['name'], x0 + 29, y0 + 14, size=11, bold=True, fill='white', align='left')
    drawLabel(f'{c["lo"]}-{c["hi"]}°C', x0 + 156, y0 + 14, size=9,
              fill=rgb(180, 180, 180), align='right')
    # car outline
    cx = x0 + 48
    drawRect(cx - 5, y0 + 31, 10, 62, fill=rgb(80, 80, 90))
    pos = [(cx - 23, y0 + 32), (cx + 9, y0 + 32), (cx - 25, y0 + 66), (cx + 9, y0 + 66)]
    for k in range(4):
        tx, ty = pos[k]
        w = 14 if k < 2 else 16
        T = p.temps[k]
        drawRect(tx, ty, w, 25, fill=tempColor(T, c['lo'], c['hi']), border='white', borderWidth=1)
        wearH = 25 * p.wear[k]
        if wearH > 0.5:
            drawRect(tx, ty, w, wearH, fill='black', opacity=55)
    for k in range(4):
        col = 0 if k % 2 == 0 else 1
        row = k // 2
        lx = x0 + 98 + col * 40
        ly = y0 + 44 + row * 34
        drawLabel(f'{p.temps[k]:.0f}°', lx, ly, size=12, bold=True, fill='white')
    w = sum(p.wear) / 4
    drawLabel(f'LIFE {(1 - w) * 100:.0f}%', x0 + 118, y0 + 96, size=9, bold=True,
              fill=rgb(255, 150, 110) if w > 0.45 else rgb(200, 200, 200))


# --------------------------------------------------------------------------
# Screens
# --------------------------------------------------------------------------


def drawMenu(app):
    cx = WIDTH / 2
    drawRect(0, 0, WIDTH, HEIGHT, fill=gradient(rgb(15, 15, 25), rgb(60, 10, 15), start='top'))
    # animated stripes
    for k in range(8):
        x = (k * 120 + app.menuT * 200) % (WIDTH + 260) - 180
        drawPolygon(x, HEIGHT, x + 50, HEIGHT, x + 220, 0, x + 170, 0, fill=rgb(200, 20, 30), opacity=12)
    drawLabel('GRAND PRIX 2.5D', cx, 52, size=42, bold=True, fill='white')
    drawLabel('Qualifying  +  5-lap race  vs  7 A* AI drivers', cx, 88, size=14,
              fill=rgb(220, 220, 220))
    # difficulty
    drawLabel('DIFFICULTY  (1/2/3, D-pad L/R)', cx - 160, 122, size=12, bold=True, fill='white')
    for k, d in enumerate(['EASY', 'MEDIUM', 'HARD']):
        sel = app.difficulty == d
        x = cx - 305 + k * 96
        drawRect(x, 136, 90, 32, fill=rgb(200, 20, 30) if sel else rgb(50, 50, 60),
                 border='white' if sel else None)
        drawLabel(f'{k + 1}  {d}', x + 45, 152, size=12, bold=True, fill='white')
    drawLabel('RACE TYRE  (S/M/H, D-pad U/D)', cx + 160, 122, size=12, bold=True, fill='white')
    for k, cmp in enumerate(['S', 'M', 'H']):
        c = COMPOUNDS[cmp]
        sel = app.raceCompound == cmp
        x = cx + 17 + k * 96
        drawRect(x, 136, 90, 32, fill=rgb(70, 70, 80) if sel else rgb(40, 40, 48),
                 border='white' if sel else None)
        drawCircle(x + 16, 152, 9, fill=rgb(*c['col']))
        drawCircle(x + 16, 152, 5, fill='black')
        drawLabel(c['name'], x + 55, 152, size=11, bold=True, fill='white')
    c = COMPOUNDS[app.raceCompound]
    tip = {'S': 'Soft: fastest, warms up quickly, but wears out fast and overheats.',
           'M': 'Medium: balanced grip and durability.',
           'H': 'Hard: least grip, needs heat, but barely degrades over 5 laps.'}[app.raceCompound]
    drawLabel(tip, cx, 184, size=11, fill=rgb(200, 200, 200))
    # controls
    lines = [
        ('UP / W', 'Throttle'), ('DOWN / S', 'Brake (hold when stopped: reverse)'),
        ('LEFT RIGHT / A D', 'Steer'), ('SPACE', 'ERS boost (recharges under braking)'),
        ('C', 'Change camera (chase / high / cockpit)'), ('R', 'Reset car to track'),
        ('X', 'Let the AI drive your car'), ('P / Esc', 'Pause / Menu'),
        ('JOYSTICK', 'Stick steer, A gas, B brake, R1 ERS, Y cam, L1 reset'),
    ]
    drawRect(cx - 290, 200, 580, 198, fill='black', opacity=40)
    for k, (key, what) in enumerate(lines):
        y = 213 + k * 21
        drawLabel(key, cx - 80, y, size=12, bold=True, fill=rgb(255, 220, 60), align='right')
        drawLabel(what, cx - 66, y, size=12, fill='white', align='left')
    blink = int(app.menuT * 2) % 2 == 0
    drawLabel('Press ENTER / Start to start Qualifying', cx, 424, size=18, bold=True,
              fill='white' if blink else rgb(255, 220, 60))
    drawLabel(f'Track length {TRACK.length / 1000:.2f} km   -   ideal lap {fmtTime(TRACK.idealLap)}',
              cx, 456, size=10, fill=rgb(160, 160, 160))


def drawTable(app, title, rows, footer, header):
    drawRect(0, 0, WIDTH, HEIGHT, fill=gradient(rgb(15, 15, 25), rgb(40, 10, 15), start='top'))
    drawLabel(title, WIDTH / 2, 34, size=28, bold=True, fill='white')
    x0 = WIDTH / 2 - 300
    drawRect(x0, 60, 600, 28 + 36 * len(rows), fill='black', opacity=50)
    hx = [x0 + 24, x0 + 56, x0 + 290, x0 + 395, x0 + 585]
    for k, h in enumerate(header):
        drawLabel(h, hx[k], 74, size=10, bold=True, fill=rgb(170, 170, 170),
                  align='left' if k in (1,) else 'right' if k == 4 else 'center')
    for r, (car, cols) in enumerate(rows):
        y = 106 + r * 36
        if car.isPlayer:
            drawRect(x0 + 4, y - 16, 592, 32, fill=rgb(255, 220, 60), opacity=20)
        drawLabel(str(r + 1), hx[0], y, size=16, bold=True, fill='white')
        drawRect(x0 + 42, y - 10, 5, 20, fill=car.colRGB if not car.isPlayer else rgb(255, 220, 60))
        drawLabel(car.name, hx[1], y, size=14, bold=True, fill='white', align='left')
        drawLabel(cols[0], hx[2], y, size=13, fill='white')
        if cols[1] in COMPOUNDS:
            drawCircle(hx[3], y, 9, fill=rgb(*COMPOUNDS[cols[1]]['col']))
            drawCircle(hx[3], y, 4, fill='black')
        else:
            drawLabel(cols[1], hx[3], y, size=13, fill='white')
        drawLabel(cols[2], hx[4], y, size=13, fill='white', align='right', bold=True)
    drawLabel(footer, WIDTH / 2, HEIGHT - 28, size=15, bold=True, fill=rgb(255, 220, 60))


def drawQualiResults(app):
    rows = []
    pole = app.qualiOrder[0].qualiTime
    for k, c in enumerate(app.qualiOrder):
        t = fmtTime(c.qualiTime) if c.qualiTime < 900 else 'NO TIME'
        if k > 0 and c.qualiTime < 900:
            t += f'  (+{c.qualiTime - pole:.3f})'
        rows.append((c, (c.code, 'S', t)))
    pos = app.qualiOrder.index(app.player) + 1
    drawTable(app, 'QUALIFYING RESULTS', rows,
              f'You start P{pos}.  Race on {COMPOUNDS[app.raceCompound]["name"]} tyres  -  press ENTER / Start',
              ['POS', 'DRIVER', 'CODE', 'TYRE', 'BEST LAP'])


def drawRaceResults(app):
    rows = []
    for (c, gap) in app.results:
        best = fmtTime(c.bestLap) if c.bestLap else '-'
        rows.append((c, (best, c.compound, gap)))
    pos = [c for (c, _) in app.results].index(app.player) + 1
    msg = {1: 'VICTORY! You won the Grand Prix!', 2: 'P2 - great drive!', 3: 'Podium finish - P3!'}.get(
        pos, f'You finished P{pos} (started P{app.player.gridPos})')
    drawTable(app, 'RACE RESULTS', rows, msg + '   -  ENTER / Start for menu',
              ['POS', 'DRIVER', 'BEST LAP', 'TYRE', 'TIME / GAP'])


def redrawAll(app):
    if app.mode == 'menu':
        drawMenu(app)
    elif app.mode in ('quali', 'race'):
        drawWorld(app)
        drawHUD(app)
    elif app.mode == 'qualiResults':
        drawQualiResults(app)
    elif app.mode == 'raceResults':
        drawRaceResults(app)


def main():
    runApp(width=WIDTH, height=HEIGHT)


if __name__ == '__main__':
    main()
