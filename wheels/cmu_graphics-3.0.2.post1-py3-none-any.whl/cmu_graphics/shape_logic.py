import math
import copy
import os
from cmu_graphics import cmu_graphics
from cmu_graphics import utils


from cmu_graphics.deps import wyvern, pygeo


from cmu_graphics.libs import webrequest
from io import BytesIO
import sys
import traceback
import atexit
import unicodedata
import uuid
import re

# fmt: off
# start_translate
TRANSLATED_COLOR_NAMES = {'keys': ['aliceblue', 'antiquewhite', 'aqua', 'aquamarine', 'azure', 'beige', 'bisque', 'black', 'blanchedalmond', 'blue', 'blueviolet', 'brown', 'burlywood', 'cadetblue', 'chartreuse', 'chocolate', 'coral', 'cornsilk', 'cornflowerblue', 'crimson', 'cyan', 'darkblue', 'darkcyan', 'darkgoldenrod', 'darkgray', 'darkgreen', 'darkgrey', 'darkkhaki', 'darkmagenta', 'darkolivegreen', 'darkorange', 'darkorchid', 'darkred', 'darksalmon', 'darkseagreen', 'darkslateblue', 'darkslategray', 'darkslategrey', 'darkturquoise', 'darkviolet', 'deeppink', 'deepskyblue', 'dimgray', 'dimgrey', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia', 'gainsboro', 'ghostwhite', 'gold', 'goldenrod', 'gray', 'green', 'greenyellow', 'grey', 'honeydew', 'hotpink', 'indianred', 'indigo', 'ivory', 'khaki', 'lavender', 'lavenderblush', 'lawngreen', 'lemonchiffon', 'lightblue', 'lightcoral', 'lightcyan', 'lightgoldenrodyellow', 'lightgray', 'lightgreen', 'lightgrey', 'lightpink', 'lightsalmon', 'lightseagreen', 'lightskyblue', 'lightslategray', 'lightslategrey', 'lightsteelblue', 'lightyellow', 'lime', 'limegreen', 'linen', 'magenta', 'maroon', 'mediumaquamarine', 'mediumblue', 'mediumorchid', 'mediumpurple', 'mediumseagreen', 'mediumslateblue', 'mediumspringgreen', 'mediumturquoise', 'mediumvioletred', 'midnightblue', 'mintcream', 'mistyrose', 'moccasin', 'navajowhite', 'navy', 'oldlace', 'olive', 'olivedrab', 'orange', 'orangered', 'orchid', 'palegoldenrod', 'palegreen', 'paleturquoise', 'palevioletred', 'papayawhip', 'peachpuff', 'peru', 'pink', 'plum', 'powderblue', 'purple', 'red', 'rosybrown', 'royalblue', 'saddlebrown', 'salmon', 'sandybrown', 'seagreen', 'seashell', 'sienna', 'silver', 'skyblue', 'slateblue', 'slategray', 'slategrey', 'snow', 'springgreen', 'steelblue', 'tan', 'teal', 'thistle', 'tomato', 'turquoise', 'violet', 'wheat', 'white', 'whitesmoke', 'yellow', 'yellowgreen'], 'es': {'aliceblue': 'azulalica', 'antiquewhite': 'blancoantiguo', 'aqua': 'agua', 'aquamarine': 'aguamarina', 'azure': 'azur', 'beige': 'beige', 'bisque': 'bisque', 'black': 'negro', 'blanchedalmond': 'almendrablanqueada', 'blue': 'azul', 'blueviolet': 'azulvioleta', 'brown': 'marrón', 'burlywood': 'madera', 'cadetblue': 'azulcadete', 'chartreuse': 'verdeamarillento', 'chocolate': 'chocolate', 'coral': 'coral', 'cornsilk': 'maizseda', 'cornflowerblue': 'azualaciano', 'crimson': 'carmesí', 'cyan': 'cian', 'darkblue': 'azuloscuro', 'darkcyan': 'cianoscuro', 'darkgoldenrod': 'varilladoradaoscura', 'darkgray': 'grisoscuro', 'darkgreen': 'verdeoscuro', 'darkgrey': 'grisoscuro', 'darkkhaki': 'caquioscuro', 'darkmagenta': 'magentaoscuro', 'darkolivegreen': 'verdeolivaoscuro', 'darkorange': 'naranjaoscuro', 'darkorchid': 'orquídeaoscura', 'darkred': 'rojooscuro', 'darksalmon': 'salmónoscuro', 'darkseagreen': 'marverdeoscuro', 'darkslateblue': 'azulpizarraoscuro', 'darkslategray': 'grispizarraoscuro', 'darkslategrey': 'grispizarraoscuro', 'darkturquoise': 'turquesaoscuro', 'darkviolet': 'violetaoscuro', 'deeppink': 'rosadoprofundo', 'deepskyblue': 'azulcieloprofundo', 'dimgray': 'gristurbio', 'dimgrey': 'gristurbio', 'dodgerblue': 'azulgandul', 'firebrick': 'ladrillo', 'floralwhite': 'blancofloral', 'forestgreen': 'verdebosque', 'fuchsia': 'fucsia', 'gainsboro': 'gainsboro', 'ghostwhite': 'blancofantasma', 'gold': 'oro', 'goldenrod': 'varilladorada', 'gray': 'gris', 'green': 'verde', 'greenyellow': 'verdeamarillo', 'grey': 'gris', 'honeydew': 'melón', 'hotpink': 'rosadofuerte', 'indianred': 'rojoindio', 'indigo': 'índigo', 'ivory': 'marfil', 'khaki': 'caqui', 'lavender': 'lavanda', 'lavenderblush': 'ruborlavanda', 'lawngreen': 'cespedverde', 'lemonchiffon': 'limónchifón', 'lightblue': 'azulclaro', 'lightcoral': 'coralclaro', 'lightcyan': 'cianclaro', 'lightgoldenrodyellow': 'varilladoradaclaraamarilla', 'lightgray': 'grisclaro', 'lightgreen': 'verdeclaro', 'lightgrey': 'grisclaro', 'lightpink': 'rosadoclaro', 'lightsalmon': 'salmónclaro', 'lightseagreen': 'marverdeclaro', 'lightskyblue': 'azulcieloclaro', 'lightslategray': 'grispizarraclaro', 'lightslategrey': 'grispizarraclaro', 'lightsteelblue': 'azulaceroclaro', 'lightyellow': 'amarilloclaro', 'lime': 'lima', 'limegreen': 'limaverde', 'linen': 'lino', 'magenta': 'magenta', 'maroon': 'granate', 'mediumaquamarine': 'aguamarinamedio', 'mediumblue': 'azulmedio', 'mediumorchid': 'orquídeamedio', 'mediumpurple': 'púrpuramedio', 'mediumseagreen': 'marverdemedio', 'mediumslateblue': 'pizarraazulmedio', 'mediumspringgreen': 'verdeprimaveramedio', 'mediumturquoise': 'turquesamedio', 'mediumvioletred': 'violetarojomedio', 'midnightblue': 'azulmedianoche', 'mintcream': 'cremamenta', 'mistyrose': 'nebulosarosa', 'moccasin': 'mocasín', 'navajowhite': 'blanconaranja', 'navy': 'azulmarino', 'oldlace': 'cordónviejo', 'olive': 'oliva', 'olivedrab': 'verdemilitar', 'orange': 'naranja', 'orangered': 'rojonaranja', 'orchid': 'orquídea', 'palegoldenrod': 'varilladoradapálida', 'palegreen': 'verdepálido', 'paleturquoise': 'turquesapálido', 'palevioletred': 'rojovioletapálido', 'papayawhip': 'látigodepapaya', 'peachpuff': 'durazno', 'peru': 'naranjamarrón', 'pink': 'rosado', 'plum': 'ciruela', 'powderblue': 'azulpolvo', 'purple': 'púrpura', 'red': 'rojo', 'rosybrown': 'marrónrosado', 'royalblue': 'azulreal', 'saddlebrown': 'marróncuero', 'salmon': 'salmón', 'sandybrown': 'marrónarenoso', 'seagreen': 'marverde', 'seashell': 'caracol', 'sienna': 'tierra', 'silver': 'plateado', 'skyblue': 'azulcielo', 'slateblue': 'azulpizarra', 'slategray': 'grispizarra', 'slategrey': 'grispizarra', 'snow': 'nieve', 'springgreen': 'verdeprimavera', 'steelblue': 'azulacero', 'tan': 'bronceado', 'teal': 'verdeazulado', 'thistle': 'cardo', 'tomato': 'tomate', 'turquoise': 'turquesa', 'violet': 'violeta', 'wheat': 'trigo', 'white': 'blanco', 'whitesmoke': 'humoblanco', 'yellow': 'amarillo', 'yellowgreen': 'amarilloverde'}, 'de': {'aliceblue': 'aliceblau', 'antiquewhite': 'altweiß', 'aqua': 'wasser', 'aquamarine': 'aquamarin', 'azure': 'azurblau', 'beige': 'beige', 'bisque': 'biskuit', 'black': 'schwarz', 'blanchedalmond': 'bleichemandel', 'blue': 'blau', 'blueviolet': 'blauviolett', 'brown': 'braun', 'burlywood': 'wurzelholz', 'cadetblue': 'kadettenblau', 'chartreuse': 'chartreuse', 'chocolate': 'schokolade', 'coral': 'koralle', 'cornsilk': 'maisseide', 'cornflowerblue': 'kornfeldblau', 'crimson': 'purpur', 'cyan': 'cyan', 'darkblue': 'dunkelblau', 'darkcyan': 'dunkelcyan', 'darkgoldenrod': 'dunkelgoldrute', 'darkgray': 'dunkelgrau', 'darkgreen': 'dunkelgrün', 'darkgrey': 'dunkelgrau', 'darkkhaki': 'dunkelkhaki', 'darkmagenta': 'dunkelmagenta', 'darkolivegreen': 'dunkelolivegrün', 'darkorange': 'dunkelorange', 'darkorchid': 'dunkeorchidee', 'darkred': 'dunkelrot', 'darksalmon': 'dunkellachs', 'darkseagreen': 'dunkelseegrün', 'darkslateblue': 'dunkelschieferblau', 'darkslategray': 'dunkelschiefergrau', 'darkslategrey': 'dunkelschiefergraube', 'darkturquoise': 'dunkeltürkis', 'darkviolet': 'dunkelviolett', 'deeppink': 'dunkelrosa', 'deepskyblue': 'dunkelhimmelblau', 'dimgray': 'mittelgrau', 'dimgrey': 'mittelgraube', 'dodgerblue': 'dodgerblau', 'firebrick': 'backstein', 'floralwhite': 'blütenweiß', 'forestgreen': 'waldgrün', 'fuchsia': 'fuchsie', 'gainsboro': 'gainsboro', 'ghostwhite': 'geisterweiß', 'gold': 'gold', 'goldenrod': 'goldrute', 'gray': 'grau', 'green': 'grün', 'greenyellow': 'grüngelb', 'grey': 'graube', 'honeydew': 'honigtau', 'hotpink': 'kräftigpink', 'indianred': 'indischrot', 'indigo': 'indigo', 'ivory': 'eisen', 'khaki': 'khaki', 'lavender': 'lavendel', 'lavenderblush': 'lavendelröte', 'lawngreen': 'rasengrün', 'lemonchiffon': 'zitronenchiffon', 'lightblue': 'hellblau', 'lightcoral': 'hellkoralle', 'lightcyan': 'hellcyan', 'lightgoldenrodyellow': 'leichtgoldrutengelb', 'lightgray': 'hellgrau', 'lightgreen': 'hellgrün', 'lightgrey': 'hellgraube', 'lightpink': 'hellrosa', 'lightsalmon': 'helllachs', 'lightseagreen': 'hellseegrün', 'lightskyblue': 'hellhimmelblau', 'lightslategray': 'hellschiefergrau', 'lightslategrey': 'hellschiefergraube', 'lightsteelblue': 'hellstahlblau', 'lightyellow': 'hellgelb', 'lime': 'limette', 'limegreen': 'limettengrün', 'linen': 'leinen', 'magenta': 'magenta', 'maroon': 'kastanie', 'mediumaquamarine': 'mittelaquamarine', 'mediumblue': 'mittelblau', 'mediumorchid': 'mittelorchidee', 'mediumpurple': 'mittelviolett', 'mediumseagreen': 'mittelseegrün', 'mediumslateblue': 'mittelschieferblau', 'mediumspringgreen': 'mittelfrühlingsgrün', 'mediumturquoise': 'mitteltürkis', 'mediumvioletred': 'mittelviolettrot', 'midnightblue': 'mitternachtsblau', 'mintcream': 'mintcreme', 'mistyrose': 'nebligrose', 'moccasin': 'mokassin', 'navajowhite': 'navajoweiß', 'navy': 'marineblau', 'oldlace': 'altgold', 'olive': 'olive', 'olivedrab': 'trübolive', 'orange': 'orange', 'orangered': 'orangerot', 'orchid': 'orchidee', 'palegoldenrod': 'blassegoldrute', 'palegreen': 'blassgrün', 'paleturquoise': 'blasstürkis', 'palevioletred': 'blasslilarot', 'papayawhip': 'papayafarben', 'peachpuff': 'pfirsich', 'peru': 'peru', 'pink': 'rosa', 'plum': 'pflaume', 'powderblue': 'taubenblau', 'purple': 'lila', 'red': 'rot', 'rosybrown': 'rostbraun', 'royalblue': 'köningsblau', 'saddlebrown': 'sattelbraun', 'salmon': 'lachs', 'sandybrown': 'sandbraun', 'seagreen': 'seegrün', 'seashell': 'muschel', 'sienna': 'sienna', 'silver': 'silber', 'skyblue': 'himmelblau', 'slateblue': 'schieferblau', 'slategray': 'schiefergrau', 'slategrey': 'schiefergraube', 'snow': 'schneeweiß', 'springgreen': 'frühlingsgrün', 'steelblue': 'stahlblau', 'tan': 'gelbbraun', 'teal': 'petrol', 'thistle': 'diestel', 'tomato': 'tomate', 'turquoise': 'türkis', 'violet': 'violett', 'wheat': 'weizen', 'white': 'weiß', 'whitesmoke': 'weißerrauch', 'yellow': 'gelb', 'yellowgreen': 'gelbgrün'}}
TRANSLATED_GRADIENT_STARTS = {'keys': ['top-left', 'top-right', 'bottom-left', 'bottom-right', 'left-top', 'top', 'right-top', 'left', 'center', 'right', 'left-bottom', 'bottom', 'right-bottom'], 'es': {'top-left': 'superior-izquierda', 'top-right': 'superior-derecha', 'bottom-left': 'inferior-izquierda', 'bottom-right': 'inferior-derecha', 'left-top': 'izquierda-superior', 'top': 'superior', 'right-top': 'derecha-superior', 'left': 'izquierda', 'center': 'centro', 'right': 'derecha', 'left-bottom': 'izquierda-inferior', 'bottom': 'inferior', 'right-bottom': 'derecha-inferior'}, 'de': {'top-left': 'oben-links', 'top-right': 'oben-rechts', 'bottom-left': 'unten-links', 'bottom-right': 'unten-rechts', 'left-top': 'links-oben', 'top': 'oben', 'right-top': 'rechts-oben', 'left': 'links', 'center': 'mitte', 'right': 'rechts', 'left-bottom': 'links-unten', 'bottom': 'unten', 'right-bottom': 'rechts-unten'}}
TRANSLATED_ALIGNS = {'keys': ['left-top', 'top', 'right-top', 'left', 'center', 'right', 'left-bottom', 'bottom', 'right-bottom', 'top-left', 'top-right', 'bottom-left', 'bottom-right'], 'es': {'left-top': 'izquierda-superior', 'top': 'superior', 'right-top': 'derecha-superior', 'left': 'izquierda', 'center': 'centro', 'right': 'derecha', 'left-bottom': 'izquierda-inferior', 'bottom': 'inferior', 'right-bottom': 'derecha-inferior', 'top-left': 'superior-izquierda', 'top-right': 'superior-derecha', 'bottom-left': 'inferior-izquierda', 'bottom-right': 'inferior-derecha'}, 'de': {'left-top': 'links-oben', 'top': 'oben', 'right-top': 'rechts-oben', 'left': 'links', 'center': 'mitte', 'right': 'rechts', 'left-bottom': 'links-unten', 'bottom': 'unten', 'right-bottom': 'rechts-unten', 'top-left': 'oben-links', 'top-right': 'oben-rechts', 'bottom-left': 'unten-links', 'bottom-right': 'unten-rechts'}}
TRANSLATED_SHAPE_ATTRS = {'keys': ['group', 'play', 'pause', 'loop', 'restart', 'remove', 'bold', 'opacity', 'centerX', 'hits', 'borderWidth', 'centerY', 'url', 'left', 'add', 'points', 'startAngle', 'toBack', 'x2', 'y1', 'size', 'initialPoints', 'top', 'align', 'dashes', 'right', 'start', 'y2', 'radius', 'border', 'containsShape', 'background', 'height', 'lineWidth', 'toFront', 'roundness', 'arrowEnd', 'x1', 'fill', 'bottom', 'clear', 'sweepAngle', 'value', 'contains', 'italic', 'visible', 'arrowStart', 'hitsShape', 'font', 'children', 'hitTest', 'width', 'rotateAngle', 'red', 'blue', 'green'], 'es': {'group': 'grupo', 'play': 'toca', 'pause': 'pausa', 'loop': 'repetir', 'restart': 'reiniciar', 'remove': 'quitar', 'bold': 'negrito', 'opacity': 'opacidad', 'centerX': 'centroX', 'hits': 'toca', 'borderWidth': 'anchuraDeBorde', 'centerY': 'centroY', 'url': 'url', 'left': 'izquierda', 'add': 'agregar', 'points': 'puntos', 'startAngle': 'ánguloInicial', 'toBack': 'alFondo', 'x2': 'x2', 'y1': 'y1', 'size': 'tamaño', 'initialPoints': 'puntosIniciales', 'top': 'superior', 'align': 'alinear', 'dashes': 'guión', 'right': 'derecha', 'start': 'inicio', 'colors': 'colores', 'y2': 'y2', 'radius': 'radio', 'border': 'borde', 'containsShape': 'contieneFigura', 'background': 'fondo', 'height': 'altura', 'lineWidth': 'anchuraDeLínea', 'toFront': 'alFrente', 'roundness': 'redondez', 'arrowEnd': 'finalDeFlecha', 'x1': 'x1', 'fill': 'relleno', 'bottom': 'inferior', 'clear': 'vaciar', 'sweepAngle': 'ánguloDeBarrido', 'value': 'valor', 'contains': 'contiene', 'italic': 'itálica', 'visible': 'visible', 'arrowStart': 'inicioDeFlecha', 'hitsShape': 'tocaFigura', 'font': 'fuente', 'children': 'hijos', 'hitTest': 'tocarPrueba', 'width': 'ancho', 'rotateAngle': 'rotarÁngulo', 'red': 'red', 'blue': 'blue', 'green': 'green'}, 'de': {'group': 'gruppe', 'play': 'abspielen', 'pause': 'pausieren', 'loop': 'wiederholen', 'restart': 'neustarten', 'remove': 'entferne', 'bold': 'fett', 'opacity': 'deckkraft', 'centerX': 'mitteX', 'hits': 'trifft', 'borderWidth': 'randBreite', 'centerY': 'mitteY', 'url': 'url', 'left': 'links', 'add': 'fügeHinzu', 'points': 'punkte', 'startAngle': 'anfangsWinkel', 'toBack': 'nachHinten', 'x2': 'x2', 'y1': 'y1', 'size': 'größe', 'initialPoints': 'startPunkte', 'top': 'oben', 'align': 'ausrichtung', 'dashes': 'gestrichelt', 'right': 'rechts', 'start': 'start', 'y2': 'y2', 'radius': 'radius', 'border': 'rand', 'containsShape': 'beinhaltetForm', 'background': 'hintergrund', 'height': 'höhe', 'lineWidth': 'linienBreite', 'toFront': 'nachVorn', 'roundness': 'rundung', 'arrowEnd': 'pfeilEnde', 'x1': 'x1', 'fill': 'füllen', 'bottom': 'unten', 'clear': 'leeren', 'sweepAngle': 'krümmungsWinkel', 'value': 'wert', 'contains': 'beinhaltet', 'italic': 'kursiv', 'visible': 'sichtbar', 'arrowStart': 'pfeilStart', 'hitsShape': 'trifftForm', 'font': 'schriftart', 'children': 'kinder', 'hitTest': 'treffenTest', 'width': 'breite', 'rotateAngle': 'drehWinkel', 'red': 'red', 'blue': 'blue', 'green': 'green'}}
TRANSLATED_BOOLEANS = {'keys': ['True', 'False'], 'es': {'True': 'Verdadero', 'False': 'Falso'}, 'de': {'True': 'Wahr', 'False': 'Falsch'}}
TRANSLATED_GLOBALS = {'keys': ['Arc', 'Circle', 'Group', 'Image', 'Label', 'Line', 'Oval', 'Polygon', 'Rect', 'RegularPolygon', 'Robot', 'Sound', 'Star', 'almostEqual', 'angleTo', 'app', 'assertEqual', 'choice', 'distance', 'fromPythonAngle', 'getPointInDir', 'gradient', 'makeList', 'onKeyHolds', 'onSteps', 'print', 'pythonRound', 'random', 'randrange', 'rgb', 'round', 'rounded', 'seed', 'toPythonAngle', 'onKeyPresses', 'CMUImage'], 'es': {'Arc': 'Arco', 'Circle': 'Círculo', 'Group': 'Grupo', 'Image': 'Imagen', 'Label': 'Rótulo', 'Line': 'Línea', 'Oval': 'Óvalo', 'Polygon': 'Polígono', 'Rect': 'Rect', 'RegularPolygon': 'PolígonoRegular', 'Robot': 'Robot', 'Sound': 'Sonido', 'Star': 'Estrella', 'almostEqual': 'casiIgualA', 'angleTo': 'ánguloA', 'app': 'app', 'assertEqual': 'afirmarIgualdad', 'choice': 'opción', 'distance': 'distancia', 'fromPythonAngle': 'deÁnguloPython', 'getPointInDir': 'obtenerPuntoEnDir', 'gradient': 'gradiente', 'makeList': 'hacerLista', 'onKeyHolds': 'enTeclasRetenidas', 'onSteps': 'enPasos', 'print': 'imprime', 'pythonRound': 'redondearPython', 'random': 'aleatorio', 'randrange': 'rangoAleatorio', 'rgb': 'rgb', 'round': 'redondear', 'rounded': 'redondeado', 'seed': 'semilla', 'toPythonAngle': 'aÁnguloPython', 'onKeyPresses': 'enTeclaPresionadas', 'CMUImage': 'CMUImage'}, 'de': {'Arc': 'Bogen', 'Circle': 'Kreis', 'Group': 'Gruppe', 'Image': 'Bild', 'Label': 'Beschriftung', 'Line': 'Linie', 'Oval': 'Oval', 'Polygon': 'Vieleck', 'Rect': 'Rechteck', 'RegularPolygon': 'RegelmäßigesVieleck', 'Robot': 'Roboter', 'Sound': 'Geräusch', 'Star': 'Stern', 'almostEqual': 'fastGleich', 'angleTo': 'winkelNach', 'app': 'anwendung', 'assertEqual': 'gleichsetzen', 'choice': 'auswahl', 'distance': 'distanz', 'fromPythonAngle': 'vomPythonWinkel', 'getPointInDir': 'erhaltePunktInRichtung', 'gradient': 'farbverlauf', 'makeList': 'macheListe', 'onKeyHolds': 'wennTasteGedrückt', 'onSteps': 'schrittweise', 'print': 'ausgabe', 'pythonRound': 'pythonRunden', 'random': 'zufall', 'randrange': 'zufallsspanne', 'rgb': 'RGB', 'round': 'runden', 'rounded': 'gerundet', 'seed': 'kerne', 'toPythonAngle': 'zumPythonWinkel', 'onKeyPresses': 'wennTasteGedrückt', 'CMUImage': 'CMUImage'}}
TRANSLATED_CPCS_GLOBALS = {'keys': ['drawArc', 'drawCircle', 'drawImage', 'drawLabel', 'drawLine', 'drawOval', 'drawPolygon', 'drawRect', 'drawRegularPolygon', 'drawStar', 'getImageSize', 'runApp', 'runAppWithScreens', 'setActiveScreen'], 'es': { 'drawArc': 'dibujaArco', 'drawCircle': 'dibujaCírculo', 'drawImage': 'dibujaImagen', 'drawLabel': 'dibujaRótulo', 'drawLine': 'dibujaLínea', 'drawOval': 'dibujaÓvalo', 'drawPolygon': 'dibujaPolígono', 'drawRect': 'dibujaRect', 'drawRegularPolygon': 'dibujaPolígonoRegular', 'drawStar': 'dibujaEstrella', 'getImageSize': 'obtenerTamañoDeImagen', 'runApp': 'ejecutaApp', 'runAppWithScreens': 'ejecutaAppConPantallas', 'setActiveScreen': 'establecePantallaActiva'}}
TRANSLATED_USER_FUNCTION_NAMES = {'keys': ['onKeyHold', 'onKeyPress', 'onKeyRelease', 'onMouseDrag', 'onMouseMove', 'onMousePress', 'onMouseRelease', 'onStep', 'onScreenActivate', 'redrawAll', 'onAppStart'], 'es': {'onKeyHold': 'enTeclaRetenida', 'onKeyPress': 'enTeclaPresionada', 'onKeyRelease': 'enTeclaSoltada', 'onMouseDrag': 'enRatónArrastrado', 'onMouseMove': 'enRatónMovido', 'onMousePress': 'enRatónPresionado', 'onMouseRelease': 'enRatónSoltado', 'onStep': 'enPaso', 'onScreenActivate': 'enActivaciónDePantalla', 'redrawAll': 'redibujaTodo', 'onAppStart': 'enInicioDeApp'}, 'de': {'onKeyHold': 'beiTasteHalten', 'onKeyPress': 'beiTasteRunter', 'onKeyRelease': 'beiTasteHoch', 'onMouseDrag': 'beiMausMitTasteZiehen', 'onMouseMove': 'beiMausbewegung', 'onMousePress': 'beiMaustasteRunter', 'onMouseRelease': 'beiMaustasteHoch', 'onStep': 'beimSchritt'}}
TRANSLATED_KEY_NAMES = {'keys': ['space', 'enter', 'left', 'right', 'up', 'down', 'pageup', 'pagedown', 'escape', 'delete', 'backspace', 'tab'], 'es': {'space': 'espacio', 'enter': 'intro', 'left': 'izquierda', 'right': 'derecha', 'up': 'arriba', 'down': 'abajo', 'pageup': 'repág', 'pagedown': 'avpág', 'escape': 'escapar', 'delete': 'suprimir', 'backspace': 'retroceso', 'tab': 'pestaña'}, 'de': {'space': 'leertaste', 'enter': 'enter', 'left': 'links', 'right': 'rechts', 'up': 'pfeil-hoch', 'down': 'pfeil-runter', 'pageup': 'bild-hoch', 'pagedown': 'bild-runter', 'escape': 'escape', 'delete': 'entfernen', 'backspace': 'löschen', 'tab': 'tab'}}
TRANSLATED_APP_ATTRS = {'keys': ['background', 'getTextInput', 'group', 'maxShapeCount', 'paused', 'setTextInputs', 'stepsPerSecond', 'stop', 'stopped', 'setMaxShapeCount'], 'es': {'background': 'fondo', 'getTextInput': 'obtenerEntradaDeTexto', 'group': 'grupo', 'maxShapeCount': 'maxCuentaDeFiguras', 'paused': 'pausada', 'setTextInputs': 'establecerEntradaDeTexto', 'stepsPerSecond': 'pasosPorSegundo', 'stop': 'detener', 'stopped': 'detenido', 'setMaxShapeCount': 'establecerCuentaFormasMaximas'}, 'de': {'background': 'hintergrund', 'getTextInput': 'holeTextEingabe', 'group': 'gruppe', 'maxShapeCount': 'maximaleFormMenge', 'paused': 'pausiert', 'setTextInputs': 'setzeTextEingaben', 'stepsPerSecond': 'schritteProSekunde', 'stop': 'stop', 'stopped': 'gestoppt', 'setMaxShapeCount': 'setzeMaxFormAnzahl'}}
TRANSLATED_STRINGS = {'keys': ['Arc', 'Circle', 'Group', 'Image', 'Label', 'Line', 'Oval', 'Polygon', 'Rect', 'RegularPolygon', 'Robot', 'Sound', 'Star', 'almostEqual', 'angleTo', 'app', 'assertEqual', 'choice', 'distance', 'fromPythonAngle', 'getPointInDir', 'gradient', 'makeList', 'onKeyHolds', 'onSteps', 'print', 'pythonRound', 'random', 'randrange', 'rgb', 'round', 'rounded', 'seed', 'toPythonAngle', 'onKeyPresses', 'Arc', 'Circle', 'Group', 'Image', 'Label', 'Line', 'Oval', 'Polygon', 'Rect', 'RegularPolygon', 'Robot', 'Sound', 'Star', 'almostEqual', 'angleTo', 'app', 'assertEqual', 'choice', 'distance', 'fromPythonAngle', 'getPointInDir', 'gradient', 'makeList', 'onKeyHolds', 'onSteps', 'print', 'pythonRound', 'random', 'randrange', 'rgb', 'round', 'rounded', 'seed', 'toPythonAngle', 'onKeyPresses', 'remove', 'bold', 'opacity', 'centerX', 'hits', 'borderWidth', 'centerY', 'url', 'left', 'add', 'points', 'startAngle', 'toBack', 'x2', 'y1', 'size', 'initialPoints', 'top', 'align', 'dashes', 'right', 'start', 'y2', 'radius', 'border', 'containsShape', 'background', 'height', 'lineWidth', 'toFront', 'roundness', 'arrowEnd', 'x1', 'fill', 'bottom', 'clear', 'sweepAngle', 'value', 'contains', 'italic', 'visible', 'arrowStart', 'hitsShape', 'font', 'children', 'hitTest', 'width', 'rotateAngle', '"{{align}}" is not a valid Polygon constructor argument', '"{{attr}}" is not a valid shape constructor argument', '**** Error in onError()!!! ****', 'An assertEqual() statement in a test case failed. See the Console for details.', 'An error occurred. Here is the stack trace:', 'App', 'App.group is readonly', 'App.stopped is readonly', 'Arc', 'Arg Count Error: {{callSpec}}() takes {{argNamesLen}} arguments ({{argNames}}), not {{argsLen}}', 'Arguments to setTextInputs must be strings. %r is not a string.', 'Autograder: error executing solution code!', 'Autograder: error executing user code!', 'Autograding is taking a long time. Your code may have an infinite loop.', 'Both rows and cols must be >= 0', "Cannot set Image's url", "Cannot set Label's height", "Cannot set Label's width", "Cannot set Line's border", "Cannot set Line's borderWidth", 'Circle', 'Circle{{attrs}}', 'Failed to get text input', 'Failed to load image data', 'Font not found: {{baseFontName}}\n', 'Group', 'Group()', 'Group.add(shape)', 'Group.remove(shape)', 'Group.{{attr}} cannot be read or modified', "Group.{{attr}} has no value because its children don't all have the same value for {{attr}}", '{{error}}: Illegal gradient start ({{start}})', 'Image', 'Image{{args}}', 'Internal error (no solution shapes!).  Please try again.', 'Label', 'Label({{args}})', 'Line', 'Line{{args}}', 'Must have an even number of x,y values in initialPoints list', 'Need to pass at least 2 colors to gradient(); you gave {{colorsLength}}', 'No activeDrawing for new Shape', 'No such attribute: {{attr}}', 'None', 'Oval', 'Oval{{args}}', 'Polygon', 'Polygon{{args}}', 'Recording Starts In', 'Rect', 'Rect{{args}}', 'RegularPolygon', 'RegularPolygon{{args}}', 'Robot', 'Shape', 'Shape()', 'Shapes drawn in wrong order', "Sorry, you cannot use Python's input function in CMU CS Academy", 'Sound', 'Sound "{{soundSource}}" failed to play. Disabling it.', 'Star', 'Star{{args}}', 'The loop argument to Sound.play must be True or False, got {{loopRepr}}', 'The restart argument to Sound.play must be True or False, got {{restartRepr}}', 'Too many shapes: Your code created more than {{maxShapeCount}} shapes. If you would like to increase this limit even though it may cause your code to run slowly, call app.setMaxShapeCount(n).', 'Traceback (most recent call last):', '{{error}}: None cannot be used inside gradient.colors', '{{error}}: {{callSpec}} should be {{typeName}} (but {{value}} is of type {{valueType}})', '{{error}}: {{color}} cannot be used inside gradient.colors', '{{error}}: {{callSpec}} should be a color, and {{value}} is not a legal color name', 'Undefined poster in new _CmuGraphics', 'Unknown message {{cmd}}', "Use our rounded(n) instead of Python 3's round(n)\n  Python 3's round(n) does not work as one might expect!\n  If you still want Python 3's round, use pythonRound", 'Wait for fonts to load before using them', 'Wrong # of points ({{userPtsLen}} should be {{solnPtsLen}})', 'You are missing {{missingCount}} shape(s)', "You can't change the size of this group because {{shape}} can't be resized", "You can't get or set the align property", 'You have {{extraCount}} extra shape(s)', 'Your code appeared to be in an infinite loop, so it was terminated.', '\nWarning: Your code created labels with more than\n  1,000 total characters of text. This may cause your\n  program to run very slowly.\n', 'addPoint', 'add{{xy}}', 'align', 'app.background should not be {{userBackgroundString}}', 'app.setMaxShapeCount(n)', 'arrowEnd', 'arrowStart', 'at line', 'background', 'black', 'bold', 'border', 'borderWidth', 'bottom', 'bottom-left', 'bottom-right', 'center', 'centerX', 'centerY', 'centroidX', 'centroidY', 'color', 'containsShape(targetShape)', 'dashes', 'fill', 'font', 'gradient({{colors}}, start={{start}})', 'height', 'hits(x, y)', 'hitsShape(targetShape)', 'initialPoints', 'initialPoints (x value)', 'initialPoints (y value)', 'integer', 'italic', 'keys must be a list', 'left', 'left-bottom', 'left-top', 'line', 'lineWidth', 'list', 'n', 'non-negative-number', 'number', 'number-greater-than-2', 'number-in-range-{{lo}}-{{hi}}', 'opacity', 'oval size', 'points', 'positive-number', 'radius', 'rgb({{r}}, {{g}}, {{b}})', 'right', 'right-bottom', 'right-top', 'rotate.cx', 'rotate.cy', 'rotate.degrees', 'rotateAngle', 'roundness', 'scale{{xy}}', 'shape', 'size', 'startAngle', 'string', 'sweepAngle', 'targetShape', 'top', 'top-left', 'top-right', 'url', 'value', 'visible', 'width', 'x', 'x1', 'x2', 'y', 'y1', 'y2', '{{actual}} != {{expected}}', '{{attr}} in {{object}}', '{{attr}} should not be {{value}}', '{{ordinalName}} point mismatch at {{location}}', 'play', 'pause', 'restart', 'loop', 'TypeError', '{{error}}: in {{callSpec}}, {{value}} is not a legal align value', "{{error}}: {{callSpec}} got an unexpected keyword argument '{{arg}}'", "Polygon object cannot access '{{attr}}' because point numbers start from 1", "Polygon object cannot access '{{attr}}' because it only has 1 point", "Polygon object cannot access '{{attr}}' because it only has {{numPoints}} points", 'point number', 'contains(x, y)', 'hitTest(x, y)', 'addPoint(x, y)', 'red', 'green', 'blue', '{{callSpec}} must start with http:// or https://', 'runApp', 'runAppWithScreens', 'redrawAll', 'drawRect', 'drawImage', 'drawOval', 'drawCircle', 'drawRegularPolygon', 'drawStar', 'drawLine', 'drawPolygon', 'drawArc', 'drawLabel', 'getImageSize', "Screen '{{screen}}' requires '{{screen}}_{{redrawAllInCorrectLanguage}}()'"], 'es': {'Arc': 'Arco', 'Circle': 'Círculo', 'Group': 'Grupo', 'Image': 'Imagen', 'Label': 'Rótulo', 'Line': 'Línea', 'Oval': 'Óvalo', 'Polygon': 'Polígono', 'Rect': 'Rect', 'RegularPolygon': 'PolígonoRegular', 'Robot': 'Robot', 'Sound': 'Sonido', 'Star': 'Estrella', 'almostEqual': 'casiIgualA', 'angleTo': 'ánguloA', 'app': 'app', 'assertEqual': 'afirmarIgualdad', 'choice': 'opción', 'distance': 'distancia', 'fromPythonAngle': 'deÁnguloPython', 'getPointInDir': 'obtenerPuntoEnDir', 'gradient': 'gradiente', 'makeList': 'hacerLista', 'onKeyHolds': 'enTeclasRetenidas', 'onSteps': 'enPasos', 'print': 'imprime', 'pythonRound': 'redondearPython', 'random': 'aleatorio', 'randrange': 'rangoAleatorio', 'rgb': 'rgb', 'round': 'redondear', 'rounded': 'redondeado', 'seed': 'semilla', 'toPythonAngle': 'aÁnguloPython', 'onKeyPresses': 'enTeclaPresionadas', 'remove': 'quitar', 'bold': 'negrito', 'opacity': 'opacidad', 'centerX': 'centroX', 'hits': 'toca', 'borderWidth': 'anchuraDeBorde', 'centerY': 'centroY', 'url': 'url', 'left': 'izquierda', 'add': 'agregar', 'points': 'puntos', 'startAngle': 'ánguloInicial', 'toBack': 'alFondo', 'x2': 'x2', 'y1': 'y1', 'size': 'tamaño', 'initialPoints': 'puntosIniciales', 'top': 'superior', 'align': 'alinear', 'dashes': 'guión', 'right': 'derecha', 'start': 'inicio', 'colors': 'colores', 'y2': 'y2', 'radius': 'radio', 'border': 'borde', 'containsShape': 'contieneFigura', 'background': 'fondo', 'height': 'altura', 'lineWidth': 'anchuraDeLínea', 'toFront': 'alFrente', 'roundness': 'redondez', 'arrowEnd': 'finalDeFlecha', 'x1': 'x1', 'fill': 'relleno', 'bottom': 'inferior', 'clear': 'vaciar', 'sweepAngle': 'ánguloDeBarrido', 'value': 'valor', 'contains': 'contiene', 'italic': 'itálica', 'visible': 'visible', 'arrowStart': 'inicioDeFlecha', 'hitsShape': 'tocaFigura', 'font': 'fuente', 'children': 'hijos', 'hitTest': 'tocarPrueba', 'width': 'ancho', 'rotateAngle': 'rotarÁngulo', '"{{align}}" is not a valid Polygon constructor argument': '"alinear" no es un argumento de constructor de Polígono válido', '"{{attr}}" is not a valid shape constructor argument': '"{{attr}}" no es un argumento de constructor de formas válido', '**** Error in onError()!!! ****': '**** ¡¡¡Error dentro de enError()!!! ****', 'An assertEqual() statement in a test case failed. See the Console for details.': 'Una sentencia assertEqual() dentro de un caso de prueba falló. Mire la consola para detalles.', 'An error occurred. Here is the stack trace:': 'Ocurrió un error. Aquí está el seguimiento de la pila:', 'App': 'App', 'App.group is readonly': 'App.grupo es sólo lectura', 'App.stopped is readonly': 'App.detenido es sólo lectura', 'Arg Count Error: {{callSpec}}() takes {{argNamesLen}} arguments ({{argNames}}), not {{argsLen}}': 'Arg Count Error: {{callSpec}}() toma {{argNamesLen}} argumentos ({{argNames}}), no {{argsLen}}', 'Arguments to setTextInputs must be strings. %r is not a string.': 'Arguments to setTextInputs must be strings. %r is not a string.', 'Autograder: error executing solution code!': 'Evaluador: ¡error al ejecutar el código de la solución!', 'Autograder: error executing user code!': 'Evaluador: ¡error al ejecutar el código del usuario!', 'Autograding is taking a long time. Your code may have an infinite loop.': 'El evaluador está tardando mucho. Su código puede tener un bucle infinito.', 'Both rows and cols must be >= 0': 'Ambos las filas y las cols deben ser >= 0', "Cannot set Image's url": 'No se puede establecer el url de una Imagen', "Cannot set Label's height": 'No se puede establecer la altura de una Línea', "Cannot set Label's width": 'No se puede establecer la anchura de una Línea', "Cannot set Line's border": 'No se puede establecer el borde de una Línea', "Cannot set Line's borderWidth": 'No se puede establecer la anchura de una Línea', 'Circle{{attrs}}': 'Círculo{{attrs}}', 'Failed to get text input': 'No se pudo obtener entrade de texto', 'Failed to load image data': 'No se puedo cargar los datos de la imagen', 'Font not found: {{baseFontName}}\n': 'Fuente no encontrada: {{baseFontName}}\\n', 'Group()': 'Grupo()', 'Group.add(shape)': 'Grupo.agregar(figura)', 'Group.remove(shape)': 'Grupo.quitar(figura)', 'Group.{{attr}} cannot be read or modified': 'Grupo.{{attr}} no se puede leer ni modificar', "Group.{{attr}} has no value because its children don't all have the same value for {{attr}}": 'Grupo.{{attr}} no tiene valor porque no todos sus elementos secundarios tienen el mismo valor para {{attr}}', '{{error}}: Illegal gradient start ({{start}})': '{{error}}: Inicio de gradiente ilegal ({{start}})', 'Image{{args}}': 'Imagen{{args}}', 'Internal error (no solution shapes!).  Please try again.': 'Error internal (¡no figuras en su solución!).  Por favor inténtelo otra vez.', 'Label({{args}})': 'Rótulo({{args}})', 'Line{{args}}': 'Línea{{args}}', 'Must have an even number of x,y values in initialPoints list': 'Debe tener un número par de valores x,y dentro de la lista puntosIniciales', 'Need to pass at least 2 colors to gradient(); you gave {{colorsLength}}': 'Necesita dar al menos 2 colores a gradiente(); diste {{colorsLength}}', 'No activeDrawing for new Shape': 'No hay un dibujoActivo para la Figura nueva', 'No such attribute: {{attr}}': 'No existe tal atributo: {{attr}}', 'None': 'None', 'Oval{{args}}': 'Óvalo{{args}}', 'Polygon{{args}}': 'Polígono{{args}}', 'Recording Starts In': 'Grabación comenzando en', 'Rect{{args}}': 'Rect{{args}}', 'RegularPolygon{{args}}': 'PolígonoRegular{{args}}', 'Shape': 'Figura', 'Shape()': 'Figura()', 'Shapes drawn in wrong order': 'Figuras dibujadas en el orden equivocado', "Sorry, you cannot use Python's input function in CMU CS Academy": 'Lo lamento, no puede usar la función de entrada de Python en CMU CS Academy', 'Sound "{{soundSource}}" failed to play. Disabling it.': 'Sonido "{{soundSource}}" no pudo jugar. Desactivando.', 'Star{{args}}': 'Estrella{{args}}', 'The loop argument to Sound.play must be True or False, got {{loopRepr}}': 'El argumento de repetición de Sonido.tocar debe ser Verdadero o Falso, obtuvo {{loopRepr}}', 'The restart argument to Sound.play must be True or False, got {{restartRepr}}': 'El argumento de reinicio de Sonido.tocar debe ser Verdadero o Falso, obtuvo {{reiniciarRepr}}', 'Too many shapes: Your code created more than {{maxShapeCount}} shapes. If you would like to increase this limit even though it may cause your code to run slowly, call app.setMaxShapeCount(n).': 'Demasiadas formas: Su código creó más de {{maxShapeCount}} formas. Si desea aumentar este límite, aunque puede hacer que su código se ejecute lentamente, llame a app.establecerCuentaFormasMaximas(n).', 'Traceback (most recent call last):': 'rastreo (última llamada más reciente):', '{{error}}: None cannot be used inside gradient.colors': '{{error}}: None no se puede usar dentro de gradientes.colores', '{{error}}: {{callSpec}} should be {{typeName}} (but {{value}} is of type {{valueType}})': '{{error}}: {{callSpec}} debe ser {{typeName}} (pero {{value}} es de tipo {{valueType}})', '{{error}}: {{color}} cannot be used inside gradient.colors': '{{error}}: {{color}} no se puede utilizar dentro de gradiente.colores', '{{error}}: {{callSpec}} should be a color, and {{value}} is not a legal color name': '{{error}}: {{callSpec}} debe ser un color, y {{value}} no es un nombre de color legal', 'Undefined poster in new _CmuGraphics': 'Posteador indefinido en nuevo _CmuGraphics', 'Unknown message {{cmd}}': 'Mensaje desconocido {{cmd}}', "Use our rounded(n) instead of Python 3's round(n)\n  Python 3's round(n) does not work as one might expect!\n  If you still want Python 3's round, use pythonRound": 'Use nuestra función redondear(n) en lugar del "round(n)" de Python\\n ¡La función "round(n)" de Python 3 no funciona como uno espera!\\n Si todavía quiere usar el "round" de Python, use "pythonRound"', 'Wait for fonts to load before using them': 'Espere a que se carguen las fuentes antes de usarlas', 'Wrong # of points ({{userPtsLen}} should be {{solnPtsLen}})': '# incorrecto de puntos ({{userPtsLen}} debe ser {{solnPtsLen}})', 'You are missing {{missingCount}} shape(s)': 'Te faltan {{missingCount}} forma(s)', "You can't change the size of this group because {{shape}} can't be resized": 'No puedes cambiar el tamaño de este grupo porque no se puede cambiar el tamaño de {{shape}}', "You can't get or set the align property": 'No puede obtener o establecer la propiedad de alinear', 'You have {{extraCount}} extra shape(s)': 'Tienes {{extraCount}} forma(s) adicionales', 'Your code appeared to be in an infinite loop, so it was terminated.': 'Your code appeared to be in an infinite loop, so it was terminated.', '\nWarning: Your code created labels with more than\n  1,000 total characters of text. This may cause your\n  program to run very slowly.\n': '\\nAdvertencia: Su código creó rótulos con más de\\n  1,000 caracteres de texto en total. Esto puede hacer que su\\n programa se ejecute muy lentamente.\\n', 'addPoint': 'agregarPunto', 'add{{xy}}': 'añadir{{xy}}', 'app.background should not be {{userBackgroundString}}': 'app.fondo no debe ser {{userBackgroundString}}', 'app.setMaxShapeCount(n)': 'app.establecerMáximaCuentaDeFiguras(n)', 'at line': 'en la línea', 'black': 'negro', 'bottom-left': 'inferior-izquierda', 'bottom-right': 'inferior-derecha', 'center': 'centro', 'centroidX': 'centroideX', 'centroidY': 'centroideY', 'color': 'color', 'containsShape(targetShape)': 'contieneFigura(figuraObjetivo)', 'gradient({{colors}}, start={{start}})': 'gradient({{colors}}, start={{start}})', 'hits(x, y)': 'toca(x, y)', 'hitsShape(targetShape)': 'tocaFigura(figuraObjetivo)', 'initialPoints (x value)': 'puntosIniciales (valor x)', 'initialPoints (y value)': 'puntosIniciales (valor y)', 'integer': 'número entero', 'keys must be a list': 'teclas debe ser una lista', 'left-bottom': 'izquierda-inferior', 'left-top': 'izquierda-superior', 'line': 'línea', 'list': 'lista', 'n': 'n', 'non-negative-number': 'número-no-negativo', 'number': 'número', 'number-greater-than-2': 'número-mayor-que-2', 'number-in-range-{{lo}}-{{hi}}': 'número-en-rango-{{lo}}-{{hi}}', 'oval size': 'tamaño de óvalo', 'positive-number': 'número-positivo', 'rgb({{r}}, {{g}}, {{b}})': 'rgb({{r}}, {{g}}, {{b}})', 'right-bottom': 'derecha-inferior', 'right-top': 'derecha-superior', 'rotate.cx': 'rotar.cx', 'rotate.cy': 'rotar.cy', 'rotate.degrees': 'rotar.grados', 'scale{{xy}}': 'escala{{xy}}', 'shape': 'figura', 'string': 'cadena', 'targetShape': 'figuraObjetivo', 'top-left': 'superior-izquierda', 'top-right': 'superior-derecha', 'x': 'x', 'y': 'y', '{{actual}} != {{expected}}': '{{actual}} != {{expected}}', '{{attr}} in {{object}}': '{{attr}} dentro de {{object}}', '{{attr}} should not be {{value}}': '{{attr}} no debe ser {{value}}', '{{ordinalName}} point mismatch at {{location}}': '{{ordinalName}} desajuste de puntos en {{location}}', 'play': 'toca', 'pause': 'pausa', 'restart': 'reiniciar', 'loop': 'repetir', 'TypeError': 'Error de tipo', '{{error}}: in {{callSpec}}, {{value}} is not a legal align value': '{{error}}: en {{callSpec}}, {{value}} no es un valor legal de alineación', "{{error}}: {{callSpec}} got an unexpected keyword argument '{{arg}}'": "{{error}}: {{callSpec}} tiene un argumento de palabra clave inesperado '{{arg}}'", "Polygon object cannot access '{{attr}}' because point numbers start from 1": "El objeto de polígono no puede acceder a '{{attr}}' porque los números de puntos comienzan desde 1", "Polygon object cannot access '{{attr}}' because it only has 1 point": "El objeto de polígono no puede acceder a '{{attr}}' porque sólo tiene 1 punto", "Polygon object cannot access '{{attr}}' because it only has {{numPoints}} points": "El objeto de polígono no puede acceder a '{{attr}}' porque sólo tiene {{numPoints}} puntos", 'point number': 'número de punto', 'contains(x, y)': 'contiene(x, y)', 'hitTest(x, y)': 'tocarPrueba(x, y)', 'addPoint(x, y)': 'agregarPunto(x, y)', 'red': 'red', 'green': 'green', 'blue': 'blue', '{{callSpec}} must start with http:// or https://': '{{callSpec}} debe comenzar con http:// o https://', "Cannot modify attribute '{{attr}}' of '{{className}}' object": "No se puede modificar el atributo '{{attr}}' del objeto de '{{className}}'", 'runApp': 'ejecutaApp', 'runAppWithScreens': 'ejecutaAppConPantallas', 'redrawAll': 'redibujaTodo', 'drawRect': 'dibujaRect', 'drawImage': 'dibujaImagen', 'drawOval': 'dibujaÓvalo', 'drawCircle': 'dibujaCírculo', 'drawRegularPolygon': 'dibujaPolígonoRegular', 'drawStar': 'dibujaEstrella', 'drawLine': 'dibujaLínea', 'drawPolygon': 'dibujaPolígono', 'drawArc': 'dibujaArco', 'drawLabel': 'dibujaRótulo', 'getImageSize': 'obtenerTamañoDeImagen', "Screen '{{screen}}' requires '{{screen}}_{{redrawAllInCorrectLanguage}}()'": "Pantalla '{{screen}}' requiere '{{screen}}_{{redrawAllInCorrectLanguage}}()'"}, 'de': {'Arc': 'Bogen', 'Circle': 'Kreis', 'Group': 'Gruppe', 'Image': 'Bild', 'Label': 'Beschriftung', 'Line': 'Linie', 'Oval': 'Oval', 'Polygon': 'Vieleck', 'Rect': 'Rechteck', 'RegularPolygon': 'RegelmäßigesVieleck', 'Robot': 'Roboter', 'Sound': 'Geräusch', 'Star': 'Stern', 'almostEqual': 'fastGleich', 'angleTo': 'winkelNach', 'app': 'anwendung', 'assertEqual': 'gleichsetzen', 'choice': 'auswahl', 'distance': 'distanz', 'fromPythonAngle': 'vomPythonWinkel', 'getPointInDir': 'erhaltePunktInRichtung', 'gradient': 'farbverlauf', 'makeList': 'macheListe', 'onKeyHolds': 'wennTasteGedrückt', 'onSteps': 'schrittweise', 'print': 'ausgabe', 'pythonRound': 'pythonRunden', 'random': 'zufall', 'randrange': 'zufallsspanne', 'rgb': 'RGB', 'round': 'runden', 'rounded': 'gerundet', 'seed': 'kerne', 'toPythonAngle': 'zumPythonWinkel', 'onKeyPresses': 'wennTasteGedrückt', 'remove': 'entferne', 'bold': 'fett', 'opacity': 'deckkraft', 'centerX': 'mitteX', 'hits': 'trifft', 'borderWidth': 'randBreite', 'centerY': 'mitteY', 'url': 'url', 'left': 'links', 'add': 'fügeHinzu', 'points': 'punkte', 'startAngle': 'anfangsWinkel', 'toBack': 'nachHinten', 'x2': 'x2', 'y1': 'y1', 'size': 'größe', 'initialPoints': 'startPunkte', 'top': 'oben', 'align': 'ausrichtung', 'dashes': 'gestrichelt', 'right': 'rechts', 'start': 'start', 'y2': 'y2', 'radius': 'radius', 'border': 'rand', 'containsShape': 'beinhaltetForm', 'background': 'hintergrund', 'height': 'höhe', 'lineWidth': 'linienBreite', 'toFront': 'nachVorn', 'roundness': 'rundung', 'arrowEnd': 'pfeilEnde', 'x1': 'x1', 'fill': 'füllen', 'bottom': 'unten', 'clear': 'leeren', 'sweepAngle': 'krümmungsWinkel', 'value': 'wert', 'contains': 'beinhaltet', 'italic': 'kursiv', 'visible': 'sichtbar', 'arrowStart': 'pfeilStart', 'hitsShape': 'trifftForm', 'font': 'schriftart', 'children': 'kinder', 'hitTest': 'treffenTest', 'width': 'breite', 'rotateAngle': 'drehWinkel', '"{{align}}" is not a valid Polygon constructor argument': '"alinear" ist kein gültiges Argument für den Konstruktor von Polygon',  '"{{attr}}" is not a valid shape constructor argument': '"{{attr}}" ist kein valides Argument des Konstruktors von Form', '**** Error in onError()!!! ****': '**** Fehler in wennFehler()!!! ****', 'An assertEqual() statement in a test case failed. See the Console for details.': 'Eine assertEqual() Anweisung in einem Testfall ist fehlgeschlagen. Schau auf die Konsole um Details zu sehen.', 'An error occurred. Here is the stack trace:': 'Ein unbekannter Fehler ist aufgetreten. Hier ist der Stack Tracke:', 'App': 'Anwendung', 'App.group is readonly': 'App.gruppe nur lesbar', 'App.stopped is readonly': 'App.gestoppt ist nur lesbar', 'Arg Count Error: {{callSpec}}() takes {{argNamesLen}} arguments ({{argNames}}), not {{argsLen}}': 'Fehlerhafte Anzahl der Argumente: {{callSpec}} () akzeptiert {{argNamesLen}} Argumente ({{argNames}}), nicht {{argsLen}}', 'Arguments to setTextInputs must be strings. %r is not a string.': 'Arguments to setTextInputs must be strings. %r is not a string.', 'Autograder: error executing solution code!': 'Autograder: Fehler beim Ausführen des Lösungscodes!', 'Autograder: error executing user code!': 'Autograder: Fehler beim Ausführen des Benutzercodes!', 'Autograding is taking a long time. Your code may have an infinite loop.': 'Autograding dauert lange. Möglicherweise gibt es eine Endlosschleife in deinem Code.', 'Both rows and cols must be >= 0': 'Sowohl Zeilen als auch Spalten müssen >= 0 sein', "Cannot set Image's url": 'Die URL des Bildes kann nicht festgelegt werden', "Cannot set Label's height": 'Die Höhe des Labels kann nicht eingestellt werden', "Cannot set Label's width": 'Breite des Labels kann nicht gesetzt werden', "Cannot set Line's border": 'Der Linienrand kann nicht festgelegt werden', "Cannot set Line's borderWidth": 'Die Rahmenbreite von Line kann nicht festgelegt werden', 'Circle{{attrs}}': 'Kreis{{attrs}}', 'Failed to get text input': 'Fehler bei der Texteingabe', 'Failed to load image data': 'Fehler beim Laden der Bilddaten', 'Font not found: {{baseFontName}}\n': 'Schriftart nicht gefunden: {{baseFontName}}\\n', 'Group()': 'Gruppe()', 'Group.add(shape)': 'Gruppe.fügeHinzu(form)', 'Group.remove(shape)': 'Gruppe.entferne(form)', 'Group.{{attr}} cannot be read or modified': 'Gruppe.{{attr}} kann nicht gelesen oder geändert werden', "Group.{{attr}} has no value because its children don't all have the same value for {{attr}}": 'Gruppe.{{attr}} hat keinen Wert, da die untergeordneten Elemente nicht alle den gleichen Wert für {{attr}} haben', '{{error}}: Illegal gradient start ({{start}})': '{{error}}: Illegaler Start des Farbverlaufs ({{start}})', 'Image{{args}}': 'Bild{{args}}', 'Internal error (no solution shapes!).  Please try again.': 'Interner Fehler (keine Lösungsformen!). Bitte versuche es noche einmal.', 'Label({{args}})': 'Beschriftung({{args}})', 'Line{{args}}': 'Linie{{args}}', 'Must have an even number of x,y values in initialPoints list': 'Muss eine gerade Anzahl von x,y Werten in der Liste anfangsPunkte haben', 'Need to pass at least 2 colors to gradient(); you gave {{colorsLength}}': 'Es müssen mindestens 2 Farben an farbverlauf() übergeben werden. Du hast {{farbenLänge}} gegeben', 'No activeDrawing for new Shape': 'Keine aktiveZeichnung für neue Form', 'No such attribute: {{attr}}': 'Kein solches Attribut: {{attr}}', 'None': 'None', 'Oval{{args}}': 'Oval{{args}}', 'Polygon{{args}}': 'Polygon{{args}}', 'Recording Starts In': 'Aufnahme startet in', 'Rect{{args}}': 'Rechteck{{args}}', 'RegularPolygon{{args}}': 'RegularPolygon {{args}}', 'Shape': 'Form', 'Shape()': 'Form()', 'Shapes drawn in wrong order': 'Formen werden in der falschen Reihenfolge gezeichnet', "Sorry, you cannot use Python's input function in CMU CS Academy": "Leider kannst du Python's input Funktion nicht in CMU CS Academy nutzen", 'Sound "{{soundSource}}" failed to play. Disabling it.': 'Klang "{{soundSource}}" konnte nicht abgespielt werden. Wird deaktiviert.', 'Star{{args}}': 'Stern{{args}}', 'The loop argument to Sound.play must be True or False, got {{loopRepr}}': 'Das Schleifenargument für Sound.play muss True oder False sein, {{loopRepr}}', 'The restart argument to Sound.play must be True or False, got {{restartRepr}}': 'Das Argument um Sound.play neuzustarten muss True oder False sein und {{restartRepr}} erhalten haben', 'Too many shapes: Your code created more than {{maxShapeCount}} shapes. If you would like to increase this limit even though it may cause your code to run slowly, call app.setMaxShapeCount(n).': 'Zu viele Formen:  Ihr Code hat mehr als {{maxShapeCount}} Formen erstellt. Wenn Sie dieses Limit erhöhen möchten, obwohl Ihr Code dadurch möglicherweise langsam ausgeführt wird, rufen Sie app.setzeMaxFormAnzahl(n) auf.', 'Traceback (most recent call last):': 'Aufrufliste (jüngster Aufruf zuletzt)', '{{error}}: None cannot be used inside gradient.colors': '{{error}}: None kann nicht innerhalb von farbverlauf.farben verwendet werden', '{{error}}: {{callSpec}} should be {{typeName}} (but {{value}} is of type {{valueType}})': '{{error}}: {{callSpec}} sollte {{typeName}} sein (aber {{value}} ist vom Typ {{valueType}})', '{{error}}: {{color}} cannot be used inside gradient.colors': '{{error}}: {{color}} kann nicht in gradient.colors verwendet werden', '{{error}}: {{callSpec}} should be a color, and {{value}} is not a legal color name': '{{error}}: {{callSpec}} sollte eine Farbe sein, und {{value}} ist kein zulässiger Farbname', 'Undefined poster in new _CmuGraphics': 'Nicht definiertes Poster in neuem _CmuGraphics', 'Unknown message {{cmd}}': 'Unbekannte Nachricht {{cmd}}', "Use our rounded(n) instead of Python 3's round(n)\n  Python 3's round(n) does not work as one might expect!\n  If you still want Python 3's round, use pythonRound": "Verwenden Sie unsere Funktion rounded(n) anstelle der Python 3 Funktion round(n)\\n Python 3's round(n) funktioniert nicht wie erwartet!\\n Wenn Sie die Funktion round() von Python 3 weiterhin verwenden möchten, dann nutzen Sie pythonRound", 'Wait for fonts to load before using them': 'Warte, bis Zeichensatz geladen ist, bevor du ihn verwendest', 'Wrong # of points ({{userPtsLen}} should be {{solnPtsLen}})': 'Falsche Anzahl von Punkten ({{userPtsLen}} sollte ${{solnPtsLen}} sein)', 'You are missing {{missingCount}} shape(s)': 'Ihnen fehlen {{missingCount}} Form(en)', "You can't change the size of this group because {{shape}} can't be resized": 'Sie können die Größe dieser Gruppe nicht ändern, da die Größe von {{form}} nicht geändert werden kann', "You can't get or set the align property": 'Sie können die Align-Eigenschaft nicht abrufen oder festlegen', 'You have {{extraCount}} extra shape(s)': 'Du hast {{extraCount}} zusätzliche Form(en)', 'Your code appeared to be in an infinite loop, so it was terminated.': 'Your code appeared to be in an infinite loop, so it was terminated.', '\nWarning: Your code created labels with more than\n  1,000 total characters of text. This may cause your\n  program to run very slowly.\n': '\\nWarnung: Ihr Code hat Beschriftungen mit insgesamt mehr als\\n 1.000 Textzeichen erstellt. Dies kann dazu führen, dass Ihr\\n Programm sehr langsam ausgeführt wird.\\n', 'addPoint': 'fügePunktHinzu', 'add{{xy}}': 'addiere{{xy}}', 'app.background should not be {{userBackgroundString}}': 'anwendung.hintergrund sollte nicht {{userBackgroundString}} sein', 'app.setMaxShapeCount(n)': 'anwendung.setzeMaxFormAnzahl(n)', 'at line': 'in Zeile', 'black': 'schwarz', 'bottom-left': 'unten-links', 'bottom-right': 'unten-rechts', 'center': 'mitte', 'centroidX': 'mittelpunktX', 'centroidY': 'mittelpunktY', 'color': 'Farbe', 'containsShape(targetShape)': 'beinhaltetForm(zielForm)', 'gradient({{colors}}, start={{start}})': 'gradient({{colors}}, start={{start}})', 'hits(x, y)': 'trifft(x,y)', 'hitsShape(targetShape)': 'trifftForm(zielForm)', 'initialPoints (x value)': 'anfangsPunkte (x wert)', 'initialPoints (y value)': 'anfangsPunkte (y wert)', 'integer': 'Integer', 'keys must be a list': 'Schlüssel müssen eine Liste sein', 'left-bottom': 'links-unten', 'left-top': 'links-oben', 'line': 'Linie', 'list': 'Liste', 'n': 'n', 'non-negative-number': 'Nicht-negative Zahl', 'number': 'Nummer', 'number-greater-than-2': 'Zahl-größer-als-2', 'number-in-range-{{lo}}-{{hi}}': 'Aufnahme startet in', 'oval size': 'Größe Oval', 'positive-number': 'Positive Zahl', 'rgb({{r}}, {{g}}, {{b}})': 'RGB({{r}}, {{g}}, {{b}})', 'right-bottom': 'rechts-unten', 'right-top': 'rechts-oben', 'rotate.cx': 'drehung.cx', 'rotate.cy': 'drehung.cy', 'rotate.degrees': 'drehung.winkel', 'scale{{xy}}': 'skaliere{{xy}}', 'shape': 'Form', 'string': 'string', 'targetShape': 'zielForm', 'top-left': 'oben-links', 'top-right': 'oben-rechts', 'x': 'x', 'y': 'y', '{{actual}} != {{expected}}': '{{aktuell}}! = {{erwartet}}', '{{attr}} in {{object}}': '{{attr}} in {{object}}', '{{attr}} should not be {{value}}': '{{attr}} sollte nicht {{value}} sein', '{{ordinalName}} point mismatch at {{location}}': '{{ordinalName}} Punkt stimmt nicht mit {{location}} überein', 'play': 'abspielen', 'pause': 'pausieren', 'restart': 'neustarten', 'loop': 'wiederholen', 'TypeError': 'Typfehler', '{{error}}: in {{callSpec}}, {{value}} is not a legal align value': '{{error}}: in {{callSpec}}, {{value}} is not a legal align value', "{{error}}: {{callSpec}} got an unexpected keyword argument '{{arg}}'": "{{error}}: {{callSpec}} got an unexpected keyword argument '{{arg}}'", 'contains(x, y)': 'beinhaltet(x, y)', 'hitTest(x, y)': 'treffenTest(x, y)', 'addPoint(x, y)': 'fügePunktHinzu(x, y)', 'red': 'red', 'green': 'green', 'blue': 'blue', '{{callSpec}} must start with http:// or https://': '{{callSpec}} muss mit http:// or https:// beginnen'}}


# end_translate
# fmt: on

cmuGraphicsLanguage = 'en'


def deburr(s):
    return re.sub('[\u0300-\u036f]', '', unicodedata.normalize('NFD', s))


def accentCombinations(word):
    if word == '':
        return ['']

    output = []
    partials = accentCombinations(word[1:])

    letter = word[0]
    deburredLetter = deburr(letter)

    for partial in partials:
        output.append(letter + partial)
        if letter != deburredLetter:
            output.append(deburredLetter + partial)

    return output


def reverseTranslationDict(d):
    reverseDict = dict()
    for language in d:
        if language != 'keys':
            reverseDict[language] = dict()
            for key in d[language]:
                for accentCombination in accentCombinations(d[language][key]):
                    reverseDict[language][accentCombination] = key

    reverseDict['en'] = dict()
    for key in d['keys']:
        reverseDict['en'][key] = key

    return reverseDict


REVERSE_TRANSLATED_COLOR_NAMES = reverseTranslationDict(TRANSLATED_COLOR_NAMES)
REVERSE_TRANSLATED_GRADIENT_STARTS = reverseTranslationDict(TRANSLATED_GRADIENT_STARTS)
REVERSE_TRANSLATED_ALIGNS = reverseTranslationDict(TRANSLATED_ALIGNS)
REVERSE_TRANSLATED_SHAPE_ATTRS = reverseTranslationDict(TRANSLATED_SHAPE_ATTRS)
REVERSE_TRANSLATED_BOOLEANS = reverseTranslationDict(TRANSLATED_BOOLEANS)
REVERSE_TRANSLATED_GLOBALS = reverseTranslationDict(TRANSLATED_GLOBALS)
REVERSE_TRANSLATED_CPCS_GLOBALS = reverseTranslationDict(TRANSLATED_CPCS_GLOBALS)
REVERSE_TRANSLATED_USER_FUNCTION_NAMES = reverseTranslationDict(
    TRANSLATED_USER_FUNCTION_NAMES
)
REVERSE_TRANSLATED_KEY_NAMES = reverseTranslationDict(TRANSLATED_KEY_NAMES)
REVERSE_TRANSLATED_APP_ATTRS = reverseTranslationDict(TRANSLATED_APP_ATTRS)
REVERSE_TRANSLATED_STRINGS = reverseTranslationDict(TRANSLATED_STRINGS)

for language in TRANSLATED_USER_FUNCTION_NAMES:
    if language == 'keys':
        continue
    for en_name, trans_name in TRANSLATED_USER_FUNCTION_NAMES[language].items():
        TRANSLATED_USER_FUNCTION_NAMES[language][en_name] = accentCombinations(
            trans_name
        )

TRANSLATION_CONTEXT_LOOKUP = {
    'shape-attr': REVERSE_TRANSLATED_SHAPE_ATTRS,
    'align': REVERSE_TRANSLATED_ALIGNS,
    'gradient-start': REVERSE_TRANSLATED_GRADIENT_STARTS,
    'color': REVERSE_TRANSLATED_COLOR_NAMES,
    'boolean': REVERSE_TRANSLATED_BOOLEANS,
    'global': REVERSE_TRANSLATED_GLOBALS,
    'cpcs-global': REVERSE_TRANSLATED_CPCS_GLOBALS,
    'user-function-name': REVERSE_TRANSLATED_USER_FUNCTION_NAMES,
    'key-name': REVERSE_TRANSLATED_KEY_NAMES,
    'app-attr': REVERSE_TRANSLATED_APP_ATTRS,
}


def getOrDefault(d, key):
    if d is not None and key in d:
        return d[key]
    return key


def reverseSearchLanguageDict(d, key):
    if key in d[cmuGraphicsLanguage]:
        return d[cmuGraphicsLanguage][key], cmuGraphicsLanguage

    for language in d:
        if language != cmuGraphicsLanguage and key in d[language]:
            return d[language][key], language

    return key, None


# t() and toEnglish() run many times per frame (every shape attribute read
# translates its default value), but the translation tables never change once
# built. Remember results per language, only for keys whose type is exactly
# str: the uncached path returns the key object itself when it has no
# translation, and other key types (str subclasses with their own __eq__,
# unhashable values) must keep that identity and raise the same errors.
_tCache = {}
# Keys can come from student code (attribute names, colors), so a program
# that makes up endless new strings could grow the caches forever. Start
# over past this size instead.
_MAX_TRANSLATION_CACHE_SIZE = 10000
# Values that can never equal a translation table key (all keys are str)
_UNTRANSLATABLE_TYPES = (type(None), bool, int, float)


def t(key, variables=None, language=None):
    if language is None:
        language = cmuGraphicsLanguage

    if variables is None:
        keyType = type(key)
        if keyType in _UNTRANSLATABLE_TYPES:
            return key
        if keyType is str:
            cacheKey = (key, language)
            res = _tCache.get(cacheKey, _tCache)
            if res is _tCache:
                if len(_tCache) >= _MAX_TRANSLATION_CACHE_SIZE:
                    _tCache.clear()
                res = _tCache[cacheKey] = getOrDefault(
                    TRANSLATED_STRINGS.get(language), key
                )
            return res

    res = getOrDefault(TRANSLATED_STRINGS.get(language), key)

    if variables is not None:
        for v in variables:
            res = res.replace('{{%s}}' % v, str(variables[v]))

    return res


_toEnglishCache = {}


def toEnglish(key, context, returnLanguage=False):
    if type(key) is str:
        cacheKey = (key, context, cmuGraphicsLanguage)
        result = _toEnglishCache.get(cacheKey)
        if result is None:
            if len(_toEnglishCache) >= _MAX_TRANSLATION_CACHE_SIZE:
                _toEnglishCache.clear()
            result = _toEnglishCache[cacheKey] = _toEnglishUncached(key, context)
        return result if returnLanguage else result[0]
    result = _toEnglishUncached(key, context)
    return result if returnLanguage else result[0]


def _toEnglishUncached(key, context):
    if context == 'color':
        key = key.lower()

    searchDict = TRANSLATION_CONTEXT_LOOKUP.get(context, None)
    if searchDict is None:
        searchDict = REVERSE_TRANSLATED_STRINGS

    return reverseSearchLanguageDict(searchDict, key)


supportedLanguages = ['en', 'es', 'de']


class CMUException(Exception):
    pass


def printTraceback(exceptionType, exception, tb):
    atexit.unregister(cmu_graphics.check_for_exit_without_run)

    stack = traceback.extract_tb(tb)
    lines = (''.join(traceback.format_list(stack))).splitlines()

    print('An error occurred. Here is the stack trace:')

    while lines:
        try:
            line = lines.pop(0)
            if ', in ' in line:
                line = line[: line.index(', in ')]
            lineNumberLineParts = line.split()
            module = lineNumberLineParts[1]
            lineNumber = int(lineNumberLineParts[-1])
            if lines and lines[0].startswith('    '):
                codeLine = lines.pop(0)

            if not (
                ('loop()' in codeLine)
                or ('cmu_graphics.py' in module)
                or ('shape_logic.py' in module)
                or ('cmu_cs3_graphics.py' in module)
            ):
                print('  %s line %d:\n    %s' % (module, lineNumber, codeLine))
        except Exception:
            pass

    # Remove 'shape_logic.' from the name of any exceptions being printed
    if exceptionType != CMUException:
        print(exceptionType.__name__ + ': ' + str(exception))
    else:
        print('Exception: ' + str(exception))


import __main__

if 'CMU_GRAPHICS_DEBUG' not in __main__.__dict__:
    sys.excepthook = printTraceback


def printFullTracebacks():
    sys.excepthook = sys.__excepthook__


def pyThrow(err):
    raise CMUException(err)


def typeError(obj, attr, value, typeName, isFn):
    if isFn:
        callSpec = t('{{attr}} in {{object}}', {'attr': t(attr), 'object': t(obj)})
    else:
        if isinstance(obj, str):
            callSpec = '{className}.{attr}'.format(className=t(obj), attr=t(attr))
        else:
            callSpec = '{className}.{attr}'.format(
                className=t(obj.__class__.__name__), attr=t(attr)
            )
    valueType = type(value).__name__
    err = t(
        '{{error}}: {{callSpec}} should be {{typeName}} (but {{value}} is of type {{valueType}})',
        {
            'error': t('TypeError'),
            'callSpec': callSpec,
            'typeName': typeName,
            'value': repr(value),
            'valueType': valueType,
        },
    )
    pyThrow(err)


def checkArgCount(clsName, fnName, argNames, args):
    if len(argNames) != len(args):
        if clsName and fnName:
            callSpec = '{clsName}.{fnName}'.format(clsName=clsName, fnName=fnName)
        else:
            callSpec = clsName or fnName
        pyThrow(
            t(
                'Arg Count Error: {{callSpec}}() takes {{argNamesLen}} positional arguments ({{argNames}}), not {{argsLen}}',
                {
                    'callSpec': callSpec,
                    'argNamesLen': len(argNames),
                    'argNames': ','.join(map(t, argNames)),
                    'argsLen': len(args),
                },
            )
        )


def checkInt(obj, attr, value, isFn):
    if not isinstance(value, int):
        typeError(obj, attr, value, t('integer'), isFn)


def checkNumber(obj, attr, value, isFn):
    if not isinstance(value, (int, float)):
        typeError(obj, attr, value, t('number'), isFn)


def checkPositive(obj, attr, value, isFn):
    checkNumber(obj, attr, value, isFn)
    if value <= 0:
        typeError(obj, attr, value, t('positive-number'), isFn)


def checkNonNegative(obj, attr, value, isFn):
    checkNumber(obj, attr, value, isFn)
    if value < 0:
        typeError(obj, attr, value, t('non-negative number'), isFn)


def checkRange(obj, attr, value, lo, hi, isFn):
    if (value < lo) or (value > hi):
        typeError(
            obj,
            attr,
            value,
            t('number-in-range-{{lo}}-{{hi}}', {'lo': lo, 'hi': hi}),
            isFn,
        )


def checkValue(obj, attr, value, isFn):
    pass


def checkIntInRange(obj, attr, value, lo, hi, isFn):
    checkInt(obj, attr, value, isFn)
    checkRange(obj, attr, value, lo, hi, isFn)


def checkNumberInRange(obj, attr, value, lo, hi, isFn):
    checkNumber(obj, attr, value, isFn)
    checkRange(obj, attr, value, lo, hi, isFn)


def checkNumberIn0To100(obj, attr, value, isFn):
    checkNumberInRange(obj, attr, value, 0, 100, isFn)


def checkShape(obj, attr, value, isFn):
    if not isinstance(value, Shape):
        typeError(obj, attr, value, t('Shape'), isFn)


def checkWidthHeight(obj, attr, value, isFn):
    if isinstance(obj, (Rect, Oval, PolygonInCircle, CMUImage)):
        return checkPositive(obj, attr, value, isFn)
    return checkNonNegative(obj, attr, value, isFn)


def checkColor(obj, attr, value, isFn):
    if value is None or isinstance(value, RGB) or isinstance(value, Gradient):
        return

    if not isinstance(value, str):
        typeError(obj, attr, value, t('color'), isFn)

    if toEnglish(value, 'color').lower() in CSS3_COLORS_TO_RGB:
        return

    objName = obj if isinstance(obj, str) else obj.__class__.__name__
    pyThrow(
        t(
            '{{error}}: {{callSpec}} should be a color, and {{value}} is not a legal color name',
            {
                'error': t('TypeError'),
                'callSpec': f'{t(objName)}.{t(attr)}',
                'value': value,
            },
        )
    )


def checkBoolean(obj, attr, value, isFn):
    if not isinstance(value, bool):
        typeError(obj, attr, value, 'bool', isFn)


def checkArray(obj, attr, value, isFn):
    if not isinstance(value, list) and not isinstance(value, tuple):
        typeError(obj, attr, value, t('list'), isFn)


def checkString(obj, attr, value, isFn):
    if not isinstance(value, str):
        typeError(obj, attr, value, 'string', isFn)


def isPilImage(obj):
    return hasattr(obj, '__class__') and any(
        base.__module__.startswith('PIL.') and base.__name__ == 'Image'
        for base in obj.__class__.__mro__
    )


def checkUrl(obj, attr, value, isFn):
    if not isinstance(value, str) and not isinstance(value, PILWrapper):
        if not isPilImage(value):
            typeError(obj, attr, value, 'string', isFn)
        else:
            err = 'TypeError: The first argument to drawImage or Image should be a string or CMUImage, but you passed a PIL image. Did you forget to wrap a PIL image with CMUImage?'
            pyThrow(err)


def checkBooleanOrArray(obj, attr, value, isFn):
    if not isinstance(value, list) and not isinstance(value, tuple):
        checkBoolean(obj, attr, value, isFn)


def checkAlign(obj, attr, value, isFn):
    if value is None:
        return  # None is a legal align
    if toEnglish(value, 'align') not in aligns:
        pyThrow(
            t(
                '{{error}}: in {{callSpec}}, {{value}} is not a legal align value',
                {
                    'error': t('TypeError'),
                    'callSpec': f'{t(obj.__class__.__name__)}.{t(attr)}',
                    'value': value,
                },
            )
        )


def checkNumPoints(obj, attr, value, isFn):
    checkInt(obj, attr, value, isFn)
    if value < 3:
        typeError(obj, attr, value, 'number-greater-than-2', isFn)


def checkRoundness(obj, attr, value, isFn):
    if value is None:
        return  # None is a legal roundness
    checkNumberIn0To100(obj, attr, value, isFn)


def checkSweepAngle(obj, attr, value, isFn):
    checkNumberInRange(obj, attr, value, 0, 360, isFn)


def checkPoint(obj, attr, value, isFn):
    if not isinstance(value, list):
        typeError(obj, attr, value, 'list', isFn)
    if len(value) != 2:
        typeError(obj, attr, value, 'point (list of length 2)', isFn)
    checkNumber(obj, attr, value[0], isFn)
    checkNumber(obj, attr, value[1], isFn)


def checkPointList(obj, attr, value, isFn):
    if not isinstance(value, list):
        typeError(obj, attr, value, 'list', isFn)
    for point in value:
        # Fast path for a valid point; checkPoint raises the errors otherwise
        if (
            type(point) is list
            and len(point) == 2
            and isinstance(point[0], (int, float))
            and isinstance(point[1], (int, float))
        ):
            continue
        checkPoint(obj, attr, point, isFn)


def toColorObject(v):
    if not v:
        return t('None')
    if isinstance(v, str):
        return CSS3_COLORS_TO_RGB[toEnglish(v, 'color').lower()] or v
    if isinstance(v, RGB) or isinstance(v, Gradient):
        return v
    raise Exception('toColorObject: unknown color type: {t}'.format(t=type(v)))


def RGBAlmostEqual(v1, v2, epsilon=2):
    colorPairs = [[v1.red, v2.red], [v1.green, v2.green], [v1.blue, v2.blue]]
    return all(abs(pair[0] - pair[1]) <= epsilon for pair in colorPairs)


def RGBListAlmostEqual(v1, v2, epsilon):
    if len(v1) != len(v2):
        return False
    for i in range(len(v1)):
        if type(v1[i]) is not type(v2[i]):
            return False
        if isinstance(v1[i], RGB):
            if not RGBAlmostEqual(v1[i], v2[i], epsilon):
                return False
        elif isinstance(v1[i], list) or isinstance(v2[i], tuple):
            if not RGBListAlmostEqual(v1[i], v2[i], epsilon):
                return False
        else:
            raise Exception('RGBListAlmostEqual: invalid type: {t}'.format(t=v1[i]))
    return True


def reflectGradientStart(start):
    def toggle(s, a, b):
        if a in s and b in s:
            raise Exception('Illegal start format: {s}'.format(s=s))
        return s.replace(a, b) if a in s else s.replace(b, a)

    return toggle(toggle(start, 'top', 'bottom'), 'left', 'right')


def colorTest(v1, v2, epsilon):
    v1 = toColorObject(v1)
    v2 = toColorObject(v2)
    if type(v1) is not type(v2):
        return 0
    if isinstance(v1, RGB):
        return 1 if RGBAlmostEqual(v1, v2, epsilon) else 0
    if isinstance(v1, Gradient):
        start1 = canonicalizeGradientStart(v1.start)
        start2 = canonicalizeGradientStart(v2.start)
        if start1 != start2 and start1 != reflectGradientStart(start2):
            return 0
        colors2 = v2.getRGBColors()
        if start1 != start2:
            colors2.reverse()
        return 1 if RGBListAlmostEqual(v1.getRGBColors(), colors2, epsilon) else 0
    return 1 if v1 == v2 else 0


def eqTest(v1, v2):
    if (
        isinstance(v1, int)
        or isinstance(v2, float)
        or isinstance(v2, int)
        or isinstance(v2, float)
    ):
        return 1 if abs(v1 - v2) < 0.005 else 0
    if (isinstance(v1, list) or isinstance(v1, tuple)) and (
        isinstance(v2, list) or isinstance(v2, tuple)
    ):
        if len(v1) != len(v2):
            return 0
        for i in range(len(v1)):
            if eqTest(v1[i], v2[i]) == 0:
                return 0
        return 1
    return 1 if v1 == v2 else 0


def opacityTest(v1, v2):
    return eqTest(v1, v2)


aligns = set(
    [
        'left-top',
        'top',
        'right-top',
        'left',
        'center',
        'right',
        'left-bottom',
        'bottom',
        'right-bottom',
        'top-left',
        'top-right',
        'bottom-left',
        'bottom-right',
    ]
)


def getAlignAttrs(align):
    if 'left' in align:
        xattr = 'left'
    elif 'right' in align:
        xattr = 'right'
    else:
        xattr = 'centerX'
    if 'top' in align:
        yattr = 'top'
    elif 'bottom' in align:
        yattr = 'bottom'
    else:
        yattr = 'centerY'
    return [xattr, yattr]


def wyvernImageFromPilImage(image):
    image = image.convert('RGBA')  # ensure we have the correct number of channels
    a = bytearray(image.tobytes('raw', 'RGBA'))
    return (a, image.size[0], image.size[1], image.size[0] * 4)


class PILWrapper(object):
    def __init__(self, image):
        self.image = image
        # Converted now rather than when first drawn, which would change the
        # wrapper (and maybe the PIL image, which loads its pixels then) while
        # redrawAll runs. Apps keep these in app, so the MVC checker reported
        # that as redrawAll changing the model.
        self._imageParams = wyvernImageFromPilImage(image)
        self.uuid = str(uuid.uuid4())

    def get_params(self):
        if self._imageParams is None:
            self._imageParams = wyvernImageFromPilImage(self.image)
        return self._imageParams

    params = property(get_params, None)


def hashReference(reference):
    if isinstance(reference, PILWrapper):
        return reference.uuid
    return hash(reference)


def loadImageFromStringReference(reference):
    if reference.startswith('http'):
        # reference is a url
        try:
            response = webrequest.get(reference)
            image = wyvern.load_image_from_bytes(BytesIO(response.read()).getvalue())
        except Exception:
            pyThrow(t('Failed to load image data'))
    else:
        # reference is a path
        try:
            image = wyvern.load_image_from_path(reference)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"No file '{reference}' found in working directory '{os.getcwd()}'."
            ) from None
    return image


def loadImage(reference):
    referenceHash = hashReference(reference)
    if referenceHash not in activeDrawing.images:
        if isinstance(reference, PILWrapper):
            imageParams = reference.params
            wyvernImage = wyvern.WyvernImage(*imageParams)
        else:
            wyvernImage = loadImageFromStringReference(reference)
        activeDrawing.images[referenceHash] = wyvernImage
    return {
        'width': activeDrawing.images[referenceHash].width,
        'height': activeDrawing.images[referenceHash].height,
    }


shapeAttrs = dict()
shapeAttrDefaults = dict()


class ShapeAttr(object):
    def __init__(self, name, typeCheckFn, defaultValue):
        self.name = name
        self.typeCheckFn = typeCheckFn
        self.default = defaultValue
        shapeAttrs[name] = self
        shapeAttrDefaults[name] = defaultValue


def initShapeAttrs():
    ShapeAttr('left', checkNumber, 0)
    ShapeAttr('top', checkNumber, 0)
    ShapeAttr('centerX', checkNumber, 0)
    ShapeAttr('centerY', checkNumber, 0)
    ShapeAttr('right', checkNumber, 0)
    ShapeAttr('bottom', checkNumber, 0)
    ShapeAttr('width', checkWidthHeight, 10)
    ShapeAttr('height', checkWidthHeight, 10)
    ShapeAttr('fill', checkColor, 'black')
    ShapeAttr('border', checkColor, None)
    ShapeAttr('borderWidth', checkNonNegative, 2)
    ShapeAttr('dashes', checkBooleanOrArray, False)
    ShapeAttr('opacity', checkNumberIn0To100, 100)
    ShapeAttr('align', checkAlign, None)
    ShapeAttr('rotateAngle', checkNumber, 0)
    ShapeAttr('radius', checkNonNegative, 5)
    ShapeAttr('points', checkNumPoints, 5)
    ShapeAttr('roundness', checkRoundness, 'default')
    ShapeAttr('x1', checkNumber, 0)
    ShapeAttr('y1', checkNumber, 0)
    ShapeAttr('x2', checkNumber, 10)
    ShapeAttr('y2', checkNumber, 10)
    ShapeAttr('arrowStart', checkBoolean, False)
    ShapeAttr('arrowEnd', checkBoolean, False)
    ShapeAttr('lineWidth', checkPositive, 2)
    ShapeAttr('initialPoints', checkArray, [])
    ShapeAttr('pointList', checkPointList, [])
    ShapeAttr('closed', checkBoolean, True)
    ShapeAttr('startAngle', checkNumber, 0)
    ShapeAttr('sweepAngle', checkSweepAngle, 360)
    ShapeAttr('value', checkValue, '')
    ShapeAttr('font', checkString, 'arial')
    ShapeAttr('size', checkNonNegative, 12)
    ShapeAttr('bold', checkBoolean, False)
    ShapeAttr('italic', checkBoolean, False)
    ShapeAttr('visible', checkBoolean, True)
    ShapeAttr('url', checkUrl, None)
    ShapeAttr('db', checkValue, '')
    ShapeAttr('group', checkValue, None)
    ShapeAttr('isMvc', checkBoolean, False)


initShapeAttrs()


# This metaclass prevents 'cmu_graphics.' from being included in the name
# of the type, when type() is called on a Shape/rgb/gradient instance
class _ShapeMetaclass(type):
    def __repr__(cls):
        return "<class '" + t(cls.__name__) + "'>"

    def __str__(cls):
        return "<class '" + t(cls.__name__) + "'>"


class RGB(object, metaclass=_ShapeMetaclass):
    def __init__(self, red, green, blue):
        # What setting each of these with __setattr__ does, without going
        # through __setattr__ (rgb() is often called many times per frame)
        fields = self.__dict__
        fields['_attrs'] = {'class': self.__class__.__name__}
        for attr, value in (('red', red), ('green', green), ('blue', blue)):
            if not ((type(value) is int or type(value) is float) and 0 <= value <= 255):
                checkNumberInRange(self, attr, value, 0, 255, False)
            fields['_' + attr] = value
        fields['_strVal'] = f'rgb({red}, {green}, {blue})'

    def __getattr__(self, attr):
        en_attr = toEnglish(attr, 'shape-attr')
        if en_attr in ['red', 'green', 'blue']:
            return self.__dict__['_' + en_attr]
        elif attr[0] == '_':
            return self.__dict__[attr]
        else:
            raise AttributeError(f"'{t('rgb')}' object has no attribute '{attr}'")

    def __setattr__(self, attr, value):
        if attr[0] == '_':
            if attr[1:] in ['red', 'green', 'blue']:
                checkNumberInRange(self, attr[1:], value, 0, 255, False)
            self.__dict__[attr] = value
        else:
            raise Exception(
                t(
                    "Cannot modify attribute '{{attr}}' of '{{className}}' object",
                    {'attr': attr, 'className': t('rgb')},
                )
            )

    def darker(self):
        k = 0.85
        return RGB(round(k * self.red), round(k * self.green), round(k * self.blue))

    def lighter(self):
        k = 0.85
        return RGB(
            round(255 - k * (255 - self.red)),
            round(255 - k * (255 - self.green)),
            round(255 - k * (255 - self.blue)),
        )

    def toString(self):
        return self._strVal

    def __str__(self):
        return self._strVal

    def __repr__(self):
        return self._strVal

    # red, green, and blue are __dict__['_red'] and so on (see __getattr__),
    # read directly since colors are hashed and compared often
    def __eq__(self, other):
        if not isinstance(other, RGB):
            return False
        fields = self.__dict__
        otherFields = other.__dict__
        return (
            fields['_red'] == otherFields['_red']
            and fields['_green'] == otherFields['_green']
            and fields['_blue'] == otherFields['_blue']
        )

    def __hash__(self):
        fields = self.__dict__
        return hash((fields['_red'], fields['_green'], fields['_blue']))


RGB.__name__ = 'rgb'


CSS3_COLORS_TO_RGB = {
    'aliceblue': RGB(240, 248, 255),
    'antiquewhite': RGB(250, 235, 215),
    'aqua': RGB(0, 255, 255),
    'aquamarine': RGB(127, 255, 212),
    'azure': RGB(240, 255, 255),
    'beige': RGB(245, 245, 220),
    'bisque': RGB(255, 228, 196),
    'black': RGB(0, 0, 0),
    'blanchedalmond': RGB(255, 235, 205),
    'blue': RGB(0, 0, 255),
    'blueviolet': RGB(138, 43, 226),
    'brown': RGB(165, 42, 42),
    'burlywood': RGB(222, 184, 135),
    'cadetblue': RGB(95, 158, 160),
    'chartreuse': RGB(127, 255, 0),
    'chocolate': RGB(210, 105, 30),
    'coral': RGB(255, 127, 80),
    'cornsilk': RGB(255, 248, 220),
    'cornflowerblue': RGB(100, 149, 237),
    'crimson': RGB(220, 20, 60),
    'cyan': RGB(0, 255, 255),
    'darkblue': RGB(0, 0, 139),
    'darkcyan': RGB(0, 139, 139),
    'darkgoldenrod': RGB(184, 134, 11),
    'darkgray': RGB(169, 169, 169),
    'darkgreen': RGB(0, 100, 0),
    'darkgrey': RGB(169, 169, 169),
    'darkkhaki': RGB(189, 183, 107),
    'darkmagenta': RGB(139, 0, 139),
    'darkolivegreen': RGB(85, 107, 47),
    'darkorange': RGB(255, 140, 0),
    'darkorchid': RGB(153, 50, 204),
    'darkred': RGB(139, 0, 0),
    'darksalmon': RGB(233, 150, 122),
    'darkseagreen': RGB(143, 188, 143),
    'darkslateblue': RGB(72, 61, 139),
    'darkslategray': RGB(47, 79, 79),
    'darkslategrey': RGB(47, 79, 79),
    'darkturquoise': RGB(0, 206, 209),
    'darkviolet': RGB(148, 0, 211),
    'deeppink': RGB(255, 20, 147),
    'deepskyblue': RGB(0, 191, 255),
    'dimgray': RGB(105, 105, 105),
    'dimgrey': RGB(105, 105, 105),
    'dodgerblue': RGB(30, 144, 255),
    'firebrick': RGB(178, 34, 34),
    'floralwhite': RGB(255, 250, 240),
    'forestgreen': RGB(34, 139, 34),
    'fuchsia': RGB(255, 0, 255),
    'gainsboro': RGB(220, 220, 220),
    'ghostwhite': RGB(248, 248, 255),
    'gold': RGB(255, 215, 0),
    'goldenrod': RGB(218, 165, 32),
    'gray': RGB(128, 128, 128),
    'green': RGB(0, 128, 0),
    'greenyellow': RGB(173, 255, 47),
    'grey': RGB(128, 128, 128),
    'honeydew': RGB(240, 255, 240),
    'hotpink': RGB(255, 105, 180),
    'indianred': RGB(205, 92, 92),
    'indigo': RGB(75, 0, 130),
    'ivory': RGB(255, 255, 240),
    'khaki': RGB(240, 230, 140),
    'lavender': RGB(230, 230, 250),
    'lavenderblush': RGB(255, 240, 245),
    'lawngreen': RGB(124, 252, 0),
    'lemonchiffon': RGB(255, 250, 205),
    'lightblue': RGB(173, 216, 230),
    'lightcoral': RGB(240, 128, 128),
    'lightcyan': RGB(224, 255, 255),
    'lightgoldenrodyellow': RGB(250, 250, 210),
    'lightgray': RGB(211, 211, 211),
    'lightgreen': RGB(144, 238, 144),
    'lightgrey': RGB(211, 211, 211),
    'lightpink': RGB(255, 182, 193),
    'lightsalmon': RGB(255, 160, 122),
    'lightseagreen': RGB(32, 178, 170),
    'lightskyblue': RGB(135, 206, 250),
    'lightslategray': RGB(119, 136, 153),
    'lightslategrey': RGB(119, 136, 153),
    'lightsteelblue': RGB(176, 196, 222),
    'lightyellow': RGB(255, 255, 224),
    'lime': RGB(0, 255, 0),
    'limegreen': RGB(50, 205, 50),
    'linen': RGB(250, 240, 230),
    'magenta': RGB(255, 0, 255),
    'maroon': RGB(128, 0, 0),
    'mediumaquamarine': RGB(102, 205, 170),
    'mediumblue': RGB(0, 0, 205),
    'mediumorchid': RGB(186, 85, 211),
    'mediumpurple': RGB(147, 112, 216),
    'mediumseagreen': RGB(60, 179, 113),
    'mediumslateblue': RGB(123, 104, 238),
    'mediumspringgreen': RGB(0, 250, 154),
    'mediumturquoise': RGB(72, 209, 204),
    'mediumvioletred': RGB(199, 21, 133),
    'midnightblue': RGB(25, 25, 112),
    'mintcream': RGB(245, 255, 250),
    'mistyrose': RGB(255, 228, 225),
    'moccasin': RGB(255, 228, 181),
    'navajowhite': RGB(255, 222, 173),
    'navy': RGB(0, 0, 128),
    'oldlace': RGB(253, 245, 230),
    'olive': RGB(128, 128, 0),
    'olivedrab': RGB(107, 142, 35),
    'orange': RGB(255, 165, 0),
    'orangered': RGB(255, 69, 0),
    'orchid': RGB(218, 112, 214),
    'palegoldenrod': RGB(238, 232, 170),
    'palegreen': RGB(152, 251, 152),
    'paleturquoise': RGB(175, 238, 238),
    'palevioletred': RGB(216, 112, 147),
    'papayawhip': RGB(255, 239, 213),
    'peachpuff': RGB(255, 218, 185),
    'peru': RGB(205, 133, 63),
    'pink': RGB(255, 192, 203),
    'plum': RGB(221, 160, 221),
    'powderblue': RGB(176, 224, 230),
    'purple': RGB(128, 0, 128),
    'red': RGB(255, 0, 0),
    'rosybrown': RGB(188, 143, 143),
    'royalblue': RGB(65, 105, 225),
    'saddlebrown': RGB(139, 69, 19),
    'salmon': RGB(250, 128, 114),
    'sandybrown': RGB(244, 164, 96),
    'seagreen': RGB(46, 139, 87),
    'seashell': RGB(255, 245, 238),
    'sienna': RGB(160, 82, 45),
    'silver': RGB(192, 192, 192),
    'skyblue': RGB(135, 206, 235),
    'slateblue': RGB(106, 90, 205),
    'slategray': RGB(112, 128, 144),
    'slategrey': RGB(112, 128, 144),
    'snow': RGB(255, 250, 250),
    'springgreen': RGB(0, 255, 127),
    'steelblue': RGB(70, 130, 180),
    'tan': RGB(210, 180, 140),
    'teal': RGB(0, 128, 128),
    'thistle': RGB(216, 191, 216),
    'tomato': RGB(255, 99, 71),
    'turquoise': RGB(64, 224, 208),
    'violet': RGB(238, 130, 238),
    'wheat': RGB(245, 222, 179),
    'white': RGB(255, 255, 255),
    'whitesmoke': RGB(245, 245, 245),
    'yellow': RGB(255, 255, 0),
    'yellowgreen': RGB(154, 205, 50),
}

gradientStarts = [
    'left-top',
    'top',
    'right-top',
    'left',
    'center',
    'right',
    'left-bottom',
    'bottom',
    'right-bottom',
]

alternateGradientStarts = {
    'top-left': 'left-top',
    'top-right': 'right-top',
    'bottom-left': 'left-bottom',
    'bottom-right': 'right-bottom',
}


def canonicalizeGradientStart(start):
    start = toEnglish(start, 'gradient-start')
    if start in alternateGradientStarts:
        return alternateGradientStarts[start]
    return start


class Gradient(object, metaclass=_ShapeMetaclass):
    def __init__(self, colors, start):
        checkArray(self, t('colors'), colors, False)
        if len(colors) < 2:
            pyThrow(
                t(
                    'Need to pass at least 2 colors to gradient(); you gave {{colorLen}}',
                    {'colorLen': len(colors)},
                )
            )
        for color in colors:
            if color is None:
                pyThrow(
                    t(
                        '{{error}}: None cannot be used inside gradient.colors',
                        {'error': t('TypeError')},
                    )
                )
            if isinstance(color, Gradient):
                pyThrow(
                    t(
                        '{{error}}: {{color}} cannot be used inside gradient.colors',
                        {'color': color, 'error': t('TypeError')},
                    )
                )
            checkColor(self, 'colors', color, False)
        checkString(self, t('start'), start, False)
        if (toEnglish(start, 'gradient-start') not in gradientStarts) and (
            toEnglish(start, 'gradient-start') not in alternateGradientStarts
        ):
            pyThrow(
                t(
                    '{{error}}: Illegal gradient start ({{start}})',
                    {'error': t('TypeError'), 'start': start},
                )
            )
        self.attrs = {
            'class': self.__class__.__name__,
            'colors': colors,
            'start': start,
        }

    def toString(self):
        colors = ', '.join([repr(c) for c in self.colors])
        return f"{t('gradient')}({colors}, {t('start')}='{t(self.start)}')"

    def getRGBColors(self):
        return list(
            map(
                lambda v: (
                    v
                    if isinstance(v, RGB)
                    else CSS3_COLORS_TO_RGB[toEnglish(v, 'color').lower()]
                ),
                self.colors,
            )
        )

    def toRGBList(self):
        if self.start == 'center':
            return self.getRGBColors()
        return sorted([self.getRGBColors(), reversed(self.getRGBColors())])

    def __getattr__(self, attr):
        en_attr = toEnglish(attr, 'shape-attr')
        if en_attr == 'start':
            if attr == 'start':
                return self.attrs['start']
            return t(self.attrs['start'])
        elif en_attr == 'colors':
            return self.attrs['colors']
        raise AttributeError(f"'{t('gradient')}' object has no attribute '{attr}'")

    def __setattr__(self, attr, val):
        if attr == 'attrs':
            self.__dict__[attr] = val
            return val
        else:
            raise Exception(
                t(
                    "Cannot modify attribute '{{attr}}' of '{{className}}' object",
                    {'attr': attr, 'className': t('gradient')},
                )
            )

    def __eq__(self, other):
        if not isinstance(other, Gradient):
            return False
        if len(self.colors) != len(other.colors):
            return False
        if canonicalizeGradientStart(self.start) != canonicalizeGradientStart(
            other.start
        ):
            return False
        for i in range(len(self.colors)):
            c1 = self.colors[i]
            c2 = other.colors[i]
            if type(c1) is not type(c2):
                return False
            if c1 != c2:
                return False
        return True

    def __repr__(self):
        return self.toString()

    def __str__(self):
        return self.toString()


Gradient.__name__ = 'gradient'


class Drawing(object):
    def __init__(self):
        self.tlg = None
        self.images = {}
        self.addCounter = 0
        self.appProperties = {'maxShapeCount': 2000}
        self.nextShapeId = 0


activeDrawing = Drawing()

"""
 Shape
 ├ Group
 ├ Label
 └ Polygon
    ├ Rect
    ├ Line
    ├ PolygonInCircle
    │ ├ RegularPolygon
    │ └ Star
    └ PolygonWithTransform
      ├ CMUImage
      └ Oval
        ├ Arc
        └ Circle
"""


def shape_property(getter, setter=None):
    # Every shape attribute read goes through here, so this inlines
    # utils.truncateIntegerFloats
    def shape_getter(self):
        value = getter(self)
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value

    return property(shape_getter, setter)


def _topLevelGroupShape():
    # activeDrawing.tlg is the app's group as students see it (a
    # cmu_graphics.Group), which wraps the Group that shapes are added to
    tlg = activeDrawing.tlg
    return getattr(tlg, '_shape', tlg)


def addToTopLevelGroup(shape):
    # Same as activeDrawing.tlg.add(shape), which goes through
    # cmu_graphics.Shape.__getattr__ and slGet/slApply to call this
    tlgShape = _topLevelGroupShape()
    if not isinstance(tlgShape, Group):
        activeDrawing.tlg.add(shape)
    elif shape._group is None and shape.oldGroup is None and not shape.isGroup:
        tlgShape.addNewShape(shape)
    else:
        tlgShape.add(shape)


# Translated default attribute values, by language then attribute name. Only
# for shapeAttrDefaults, and only defaults that t() accepts (it raises for
# unhashable ones like []).
_translatedDefaults = {}
_NO_DEFAULT = object()


def translatedDefault(attrDefaults, name):
    if attrDefaults is not shapeAttrDefaults:
        return t(attrDefaults[name])
    byName = _translatedDefaults.get(cmuGraphicsLanguage)
    if byName is None:
        byName = _translatedDefaults[cmuGraphicsLanguage] = {}
    value = byName.get(name, _NO_DEFAULT)
    if value is _NO_DEFAULT:
        value = t(attrDefaults[name])
        byName[name] = value
    return value


def attr_property(name, getter, setter=None):
    # The same as shape_property(getter, setter), for a getter that only
    # returns self.get(name), with Shape.get and shape_getter inlined. Shape
    # attributes are read many times per shape per frame, and this saves
    # three function calls per read.
    def attr_getter(self):
        attrs = self.attrs
        if name in attrs:
            value = attrs[name]
        else:
            # Translate so the default shape fill is determined by user language
            value = translatedDefault(self.attrDefaults, name)
        if isinstance(value, float) and value.is_integer():
            return int(value)
        return value

    return property(attr_getter, setter)


class Shape(object):
    def __init__(self, attrs=None):
        self.id = activeDrawing.nextShapeId
        activeDrawing.nextShapeId += 1

        self._group = self.oldGroup = None
        # A list of shapes that this shape was in front of its current/previous group
        self.shapesToBeInFrontOf = []
        self.shapesInOldGroup = {}
        self.isGroup = False
        # zIndex is global across all groups
        self.zindex = -1
        self.attrs = {'class': self.__class__.__name__}
        if attrs is not None:
            if 'defaultAlign' in attrs:
                self.defaultAlign = attrs['defaultAlign']
                del attrs['defaultAlign']
            else:
                self.defaultAlign = t('center')
        self.attrDefaults = shapeAttrDefaults
        if attrs is not None:
            self.set(attrs)
        if (not attrs or not attrs.get('noGroup', False)) and (
            activeDrawing.tlg is not None
        ):
            addToTopLevelGroup(self)

    def get(self, attr):
        attrs = self.attrs
        if attr in attrs:
            return attrs[attr]
        # Translate so the default shape fill is determined by user language
        return translatedDefault(self.attrDefaults, attr)

    def setAttr(self, attr, value):
        self.attrs[attr] = value
        return value

    def set(self, attrs):
        result = None
        ownAttrs = self.attrs
        for attr in attrs:
            value = attrs[attr]
            attrSpec = shapeAttrs.get(attr, None)
            if attrSpec is not None:
                attrSpec.typeCheckFn(self, attr, value, False)
            # Inlined setAttr
            ownAttrs[attr] = value
            result = value
            # TODO: Handle labels
        return result

    def get_group(self):
        return self._group

    def set_group(self, v):
        pyThrow(t("You can't set the group property"))

    group = shape_property(get_group, set_group)

    def get_align(self):
        pyThrow(t("You can't get or set the align property"))

    def set_align(self, v):
        pyThrow(t("You can't get or set the align property"))

    align = shape_property(get_align, set_align)

    def get_doNotInspect(self):
        return self.attrs.get('doNotInspect', None)

    def set_doNotInspect(self, v):
        self.attrs['doNotInspect'] = v
        return v

    doNotInspect = shape_property(get_doNotInspect, set_doNotInspect)

    def get_centerX(self):
        return self.get('centerX', None)

    def set_centerX(self, v):
        self.set({'centerX', v})
        return v

    centerX = shape_property(get_centerX, set_centerX)

    def get_centerY(self):
        return self.get('centerY', None)

    def set_centerY(self, v):
        self.set({'centerY', v})
        return v

    centerY = shape_property(get_centerY, set_centerY)

    def get_left(self):
        return self.centerX - self.width / 2

    def set_left(self, v):
        self.addx(v - self.left)
        return v

    left = shape_property(get_left, set_left)

    def get_top(self):
        return self.centerY - self.height / 2

    def set_top(self, v):
        self.centerY = v + self.height / 2
        return v

    top = shape_property(get_top, set_top)

    def get_right(self):
        return self.centerX + self.width / 2

    def set_right(self, v):
        self.centerX = v - self.width / 2
        return v

    right = shape_property(get_right, set_right)

    def get_bottom(self):
        return self.centerY + self.height / 2

    def set_bottom(self, v):
        self.centerY = v - self.height / 2
        return v

    bottom = shape_property(get_bottom, set_bottom)

    def addxy(self, varName=None, d=None):
        if d == 0:
            return
        if varName == 'x':
            self.centerX += d
        else:
            self.centerY += d

    def addx(self, dx):
        self.addxy('x', dx)

    def addy(self, dy):
        self.addxy('y', dy)

    def get_centroidX(self):
        return self.centroid[0]

    def set_centroidX(self, v):
        self.addx(v - self.centroidX)

    centroidX = shape_property(get_centroidX, set_centroidX)

    def get_centroidY(self):
        return self.centroid[1]

    def set_centroidY(self, v):
        self.addy(v - self.centroidY)

    centroidY = shape_property(get_centroidY, set_centroidY)

    def get_width(self):
        return self.get('width')

    def set_width(self, v):
        self.scalexy('x', v / self.width)
        self.set({'width': v})

    width = attr_property('width', get_width, set_width)

    def get_height(self):
        return self.get('height')

    def set_height(self, v):
        self.scalexy('y', v / self.height)
        self.set({'height': v})

    height = attr_property('height', get_height, set_height)

    def get_fill(self):
        return self.get('fill')

    def set_fill(self, v):
        return self.set({'fill': v})

    fill = attr_property('fill', get_fill, set_fill)

    def get_border(self):
        return self.get('border')

    def set_border(self, v):
        return self.set({'border': v})

    border = attr_property('border', get_border, set_border)

    def get_borderWidth(self):
        return self.get('borderWidth')

    def set_borderWidth(self, v):
        return self.set({'borderWidth': v})

    borderWidth = attr_property('borderWidth', get_borderWidth, set_borderWidth)

    def get_dashes(self):
        return self.get('dashes')

    def set_dashes(self, v):
        return self.set({'dashes': v})

    dashes = attr_property('dashes', get_dashes, set_dashes)

    def get_opacity(self):
        return self.get('opacity')

    def set_opacity(self, v):
        return self.set({'opacity': v})

    opacity = attr_property('opacity', get_opacity, set_opacity)

    def get_closed(self):
        return self.get('closed')

    def set_closed(self, v):
        return self.set({'closed': v})

    closed = attr_property('closed', get_closed, set_closed)

    def get_db(self):
        return self.get('db')

    def set_db(self, v):
        return self.set({'db': v})

    db = attr_property('db', get_db, set_db)

    def get_visible(self):
        return (self._group is not None) and (
            self._group.visible or self._group == activeDrawing.tlg._shape
        )

    def set_visible(self, v):
        if v == self.visible:
            return
        if v:
            if self.oldGroup:
                self.oldGroup.insert(self)
            else:
                activeDrawing.tlg.add(self)
        else:
            self._group.remove(self)

    visible = shape_property(get_visible, set_visible)

    def doAlign(self, x, y, v):
        v = toEnglish(v, 'align')
        [xattr, yattr] = getAlignAttrs(v)
        setattr(self, xattr, x)
        setattr(self, yattr, y)

    def get_centroid(self):
        return [self.centerX, self.centerY]

    def set_centroid(self, v):
        pyThrow('Centroid cannot be set')

    centroid = shape_property(get_centroid, set_centroid)

    def getRotateAnchor(self):
        return self.centroid

    def get_rotateAngle(self):
        return self.get('rotateAngle')

    def set_rotateAngle(self, v):
        self._rotate(v - self.rotateAngle)

    rotateAngle = attr_property('rotateAngle', get_rotateAngle, set_rotateAngle)

    def rotate(self, *arguments):
        checkArgCount(
            self.__class__.__name__,
            t('rotate'),
            [t('degrees'), t('x'), t('y')],
            arguments,
        )
        degrees, x, y = arguments

        checkNumber(t('rotate(degrees, x, y)'), t('degrees'), degrees, True)
        checkNumber(t('rotate(degrees, x, y)'), t('x'), x, True)
        checkNumber(t('rotate(degrees, x, y)'), t('y'), y, True)
        self._rotate(degrees, x, y)

    def _rotate(self, degrees=None, cx=None, cy=None):
        # Internal method used by rotate, no typechecking
        if cx is None and cy is None:
            cx, cy = self.getRotateAnchor()
            cx = utils.round6(cx)
            cy = utils.round6(cy)
        self.set({'rotateAngle': self.rotateAngle + degrees})
        self.doRotate(degrees, cx, cy)

    def doRotate(self, degrees, cx, cy):
        pyThrow('Must override doRotate method!')

    def toString(self):
        return t('Shape()')

    def _toString(self):
        return self.toString()  # so cmu_graphics can access toString

    def contains(self, *arguments):  # contains(x,y)
        checkArgCount(
            self.__class__.__name__, t('contains'), [t('x'), t('y')], arguments
        )
        x, y = arguments
        checkNumber(t('contains(x, y)'), 'x', x, True)
        checkNumber(t('contains(x, y)'), 'y', y, True)
        return utils.polygonContainsPoint(self.getApproxPoints(), x, y)

    def _filled(self):
        return self.fill is not None or isinstance(self, CMUImage)

    def _hits(self, x, y):
        # Internal method used by hitsShape and hits, no typechecking
        pts = self.getApproxPoints()
        if not utils.polygonContainsPoint(pts, x, y):
            return False
        if self._filled():
            return True
        border = self.border
        if not border:
            return False
        # ok, so we have a border, but no fill, so we 'hit' if we
        # are within a borderWidth of the border
        bw = self.borderWidth if border else 0
        return utils.pointNearPolygonBorder(pts, x, y, bw)

    def hits(self, *arguments):  # hits(x,y)
        checkArgCount(self.__class__.__name__, t('hits'), [t('x'), t('y')], arguments)
        x, y = arguments
        checkNumber(t('hits(x, y)'), t('x'), x, True)
        checkNumber(t('hits(x, y)'), t('y'), y, True)
        return self._hits(x, y)

    def containsShape(self, *arguments):
        checkArgCount(
            self.__class__.__name__, t('containsShape'), [t('targetShape')], arguments
        )
        (targetShape,) = arguments
        checkShape(t('containsShape(targetShape)'), t('targetShape'), targetShape, True)

        if isinstance(targetShape, Group):
            return all([self.containsShape(shape) for shape in targetShape._shapes])

        # This shapes fully contains the target shape if their
        # edges do not intersect, but (any point of / all points of)
        # the targetShape are inside this shape
        x = targetShape.centerX
        y = targetShape.centerY
        return not pygeo.edgesIntersect(
            self.getApproxPoints(), targetShape.getApproxPoints()
        ) and self.contains(x, y)

    def getBounds(self):
        return {
            'left': self.left,
            'top': self.top,
            'width': self.width,
            'height': self.height,
        }

    def boundsIntersect(self, targetShape, margin=None):
        # Symmetric.  Fast pre-test for hitsShape.  If this is False, hitsShape
        # must be False.  If this is True, hitsShape *may* be True.
        if margin is None:
            margin = 0
        b1 = self.getBounds()
        b2 = targetShape.getBounds()
        return (
            (b1['left'] + margin <= b2['left'] + b2['width'])
            and (b2['left'] + margin <= b1['left'] + b1['width'])
            and (b1['top'] + margin <= b2['top'] + b2['height'])
            and (b2['top'] + margin <= b1['top'] + b1['height'])
        )

    def hitsShape(self, *arguments):
        checkArgCount(
            self.__class__.__name__, t('hitsShape'), [t('targetShape')], arguments
        )
        (targetShape,) = arguments
        checkShape(t('hitsShape(targetShape)'), t('targetShape'), targetShape, True)
        # Symmetric.  Two shapes hit each other if any of their
        # vertices hit the other or their edges intersect.
        myShapes = utils.getChildShapes(self)
        allTargetShapes = utils.getChildShapes(targetShape)
        targetShapes = []

        for targetShape in allTargetShapes:
            if any(targetShape.boundsIntersect(myShape) for myShape in myShapes):
                targetShapes.append(targetShape)

        myShapesPoints = [shape.getApproxPoints() for shape in myShapes]
        targetShapesPoints = [shape.getApproxPoints() for shape in targetShapes]

        for i in range(len(myShapes)):
            for j in range(len(targetShapes)):
                if pygeo.edgesIntersect(myShapesPoints[i], targetShapesPoints[j]):
                    return True

        targetApproxPoints = [shape.getApproxPoints() for shape in targetShapes]

        for i in range(len(myShapes)):
            shape1 = myShapes[i]
            shape1ApproxPoints = shape1.getApproxPoints()
            if len(shape1ApproxPoints) == 0:
                continue
            shape1Vertex = shape1ApproxPoints[0]

            for j in range(len(targetShapes)):
                shape2 = targetShapes[j]
                shape2ApproxPoints = targetApproxPoints[j]

                if shape1._filled() and shape2._filled():
                    if len(shape2ApproxPoints) == 0:
                        continue

                    targetVertex = shape2ApproxPoints[0]

                    if shape2._hits(shape1Vertex[0], shape1Vertex[1]):
                        return True
                    if shape1._hits(targetVertex[0], targetVertex[1]):
                        return True

                if not shape2._filled():
                    if any((shape2._hits(pt[0], pt[1]) for pt in shape1ApproxPoints)):
                        return True

                if not shape1._filled():
                    if any((shape1._hits(pt[0], pt[1]) for pt in shape2ApproxPoints)):
                        return True

        return False

    def toFront(self):
        if self.group is not None:
            self.group._toFront(self)

    def toBack(self):
        if self.group is not None:
            self.group._toBack(self)

    def setFillOrStrokeStyle(self, ctx, fillOrBorder):
        style = self.getFillOrStrokeStyle(fillOrBorder, ctx)
        if isinstance(style, wyvern.Gradient):
            ctx.set_source_gradient(style)
        else:
            ctx.set_source_rgba(*style)

    def getFillOrStrokeStyle(self, fillOrBorder, ctx):
        if fillOrBorder is None:
            return (0, 0, 0, 1)
        if isinstance(fillOrBorder, Gradient):
            gradient = fillOrBorder
            g = self.createBaseGradient(gradient)
            n = len(gradient.colors)
            for i in range(n):
                color = gradient.colors[i]
                ctx.add_color_stop_rgba(
                    i / (n - 1), *self.getFillOrStrokeStyle(color, ctx)
                )
            return g
        if isinstance(fillOrBorder, str):
            fillOrBorder = CSS3_COLORS_TO_RGB[toEnglish(fillOrBorder, 'color').lower()]
        if type(fillOrBorder) is RGB:
            # What RGB.__getattr__ returns for red, green, and blue (whose
            # names are the same in every language), without translating them
            rgba = (
                fillOrBorder._red / 255,
                fillOrBorder._green / 255,
                fillOrBorder._blue / 255,
                self.opacity / 100,
            )
        else:
            rgba = (
                fillOrBorder.red / 255,
                fillOrBorder.green / 255,
                fillOrBorder.blue / 255,
                self.opacity / 100,
            )
        return rgba

    def setDashes(self, ctx):
        dashes = self.dashes
        if isinstance(dashes, bool):
            ctx.set_dash([5, 5] if dashes else [])
        else:
            ctx.set_dash(dashes)

    def drawDbPoint(self, ctx, x, y, color):
        ctx.save()
        color_list = list(self.getFillOrStrokeStyle(color, ctx))
        color_list[3] = 1  # ignore our own opacity when drawing db points
        ctx.set_source_rgba(*color_list)
        r = 3
        ctx.new_path()
        ctx.arc(x, y, r, 0, 2 * math.pi)
        ctx.close_path()
        ctx.fill()
        ctx.restore()

    def drawDbCenter(self, ctx):
        self.drawDbPoint(ctx, self.centerX, self.centerY, 'red')

    def drawDbCentroid(self, ctx):
        if isinstance(self, Polygon):
            centroid = utils.getPolygonCentroid(self.pointList)
            self.drawDbPoint(ctx, centroid[0], centroid[1], 'magenta')
        else:
            self.drawDbCenter(ctx)

    def drawDbBox(self, ctx):
        ctx.save()
        ctx.new_path()
        ctx.rectangle(self.left, self.top, self.width, self.height)
        ctx.close_path()
        ctx.set_line_width(2)
        color_list = list(self.getFillOrStrokeStyle('red', ctx))
        color_list[3] = 1  # ignore our own opacity when drawing db points
        ctx.set_source_rgba(*color_list)
        ctx.set_dash([2, 2])
        ctx.stroke()
        ctx.restore()

    def drawDbPoints(self, ctx):
        pts = self.getApproxPoints()
        ctx.save()
        r = 4
        self.setFillOrStrokeStyle(ctx, 'magenta')
        # dots at corners
        for pt in pts:
            x, y = pt
            ctx.new_path()
            ctx.arc(x, y, r, 0, 2 * math.pi)
            ctx.close_path()
            ctx.fill()
        # now connect the dots
        ctx.new_path()
        utils.makePolygonPath(pts, ctx)
        ctx.close_path()
        ctx.set_line_width(3)
        self.setFillOrStrokeStyle(ctx, 'magenta')
        ctx.set_dash([7, 7])
        ctx.stroke()
        ctx.restore()

    def draw(self, ctx):
        ctx.save()
        if self.isGroup:
            for s in self._shapes:
                s.draw(ctx)
            # Groups used to leave this save on the canvas's stack, which
            # grew by one entry per group drawn every frame. Children
            # restore everything they change, so restoring here draws the
            # same thing.
            ctx.restore()
        else:
            bw = self.borderWidth if self.border else 0
            if isinstance(self, Label):
                if str(self.value) != self.valueStr:
                    self.valueStr = str(self.value)
                    self.setDims()
                [targetX, targetY] = self.getApproxPoints()[
                    6
                ]  # target start,top of text
                # rotate around targetX, targetY
                if self.rotateAngle != 0:
                    ctx.translate(targetX, targetY)
                    ctx.rotate(utils.toRadians(self.rotateAngle))
                    ctx.translate(-targetX, -targetY)

                ctx.select_font_face(*getFont(self.font, self.bold, self.italic))
                ctx.set_font_size(self.size)
                text = str(self.value)

                ctx.new_path()
                ctx.move_to(targetX - self.attrs['xAdjust'], targetY)

                ctx.text_path(text)

                self.setFillOrStrokeStyle(ctx, self.fill)
                ctx.fill_preserve()
                if bw:
                    self.setFillOrStrokeStyle(ctx, self.border)
                    ctx.set_line_width(bw)
                    ctx.stroke()
            elif isinstance(self, Line):
                if self.fill:
                    ctx.new_path()
                    self.setFillOrStrokeStyle(ctx, self.fill)
                    self.setDashes(ctx)
                    ctx.set_line_width(self.lineWidth)
                    ctx.move_to(self.x1, self.y1)
                    ctx.line_to(self.x2, self.y2)
                    ctx.stroke()

                    self.drawArrows(ctx)
            else:
                self.makePath(ctx)
                if self.closed:
                    ctx.close_path()
                fill = self.fill
                if fill and len(self.pointList) > 2:
                    self.setFillOrStrokeStyle(ctx, fill)
                    ctx.fill_preserve()
                if bw:
                    # (*note) if there is a border, draw with 2x borderWidth,
                    # but clipped to shape so only 1x inner border is drawn
                    bw *= 2
                    ctx.clip_preserve()
                    self.setFillOrStrokeStyle(ctx, self.border)
                    # @TODO
                    self.setDashes(ctx)
                    if isinstance(self, Arc):
                        ctx.set_line_join(wyvern.LineJoin.ROUND)
                    ctx.set_line_width(bw)
                    ctx.stroke()
            if isinstance(self, CMUImage):
                self.drawImage(ctx)
            ctx.restore()

        db = self.db
        if db != '' and isinstance(db, str):
            if db == 'all' or 'points' in db:
                self.drawDbPoints(ctx)
            if db == 'all' or 'box' in db:
                self.drawDbBox(ctx)
            if db == 'all' or 'center' in db:
                self.drawDbCenter(ctx)
            if db == 'all' or 'centroid' in db:
                self.drawDbCentroid(ctx)


def countShapesInGroup(shape):
    # First make it a sl shape so hasattr doesn't call getattr and crash
    if hasattr(shape, '_shape'):
        shape = shape._shape
    if type(shape) is TopLevelGroup:
        # Counts its records without making them into shapes
        fields = shape.__dict__
        ownShapes = fields['_ownShapes']
        pendingCount = len(fields['_pending'])
        if not ownShapes and not pendingCount:
            return 1
        return _countShapes(ownShapes) + pendingCount
    if not hasattr(shape, '_shapes') or not shape._shapes:
        return 1
    return _countShapes(shape._shapes)


def _countShapes(shapes):
    # countShapesInGroup for each of a group's shapes, added up. This runs
    # every 100 shapes added, over every shape, so it checks isGroup rather
    # than using hasattr (which raises and catches an AttributeError for
    # every shape that isn't a group). A shape has _shapes once it's a group
    # (Group.__init__ sets isGroup and _shapes together).
    total = 0
    for shape in shapes:
        if type(shape) is not LazyShape and shape.isGroup and shape._shapes:
            total += _countShapes(shape._shapes)
        else:
            total += 1
    return total


def _countShapeAdded():
    # Every 100 shapes added, check that there aren't too many
    activeDrawing.addCounter += 1
    if activeDrawing.addCounter % 100 == 0:
        if (
            countShapesInGroup(activeDrawing.tlg)
            > activeDrawing.appProperties['maxShapeCount']
        ):
            pyThrow(
                t(
                    'Too many shapes: Your code created more than {{maxShapeCount}} shapes. If you would like to increase this limit even though it may cause your code to run slowly, call app.setMaxShapeCount(n).',
                    {
                        'maxShapeCount': str(
                            activeDrawing.appProperties['maxShapeCount']
                        )
                    },
                )
            )


def checkRecursiveGroupAddition(group, shape):
    if shape.isGroup:
        if group.id == shape.id:
            pyThrow(t('Group.add failed: a Group cannot contain itself.'))
        for subshape in shape._shapes:
            checkRecursiveGroupAddition(group, subshape)


def _resetZindexes(group):
    # The zindex reset at the end of Group.remove, for a group's shapes
    for shape in group._shapes:
        if shape.isGroup:
            _resetZindexes(shape)
        else:
            shape.zindex = -1


class Group(Shape):
    def __init__(self, attrs):
        super().__init__(attrs)
        self.isGroup = True
        self._shapes = []

    def toString(self):
        return t('Group()')

    def __iter__(self):
        return iter(self.children)

    def get_children(self):
        return list(map(lambda s: s.studentShape, self._shapes))

    children = shape_property(get_children)

    def insert(self, shape, newIndex=None):
        if shape._group:
            shape._group.remove(shape)
        # By default, put this shape at the top of the group
        if newIndex is None:
            newIndex = len(self._shapes)
            # But if it was in this group before, put it back in front of all the
            # shapes that it was in front of before
            if shape.oldGroup == self:
                newIndex = 0
                for s2 in shape.shapesToBeInFrontOf:
                    s2Index = self._shapes.index(s2) if s2 in self._shapes else -1
                    if s2Index >= 0:
                        newIndex = max(newIndex, s2Index + 1)

                for i, s2 in enumerate(self._shapes):
                    if s2.id not in shape.shapesInOldGroup and shape.id > s2.id:
                        newIndex = max(newIndex, i + 1)

        self._shapes.insert(newIndex, shape)
        shape._group = self
        shape.zindex = -1
        shape.oldGroup = None
        shape.shapesToBeInFrontOf = []
        shape.shapesInOldGroup = {}

    def add(self, *shapes):
        for i in range(len(shapes)):
            # Only translate the error message names when there's an error
            if not isinstance(shapes[i], Shape):
                checkShape(t('Group.add(shape)'), t('shape'), shapes[i], True)
            checkRecursiveGroupAddition(self, shapes[i])
            _countShapeAdded()
            self.insert(shapes[i])

    def addNewShape(self, shape):
        """add(shape) for a shape that has never been in a group (and isn't a
        group): the same checks and changes, without the general case's
        work."""
        _countShapeAdded()
        # What insert() does for a shape with no current or old group
        self._shapes.append(shape)
        shape._group = self
        shape.zindex = -1
        shape.oldGroup = None
        shape.shapesToBeInFrontOf = []
        shape.shapesInOldGroup = {}

    def _toFront(self, shape):
        self.remove(shape)
        self.insert(shape, len(self._shapes))

    def _toBack(self, shape):
        self.remove(shape)
        self.insert(shape, 0)

    def remove(self, shape):
        # Only translate the error message names when there's an error
        if not isinstance(shape, Shape):
            checkShape(t('Group.remove(shape)'), t('shape'), shape, True)
        currentIndex = self._shapes.index(shape) if shape in self._shapes else -1
        shape.shapesToBeInFrontOf = self._shapes[:currentIndex]
        shape.shapesInOldGroup = {}

        for s in self._shapes:
            shape.shapesInOldGroup[s.id] = s

        for i in range(currentIndex + 1, len(self._shapes)):
            self._shapes[i].shapesToBeInFrontOf.append(shape)

        if shape in self._shapes:
            self._shapes.remove(shape)
        shape.oldGroup = self
        shape._group = None
        shape.zindex = -1

        def f(shape):
            if shape.isGroup:
                for s in shape._shapes:
                    f(s)
            else:
                shape.zindex = -1

        f(shape)

    def clear(self):
        shapes = self._shapes
        self._shapes = []
        for shape in shapes:
            if not isinstance(shape, Shape):
                self.remove(shape)  # Raises the error
                continue
            # What remove(shape) does, now that this group is empty
            shape.shapesToBeInFrontOf = []
            shape.shapesInOldGroup = {}
            shape.oldGroup = self
            shape._group = None
            shape.zindex = -1
            if shape.isGroup:
                _resetZindexes(shape)

    def hits(self, x, y):
        return self.hitTest(x, y) is not None

    def hitTest(self, x, y):
        for i in range(len(self._shapes) - 1, -1, -1):
            shape = self._shapes[i]
            if shape.hits(x, y):
                return shape.studentShape
        return None

    def contains(self, x, y):
        return any(shape.contains(x, y) for shape in self._shapes)

    def getSinglePointFromShape(self, target):
        if isinstance(target, Group):
            if len(target._shapes) > 0:
                return self.getSinglePointFromShape(target._shapes[0])
            return None
        else:
            return target.getApproxPoints()[0]

    def closeShapes(self, shapes):
        for shape in shapes:
            shape.append(shape[0])

    def getApproxGroupPoints(self, group):
        shapes = group._shapes
        if len(shapes) > 0:
            groupPoints = [
                self.getApproxGroupPoints(shape)
                if isinstance(shape, Group)
                else [[shape.getApproxPoints()]]
                for shape in shapes
            ]
            for groups in groupPoints:
                for group in groups:
                    self.closeShapes(group)
            return pygeo.union(groupPoints)
        else:
            return []

    # helper method to ensure union only gets called once
    def containsShapeFromPoints(self, target, groupPoints):
        if isinstance(target, Group):
            return all(
                [
                    self.containsShapeFromPoints(shape, groupPoints)
                    for shape in target._shapes
                ]
            )
        targetPoints = target.getApproxPoints()
        groupNum = len(groupPoints)

        for i in range(groupNum):
            groupShape = groupPoints[i]
            # for a polygon, the first argument is the outline and the remaining are holes in the shape, if they exist
            shapeNum = len(groupShape)
            for i in range(shapeNum):
                if pygeo.edgesIntersect(
                    groupShape[i],
                    targetPoints,
                ):
                    return False

        return self.contains(targetPoints[0][0], targetPoints[0][1])

    def containsShape(self, target):
        # Computing the group union in getApproxGroupShape can be slow, so we
        # try two simpler methods first to see if they give an answer.

        # 1: If there is a point in target that is not contained by this group,
        #    we can return false.
        samplePoint = self.getSinglePointFromShape(target)
        if samplePoint and not self.contains(samplePoint[0], samplePoint[1]):
            return False

        # 2: If the target is fully contained within a single one of the shapes,
        #    we can return true.
        if any([shape.containsShape(target) for shape in self._shapes]):
            return True

        groupPoints = self.getApproxGroupPoints(self)
        return self.containsShapeFromPoints(target, groupPoints)

    def drawDbPoints(self, ctx):
        groupPoints = self.getApproxGroupPoints(self)
        ctx.save()
        r = 4
        # dots at corners
        for shapeList in groupPoints:
            for shape in shapeList:
                for pt in shape:
                    x, y = pt
                    self.setFillOrStrokeStyle(ctx, 'magenta')
                    ctx.new_path()
                    ctx.arc(x, y, r, 0, 2 * math.pi)
                    ctx.close_path()
                    ctx.fill()
                ctx.new_path()
                utils.makePolygonPath(shape, ctx)
                ctx.close_path()
                ctx.set_line_width(3)
                self.setFillOrStrokeStyle(ctx, 'magenta')
                ctx.set_dash([7, 7])
                ctx.stroke()
        ctx.restore()

    def addx(self, dx):
        for shape in self._shapes:
            shape.left += dx

    def get_left(self):
        if len(self._shapes) == 0:
            return 0
        return utils.min_or_inf(list(map(lambda s: s.left, self._shapes)))

    def set_left(self, v):
        self.addx(v - self.left)

    left = shape_property(get_left, set_left)

    def get_right(self):
        if len(self._shapes) == 0:
            return 0
        return max(map(lambda s: s.right, self._shapes))

    def set_right(self, v):
        self.addx(v - self.right)

    right = shape_property(get_right, set_right)

    def get_centerX(self):
        return (self.left + self.right) / 2

    def set_centerX(self, v):
        self.addx(v - self.centerX)

    centerX = shape_property(get_centerX, set_centerX)

    def addy(self, dy):
        for shape in self._shapes:
            shape.top += dy

    def get_top(self):
        if len(self._shapes) == 0:
            return 0
        return utils.min_or_inf(list(map(lambda s: s.top, self._shapes)))

    def set_top(self, v):
        self.addy(v - self.top)

    top = shape_property(get_top, set_top)

    def get_bottom(self):
        if len(self._shapes) == 0:
            return 0
        return max(map(lambda s: s.bottom, self._shapes))

    def set_bottom(self, v):
        self.addy(v - self.bottom)

    bottom = shape_property(get_bottom, set_bottom)

    def get_centerY(self):
        return (self.top + self.bottom) / 2

    def set_centerY(self, v):
        self.addy(v - self.centerY)

    centerY = shape_property(get_centerY, set_centerY)

    def scalexy(self, varName, k, scaleAnchor=None):
        if k == 1:
            return
        if scaleAnchor is None:
            scaleAnchor = self.centroid
        for s in self._shapes:
            s.scalexy(varName, k, scaleAnchor)

    def get_width(self):
        return self.right - self.left

    def set_width(self, v):
        if self.width == 0:
            self.scaleToTarget('x', v)
        else:
            self.scalexy('x', (v / self.width))

    width = shape_property(get_width, set_width)

    def get_height(self):
        return self.bottom - self.top

    def set_height(self, v):
        if self.height == 0:
            self.scaleToTarget('y', v)
        else:
            self.scalexy('y', (v / self.height))

    height = shape_property(get_height, set_height)

    def _rotate(self, degrees=None, cx=None, cy=None):
        if len(self._shapes) == 0:
            self.set({'rotateAngle': self.rotateAngle + degrees})
            return

        super()._rotate(degrees, cx, cy)

    def doRotate(self, degrees, cx, cy):
        for s in self._shapes:
            s.rotate(degrees, cx, cy)

    def get_area(self):
        result = 0
        for s in self._shapes:
            result += s.area
        return result

    area = shape_property(get_area)

    def get_centroid(self):
        x, y, A = 0, 0, 0
        for s in self._shapes:
            c = s.centroid
            a = s.area
            cx, cy = c[0], c[1]
            x += a * cx
            y += a * cy
            A += a
        return [x, y] if A == 0 else [x / A, y / A]

    centroid = shape_property(get_centroid)

    # pass-through attrs (PTA's)

    def getPTA(self, attr):
        val = None
        for shape in self._shapes:
            if val is None:
                val = getattr(shape, attr)
            else:
                if (
                    attr == 'fill' and not colorTest(getattr(shape, attr), val, 0.005)
                ) or (attr == 'opacity' and not opacityTest(getattr(shape, attr), val)):
                    pyThrow(
                        t(
                            "Group.{{attr}} has no value because its children don't all have the same value for {{attr}}",
                            {'attr': t(attr)},
                        )
                    )
        return val

    def setPTA(self, attr, v):
        for shape in self._shapes:
            setattr(shape, attr, v)
        return v

    def get_fill(self):
        return self.getPTA('fill')

    def set_fill(self, v):
        return self.setPTA('fill', v)

    fill = shape_property(get_fill, set_fill)

    def get_opacity(self):
        return self.getPTA('opacity')

    def set_opacity(self, v):
        return self.setPTA('opacity', v)

    opacity = shape_property(get_opacity, set_opacity)

    def noPTA(self, attr):
        pyThrow(t('Group.{{attr}} cannot be read or modified', {'attr': t(attr)}))

    def get_border(self):
        return self.noPTA('border')

    def set_border(self, v):
        return self.noPTA('border', v)

    border = shape_property(get_border, set_border)

    def get_borderWidth(self):
        return self.noPTA('borderWidth')

    def set_borderWidth(self, v):
        return self.noPTA('borderWidth', v)

    borderWidth = shape_property(get_borderWidth, set_borderWidth)

    def get_dashes(self):
        return self.noPTA('dashes')

    def set_dashes(self, v):
        return self.noPTA('dashes', v)

    dashes = shape_property(get_dashes, set_dashes)

    def get_arrowEnd(self):
        return self.noPTA('arrowEnd')

    def set_arrowEnd(self, v):
        return self.noPTA('arrowEnd', v)

    arrowEnd = shape_property(get_arrowEnd, set_arrowEnd)

    def get_arrowStart(self):
        return self.noPTA('arrowStart')

    def set_arrowStart(self, v):
        return self.noPTA('arrowStart', v)

    arrowStart = shape_property(get_arrowStart, set_arrowStart)

    def get_url(self):
        return self.noPTA('url')

    def set_url(self, v):
        return self.noPTA('url', v)

    url = shape_property(get_url, set_url)

    def get_radius(self):
        return self.noPTA('radius')

    def set_radius(self, v):
        return self.noPTA('radius', v)

    radius = shape_property(get_radius, set_radius)

    def get_points(self):
        return self.noPTA('points')

    def set_points(self, v):
        return self.noPTA('points', v)

    points = shape_property(get_points, set_points)

    def get_roundness(self):
        return self.noPTA('roundness')

    def set_roundness(self, v):
        return self.noPTA('roundness', v)

    roundness = shape_property(get_roundness, set_roundness)

    def get_x1(self):
        return self.noPTA('x1')

    def set_x1(self, v):
        return self.noPTA('x1', v)

    x1 = shape_property(get_x1, set_x1)

    def get_y1(self):
        return self.noPTA('y1')

    def set_y1(self, v):
        return self.noPTA('y1', v)

    y1 = shape_property(get_y1, set_y1)

    def get_x2(self):
        return self.noPTA('x2')

    def set_x2(self, v):
        return self.noPTA('x2', v)

    x2 = shape_property(get_x2, set_x2)

    def get_y2(self):
        return self.noPTA('y2')

    def set_y2(self, v):
        return self.noPTA('y2', v)

    y2 = shape_property(get_y2, set_y2)

    def get_lineWidth(self):
        return self.noPTA('lineWidth')

    def set_lineWidth(self, v):
        return self.noPTA('lineWidth', v)

    lineWidth = shape_property(get_lineWidth, set_lineWidth)

    def get_closed(self):
        return self.noPTA('closed')

    def set_closed(self, v):
        return self.noPTA('closed', v)

    closed = shape_property(get_closed, set_closed)

    def get_startAngle(self):
        return self.noPTA('startAngle')

    def set_startAngle(self, v):
        return self.noPTA('startAngle', v)

    startAngle = shape_property(get_startAngle, set_startAngle)

    def get_sweepAngle(self):
        return self.noPTA('sweepAngle')

    def set_sweepAngle(self, v):
        return self.noPTA('sweepAngle', v)

    sweepAngle = shape_property(get_sweepAngle, set_sweepAngle)

    def get_value(self):
        return self.noPTA('value')

    def set_value(self, v):
        return self.noPTA('value', v)

    value = shape_property(get_value, set_value)

    def get_font(self):
        return self.noPTA('font')

    def set_font(self, v):
        return self.noPTA('font', v)

    font = shape_property(get_font, set_font)

    def get_size(self):
        return self.noPTA('size')

    def set_size(self, v):
        return self.noPTA('size', v)

    size = shape_property(get_size, set_size)

    def get_bold(self):
        return self.noPTA('bold')

    def set_bold(self, v):
        return self.noPTA('bold', v)

    bold = shape_property(get_bold, set_bold)

    def get_italic(self):
        return self.noPTA('italic')

    def set_italic(self, v):
        return self.noPTA('italic', v)

    italic = shape_property(get_italic, set_italic)

    def scaleToTarget(self, varName, target):
        for shape in self._shapes:
            if getattr(shape, 'scaleToTarget'):
                shape.scaleToTarget(varName, target)


SHOW_FONT_WARNINGS = True

# This is a list of fonts that are available on the CMU CS Academy website but may not be
# available on the user's computer. We show a warning the first time a font is used.
FONTS_SHOW_WARNING = {
    'caveat',
    'cinzel',
    'montserrat',
    'grenze',
    'sacramento',
    'orbitron',
    'symbols',
}


def getFont(baseFontName, isBold=False, isItalic=False):
    if 'mono' in baseFontName or 'courier' in baseFontName:
        fontName = 'Courier New'
    elif 'arial' in baseFontName or 'sans' in baseFontName:
        fontName = 'Arial'
    elif baseFontName.lower() in (
        'serif',
        'sans-serif',
        'cursive',
        'fantasy',
        'monospace',
    ):
        fontName = baseFontName.lower()
    else:
        fontName = baseFontName

    bold = wyvern.FontWeight.BOLD if isBold else wyvern.FontWeight.NORMAL
    italic = wyvern.FontSlant.ITALIC if isItalic else wyvern.FontSlant.NORMAL

    return (fontName, bold, italic)


def maybe_show_font_warning(fontName):
    if SHOW_FONT_WARNINGS and fontName.lower() in FONTS_SHOW_WARNING:
        FONTS_SHOW_WARNING.remove(fontName.lower())
        print(f"INFO: Your code drew a Label using a font ('{fontName}')")
        print('that is available on the CMU CS Academy website but may not be')
        print('available on your computer. You could change this font to any')
        print(f"font installed on your system, or install ('{fontName}').")
        print('To stop showing this warning, set app.showFontWarnings = False.\n')


fontCtx = wyvern.ImageSurface(1, 1).canvas


class Label(Shape):
    def __init__(self, attrs):
        super().__init__(attrs)
        self.valueStr = None
        if attrs is not None:
            self.setDims()

    def getApproxPoints(self):
        return self.attrs['approxPoints']

    def doRotate(self, degrees, cx, cy):
        newCenter = utils.rotatePoint([self.centerX, self.centerY], degrees, cx, cy)
        self.set({'centerX': newCenter[0], 'centerY': newCenter[1]})
        self.setDims()

    def setDims(self):
        fontCtx.select_font_face(*getFont(self.font, self.bold, self.italic))
        fontCtx.set_font_size(self.size)

        cx = self.attrs['centerX']
        cy = self.attrs['centerY']
        stringValue = utils.convertLabelValue(self.value)
        xBearing, yBearing, width, height, xAdvance, yAdvance = fontCtx.text_extents(
            stringValue
        )
        height = -yBearing
        unrotatedWidth = width
        hasOuterSpaces = len(stringValue) > 0 and (
            stringValue[0] == ' ' or stringValue[-1] == ' '
        )
        if hasOuterSpaces:
            unrotatedWidth = max(unrotatedWidth, xAdvance)
        # unrotatedHeight = -height
        unrotatedHeight = height
        x0 = cx - unrotatedWidth / 2
        y0 = cy - unrotatedHeight / 2
        x1 = cx + unrotatedWidth / 2
        y1 = cy + unrotatedHeight / 2
        pts = [
            [x0, y0],
            [(x0 + x1) / 2, y0],
            [x1, y0],
            [x1, (y0 + y1) / 2],
            [x1, y1],
            [(x0 + x1) / 2, y1],
            [x0, y1],
            [x0, (y0 + y1) / 2],
        ]
        a = self.rotateAngle
        if a:
            pts = utils.rotatePoints(pts, a, self.centerX, self.centerY)
        self.set({'approxPoints': pts, 'xAdjust': 0 if hasOuterSpaces else xBearing})
        box = utils.getBoxDims(pts)
        self.set({'width': box['width'], 'height': box['height']})

    def get_area(self):
        return self.width * self.height

    area = shape_property(get_area)

    def createBaseGradient(self, gradient):
        # The approxPoints of a Label are positioned correctly (self.rotateAngle has
        # already been applied to them). However, when we draw the text, we
        # rotate the canvas around the start,bottom point of the text. So, we have to make a
        # gradient that is positioned such that it will be in the correct place after
        # being rotated around start,bottom by self.rotateAngle.
        start = canonicalizeGradientStart(gradient.start)
        [targetX, targetY] = self.getApproxPoints()[6]  # target start,top of text
        if start == 'center':
            cx = self.centerX
            cy = self.centerY
            r = utils.distance(cx, cy, self.right, self.top)
            [[cx, cy]] = utils.rotatePoints(
                [[cx, cy]], -self.rotateAngle, targetX, targetY
            )
            return wyvern.Gradient.RadialGradient(cx, cy, r)

        startToPointIndex = {
            'left-top': 0,
            'top': 1,
            'right-top': 2,
            'right': 3,
            'right-bottom': 4,
            'bottom': 5,
            'left-bottom': 6,
            'left': 7,
        }

        if startToPointIndex.get(start) is None:
            pyThrow('Illegal gradient start {start}'.format(start=start))

        [x0, y0] = self.getApproxPoints()[startToPointIndex[start]]
        endIndex = (startToPointIndex[start] + 4) % 8
        [x1, y1] = self.getApproxPoints()[endIndex]

        if self.rotateAngle != 0:
            [[x0, y0], [x1, y1]] = utils.rotatePoints(
                [[x0, y0], [x1, y1]], -self.rotateAngle, targetX, targetY
            )

        return wyvern.Gradient.LinearGradient(x0, y0, x1, y1)

    def get_width(self):
        return self.get('width')

    def set_width(self, v):
        pyThrow(t("Cannot set Label's width"))

    width = attr_property('width', get_width, set_width)

    def get_height(self):
        return self.get('height')

    def set_height(self, v):
        pyThrow(t("Cannot set Label's height"))

    height = attr_property('height', get_height, set_height)

    def get_centerX(self):
        return self.get('centerX')

    def set_centerX(self, v):
        self.set({'centerX': v})
        self.setDims()
        return v

    centerX = attr_property('centerX', get_centerX, set_centerX)

    def get_centerY(self):
        return self.get('centerY')

    def set_centerY(self, v):
        self.set({'centerY': v})
        self.setDims()
        return v

    centerY = attr_property('centerY', get_centerY, set_centerY)

    def get_value(self):
        return self.get('value')

    def set_value(self, v):
        self.set({'value': v})
        self.valueStr = str(v)
        self.setDims()
        return v

    value = attr_property('value', get_value, set_value)

    def get_font(self):
        return self.get('font')

    def set_font(self, v):
        maybe_show_font_warning(v)
        self.set({'font': v})
        self.setDims()
        return v

    font = attr_property('font', get_font, set_font)

    def get_size(self):
        return self.get('size')

    def set_size(self, v):
        self.set({'size': v})
        self.setDims()
        return v

    size = attr_property('size', get_size, set_size)

    def get_bold(self):
        return self.get('bold')

    def set_bold(self, v):
        self.set({'bold': v})
        self.setDims()
        return v

    bold = attr_property('bold', get_bold, set_bold)

    def get_italic(self):
        return self.get('italic')

    def set_italic(self, v):
        self.set({'italic': v})
        self.setDims()
        return v

    italic = attr_property('italic', get_italic, set_italic)

    def toString(self):
        return f'{t("Label")}({self.value}, {self.centerX}, {self.centerY})'


class Polygon(Shape):
    def __init__(self, attrs=None):
        if attrs is not None and 'initialPoints' in attrs:
            if len(attrs['initialPoints']) % 2 != 0:
                pyThrow(
                    t('Must have an even number of x,y values in initialPoints list')
                )
            initialPoints = attrs['initialPoints']
            for i in range(0, len(initialPoints), 2):
                x, y = initialPoints[i], initialPoints[i + 1]
                # Only translate the error message names when there's an error
                if not isinstance(x, (int, float)):
                    checkNumber(t('Polygon'), t('initialPoints (x value)'), x, False)
                if not isinstance(y, (int, float)):
                    checkNumber(t('Polygon'), t('initialPoints (y value)'), y, False)

        super().__init__(attrs)
        self._cachedCentroid = self._cachedArea = None

        if attrs is not None and 'initialPoints' in attrs:
            pts = attrs['initialPoints']
            pointList = []
            for i in range(0, len(pts), 2):
                x, y = pts[i], pts[i + 1]
                pointList.append([x, y])
            self.pointList = pointList

    def get_pointList(self):
        return self.get('pointList')

    def set_pointList(self, pl):
        self.set({'pointList': pl})
        self.setDims()

    pointList = attr_property('pointList', get_pointList, set_pointList)

    def get_area(self):
        if self._cachedArea is None:
            self._cachedArea = abs(utils.getPolygonArea(self.pointList))
        return self._cachedArea

    area = shape_property(get_area)

    def get_centroid(self):
        if self._cachedCentroid is None:
            self._cachedCentroid = utils.getPolygonCentroid(self.pointList)
        return self._cachedCentroid

    centroid = shape_property(get_centroid)

    def addPoint(self, x, y):
        checkNumber(t('addPoint'), t('x'), x, False)
        checkNumber(t('addPoint'), t('y'), y, False)
        self.pointList.append([x, y])
        self.pointList = self.pointList  # alert to change

    def setCoord(self, attrName, varIndex, pointIndex, newVal):
        checkNumber(t('Polygon'), attrName, newVal, False)
        self.pointList[pointIndex][varIndex] = newVal
        self.pointList = self.pointList  # alert to change

    def makePath(self, ctx):
        return utils.makePolygonPath(self.pointList, ctx)

    def setDims(self):
        self._cachedCentroid = self._cachedArea = None
        if len(self.pointList) == 0:
            self.set(
                {
                    'centerX': 0,
                    'centerY': 0,
                    'width': 0,
                    'height': 0,
                }
            )
            return
        boxDims = utils.getBoxDims(self.pointList)
        self.set(
            {
                'centerX': boxDims['left'] + boxDims['width'] / 2,
                'centerY': boxDims['top'] + boxDims['height'] / 2,
                'width': boxDims['width'],
                'height': boxDims['height'],
            }
        )

    def get_centerX(self):
        return self.get('centerX')

    def set_centerX(self, v):
        self.addx(v - self.centerX)
        # centerX will get set by setDims(), but we overwrite the value
        # with what the user gave so that there are no rounding errors.
        self.set({'centerX': v})

    centerX = attr_property('centerX', get_centerX, set_centerX)

    def get_centerY(self):
        return self.get('centerY')

    def set_centerY(self, v):
        self.addy(v - self.centerY)
        # centerY will get set by setDims(), but we overwrite the value
        # with what the user gave so that there are no rounding errors.
        self.set({'centerY': v})

    centerY = attr_property('centerY', get_centerY, set_centerY)

    def get_left(self):
        return utils.min_or_inf(list(map(lambda point: point[0], self.pointList)))

    def set_left(self, v):
        self.addx(v - self.left)
        return v

    left = shape_property(get_left, set_left)

    def get_top(self):
        return utils.min_or_inf(list(map(lambda point: point[1], self.pointList)))

    def set_top(self, v):
        self.addy(v - self.top)
        return v

    top = shape_property(get_top, set_top)

    def get_right(self):
        return max(map(lambda point: point[0], self.pointList))

    def set_right(self, v):
        self.addx(v - self.right)
        return v

    right = shape_property(get_right, set_right)

    def get_bottom(self):
        return max(map(lambda point: point[1], self.pointList))

    def set_bottom(self, v):
        self.addy(v - self.bottom)
        return v

    bottom = shape_property(get_bottom, set_bottom)

    def addxy(self, varName, d):
        if d == 0:
            return
        varIndex = 0 if varName == 'x' else 1
        pointList = self.pointList
        for i in range(len(pointList)):
            pointList[i][varIndex] += d
        self.pointList = pointList  # alert to change

    def scalexy(self, varName, k, scaleAnchor=None):
        if k == 1:
            return
        varIndex = 0 if varName == 'x' else 1
        pointList = self.pointList
        cxy = (scaleAnchor or self.getScaleAnchor())[varIndex]
        for i in range(len(pointList)):
            dxy = pointList[i][varIndex] - cxy
            pointList[i][varIndex] = cxy + k * dxy
        self.pointList = pointList  # alert to change

    def getScaleAnchor(self):
        return [self.centerX, self.centerY]

    def doRotate(self, degrees, cx, cy):
        self.pointList = utils.rotatePoints(self.pointList, degrees, cx, cy)

    def getApproxPoints(self):
        return self.pointList

    def toString(self):
        args = utils.flatten(self.pointList)
        return t('Polygon{{args}}', {'args': utils.roundedTupleString(args, 2)})

    def createBaseGradient(self, fillOrBorder):
        gradient = fillOrBorder
        start = canonicalizeGradientStart(gradient.start)
        rotateAnchor = self.getRotateAnchor()

        unrotatedPoints = self.pointList
        if self.rotateAngle != 0:
            unrotatedPoints = utils.rotatePoints(
                self.pointList, -self.rotateAngle, rotateAnchor[0], rotateAnchor[1]
            )
        dims = utils.getBoxDims(unrotatedPoints)

        if start == 'center':
            if isinstance(self, Oval):
                r = max(dims['width'], dims['height']) / 2
            else:
                r = utils.distance(
                    dims['left'] + dims['width'] / 2,
                    dims['top'] + dims['height'] / 2,
                    dims['left'],
                    dims['top'],
                )

            if isinstance(self, Star):
                r *= 0.8

            return wyvern.Gradient.RadialGradient(
                rotateAnchor[0],
                rotateAnchor[1],
                r,
            )

        left, top = dims['left'], dims['top']
        right = left + dims['width']
        bottom = top + dims['height']
        centerX = left + dims['width'] / 2
        centerY = top + dims['height'] / 2
        if start == 'left-top':
            x0 = left
            x1 = right
            y0 = top
            y1 = bottom
        elif start == 'left':
            x0 = left
            x1 = right
            y0 = y1 = centerY
        elif start == 'left-bottom':
            x0 = left
            x1 = right
            y0 = bottom
            y1 = top
        elif start == 'top':
            x0 = x1 = centerX
            y0 = top
            y1 = bottom
        elif start == 'bottom':
            x0 = x1 = centerX
            y0 = bottom
            y1 = top
        elif start == 'right-top':
            x0 = right
            x1 = left
            y0 = top
            y1 = bottom
        elif start == 'right':
            x0 = right
            x1 = left
            y0 = y1 = centerY
        elif start == 'right-bottom':
            x0 = right
            x1 = left
            y0 = bottom
            y1 = top
        else:
            pyThrow('Illegal gradient start ({start})'.format(start=start))

        if self.rotateAngle != 0:
            [[x0, y0], [x1, y1]] = utils.rotatePoints(
                [[x0, y0], [x1, y1]], self.rotateAngle, rotateAnchor[0], rotateAnchor[1]
            )

        return wyvern.Gradient.LinearGradient(x0, y0, x1, y1)


class Rect(Polygon):
    def __init__(self, attrs=None):
        if attrs is not None:
            right = attrs['left'] + attrs['width']
            bottom = attrs['top'] + attrs['height']
            attrs['defaultAlign'] = 'left-top'
            attrs['initialPoints'] = [
                attrs['left'],
                attrs['top'],
                right,
                attrs['top'],
                right,
                bottom,
                attrs['left'],
                bottom,
            ]
        super().__init__(attrs)

    def getScaleAnchor(self):
        return [self.left, self.top]

    def toString(self):
        args = [self.left, self.top, self.width, self.height]
        return t('Rect{{args}}', {'args': utils.roundedTupleString(args, 2)})


class Line(Polygon):
    def __init__(self, attrs):
        attrs['initialPoints'] = utils.flatten(
            utils.getLinePoints(attrs['x1'], attrs['y1'], attrs['x2'], attrs['y2'], 2)
        )

        exactValues = {
            'x1': attrs['x1'],
            'x2': attrs['x2'],
            'y1': attrs['y1'],
            'y2': attrs['y2'],
        }

        del attrs['x1']
        del attrs['y1']
        del attrs['x2']
        del attrs['y2']
        super().__init__(attrs)
        self.exactValues = exactValues

    def addxy(self, varName, d):
        super().addxy(varName, d)
        attrs = []
        if varName == 'x':
            attrs = ['x1', 'x2']
        else:
            attrs = ['y1', 'y2']

        for attr in attrs:
            if attr in self.exactValues:
                self.exactValues[attr] += d

    def scalexy(self, varName, k, scaleAnchor):
        super().scalexy(varName, k, scaleAnchor)
        self.exactValues = {}

    def _rotate(self, degrees=None, cx=None, cy=None):
        super()._rotate(degrees, cx, cy)
        self.exactValues = {}

    def getXY(self, i0, i1, j, name):
        if name in self.exactValues:
            return self.exactValues[name]

        points = self.pointList
        return (points[i0][j] + points[i1][j]) / 2

    def setXY(self, i0, i1, j, v, name):
        self.exactValues[name] = v
        p = self.pointList
        oldv = (p[i0][j] + p[i1][j]) / 2
        dv = v - oldv
        p[i0][j] += dv
        p[i1][j] += dv
        self.pointList = self.pointList  # alert to change
        return v

    def get_x1(self):
        return self.getXY(0, 3, 0, 'x1')  # x1,y1 at points 0 and 3, 0=x

    def set_x1(self, v):
        return self.setXY(0, 3, 0, v, 'x1')  # x1,y1 at points 0 and 3, 0=x

    x1 = shape_property(get_x1, set_x1)

    def get_y1(self):
        return self.getXY(0, 3, 1, 'y1')  # x1,y1 at points 0 and 3, 1=y

    def set_y1(self, v):
        return self.setXY(0, 3, 1, v, 'y1')  # x1,y1 at points 0 and 3, 1=y

    y1 = shape_property(get_y1, set_y1)

    def get_x2(self):
        return self.getXY(1, 2, 0, 'x2')  # x2,y2 at points 1 and 2, 0=x

    def set_x2(self, v):
        return self.setXY(1, 2, 0, v, 'x2')  # x2,y2 at points 1 and 2, 0=x

    x2 = shape_property(get_x2, set_x2)

    def get_y2(self):
        return self.getXY(1, 2, 1, 'y2')  # x2,y2 at points 1 and 2, 1=y

    def set_y2(self, v):
        return self.setXY(1, 2, 1, v, 'y2')  # x2,y2 at points 1 and 2, 1=y

    y2 = shape_property(get_y2, set_y2)

    def get_arrowStart(self):
        return self.get('arrowStart')

    def set_arrowStart(self, v):
        return self.set({'arrowStart': v})

    arrowStart = attr_property('arrowStart', get_arrowStart, set_arrowStart)

    def get_arrowEnd(self):
        return self.get('arrowEnd')

    def set_arrowEnd(self, v):
        return self.set({'arrowEnd': v})

    arrowEnd = attr_property('arrowEnd', get_arrowEnd, set_arrowEnd)

    def get_lineWidth(self):
        pts = self.pointList
        return utils.distance(pts[0][0], pts[0][1], pts[3][0], pts[3][1])

    def set_lineWidth(self, v):
        self.pointList = utils.getLinePoints(self.x1, self.y1, self.x2, self.y2, v)
        return self.set({'lineWidth': v})

    lineWidth = shape_property(get_lineWidth, set_lineWidth)

    def get_borderWidth(self):
        return 0

    def set_borderWidth(self, v):
        pyThrow(t("Cannot set Line's borderWidth"))

    borderWidth = shape_property(get_borderWidth, set_borderWidth)

    def get_border(self):
        return None

    def set_border(self, v):
        pyThrow(t("Cannot set Line's border"))

    border = shape_property(get_border, set_border)

    def get_area(self):
        return self.lineWidth * utils.distance(self.x1, self.y1, self.x2, self.y2)

    area = shape_property(get_area)

    def drawArrows(self, ctx):
        if not self.arrowEnd and not self.arrowStart:
            return ctx

        dx = self.x2 - self.x1
        dy = self.y2 - self.y1
        dist = math.sqrt(dy * dy + dx * dx)
        if dist < 0.01:
            return ctx
        dx /= dist
        dy /= dist

        normalDx = -dy
        normalDy = dx

        arrowLength = min(50, 10 * math.sqrt(self.lineWidth))
        arrowWidth = arrowLength / 3

        def drawArrow(x, y, dir):
            ctx.new_path()
            self.setFillOrStrokeStyle(ctx, self.fill)
            ctx.set_dash([])
            ctx.move_to(x, y)
            ctx.line_to(
                x + dir * arrowLength * dx - arrowWidth * normalDx,
                y + dir * arrowLength * dy - arrowWidth * normalDy,
            )
            ctx.line_to(
                x + dir * arrowLength * dx + arrowWidth * normalDx,
                y + dir * arrowLength * dy + arrowWidth * normalDy,
            )
            ctx.close_path()
            ctx.fill_preserve()
            ctx.stroke()

        if self.arrowEnd:
            drawArrow(self.x2, self.y2, -1)
        if self.arrowStart:
            drawArrow(self.x1, self.y1, 1)

    def isPoint(self):
        return self.x1 == self.x2 and self.y1 == self.y2

    def scaleToTarget(self, varName, target):
        if self.isPoint():
            if varName == 'x':
                self.x1 -= target / 2
                self.x2 += target / 2
            elif varName == 'y':
                self.y1 -= target / 2
                self.y2 += target / 2
        self.lineWidth = self.lineWidth

    def get_height(self):
        return super().get_height()

    def set_height(self, v):
        if self.height == 0:
            self.scaleToTarget('y', v)
        else:
            super().height = 0

    height = shape_property(get_height, set_height)

    def get_width(self):
        return super().get_width()

    def set_width(self, v):
        if self.width == 0:
            self.scaleToTarget('x', v)
        else:
            super().height = 0

    width = shape_property(get_width, set_width)

    def toString(self):
        args = [self.x1, self.y1, self.x2, self.y2]
        return t('Line{{args}}', {'args': utils.roundedTupleString(args, 2)})


class PolygonInCircle(Polygon):
    def get_radius(self):
        return self.get('radius')

    def set_radius(self, v):
        self.set({'radius': v})
        self.updatePointList()
        return v

    radius = attr_property('radius', get_radius, set_radius)

    def get_points(self):
        return self.get('points')

    def set_points(self, v):
        self.set({'points': v})
        self.updatePointList()
        return v

    points = attr_property('points', get_points, set_points)

    def get_centerX(self):
        return utils.round2(self.centroid[0])

    def set_centerX(self, v):
        self.addx(v - self.centerX)

    centerX = shape_property(get_centerX, set_centerX)

    def get_centerY(self):
        return utils.round2(self.centroid[1])

    def set_centerY(self, v):
        self.addy(v - self.centerY)

    centerY = shape_property(get_centerY, set_centerY)


class RegularPolygon(PolygonInCircle):
    def __init__(self, attrs):
        attrs['initialPoints'] = utils.flatten(
            utils.getRegularPolygonPoints(
                attrs['centerX'], attrs['centerY'], attrs['radius'], attrs['points'], 0
            )
        )
        super().__init__(attrs)

    def updatePointList(self):
        self.pointList = utils.getRegularPolygonPoints(
            self.centerX, self.centerY, self.radius, self.points, self.rotateAngle
        )

    def toString(self):
        args = [self.centerX, self.centerY, self.radius, self.points]
        return t('RegularPolygon{{args}}', {'args': utils.roundedTupleString(args, 2)})


class Star(PolygonInCircle):
    def __init__(self, attrs):
        attrs['initialPoints'] = utils.flatten(
            utils.getStarPoints(
                attrs['centerX'],
                attrs['centerY'],
                attrs['radius'],
                attrs['points'],
                None,
                0,
            )
        )
        super().__init__(attrs)

    def get_roundness(self):
        result = self.get('roundness')
        if result == 'default':
            return utils.getDefaultRoundness(self.points)
        return result

    def set_roundness(self, v):
        self.set({'roundness': v})
        self.updatePointList()
        return v

    roundness = shape_property(get_roundness, set_roundness)

    def updatePointList(self):
        self.pointList = utils.getStarPoints(
            self.centerX,
            self.centerY,
            self.radius,
            self.points,
            self.roundness,
            self.rotateAngle,
        )

    def toString(self):
        args = [self.centerX, self.centerY, self.radius, self.points]
        return t('Star{{args}}', {'args': utils.roundedTupleString(args, 2)})


class PolygonWithTransform(Polygon):
    def get_transformMatrix(self):
        return self.get('transformMatrix')

    def set_transformMatrix(self, v):
        return self.set({'transformMatrix': v})

    transformMatrix = attr_property(
        'transformMatrix', get_transformMatrix, set_transformMatrix
    )

    def multMat(self, trans):
        newTrans = [[0, 0], [0, 0]]
        for i in range(len(newTrans)):
            for j in range(len(newTrans)):
                for k in range(len(newTrans)):
                    newTrans[i][j] += self.transformMatrix[k][j] * trans[i][k]
        self.transformMatrix = newTrans

    def doRotate(self, degrees, cx, cy):
        super().doRotate(degrees, cx, cy)
        cos = utils.intCos(-degrees)
        sin = utils.intSin(-degrees)
        rotateTrans = [
            [cos, sin],
            [-sin, cos],
        ]
        self.multMat(rotateTrans)

    def scalexy(self, varName, k, scaleAnchor=None):
        super().scalexy(varName, k, scaleAnchor)
        if k == 1:
            return
        i = 0 if (varName == 'x') else 1

        trans = [[1, 0], [0, 1]]
        trans[i][i] = k
        self.multMat(trans)


def _copyAttrDefaults(attrDefaults):
    # copy.deepcopy(attrDefaults), which is slow, and runs for every Image made.
    # The defaults are immutable values and lists of them, so copying the lists
    # makes the same copy.
    copied = {}
    for name, value in attrDefaults.items():
        valueType = type(value)
        if valueType is list and all(
            type(item) in _TEMPLATE_IMMUTABLE_TYPES for item in value
        ):
            copied[name] = value[:]
        elif valueType in _TEMPLATE_IMMUTABLE_TYPES:
            copied[name] = value
        else:
            return copy.deepcopy(attrDefaults)
    return copied


# Images resampled to the sizes they're drawn at. Each Image keeps its own
# resampled copy, but in CPCS Mode a new Image is made every frame, so share
# them between Images too: the same image at the same size resamples the
# same. Keyed by the source image's id; entries hold the source image itself,
# so its id can't be reused while the entry exists. Least recently used
# entries are dropped past a budget of pixels.
MAX_SCALED_IMAGE_PIXELS = 8_000_000
_scaledImages = {}
_scaledImagePixels = 0


def scaledImage(src, width, height):
    global _scaledImagePixels
    key = (id(src), width, height)
    entry = _scaledImages.pop(key, None)
    if entry is not None and entry[0] is not src:
        _scaledImagePixels -= entry[2]
        entry = None
    if entry is None:
        entry = (src, src.scaled(width, height), width * height)
        _scaledImagePixels += entry[2]
        while _scaledImages and _scaledImagePixels > MAX_SCALED_IMAGE_PIXELS:
            oldest = next(iter(_scaledImages))
            _scaledImagePixels -= _scaledImages.pop(oldest)[2]
    # Reinsert, so the dict's order is least to most recently used
    _scaledImages[key] = entry
    return entry[1]


class CMUImage(PolygonWithTransform):
    def __init__(self, attrs):
        if attrs is not None:
            imageData = loadImage(attrs['url'])

            height, width = imageData['height'], imageData['width']
            right = attrs['left'] + width
            bottom = attrs['top'] + height
            attrs['defaultAlign'] = 'left-top'
            attrs['initialPoints'] = [
                attrs['left'],
                attrs['top'],
                right,
                attrs['top'],
                right,
                bottom,
                attrs['left'],
                bottom,
            ]
            attrs['transformMatrix'] = [
                [1, 0],
                [0, 1],
            ]
            super().__init__(attrs)
            self.attrDefaults = _copyAttrDefaults(self.attrDefaults)
            self.attrDefaults.update({'fill': None})

    def get_url(self):
        return self.get('url')

    def set_url(self, v):
        pyThrow(t("Cannot set Image's url"))

    url = attr_property('url', get_url, set_url)

    def getScaleAnchor(self):
        return [self.left, self.top]

    def drawImage(self, ctx):
        mat = self.transformMatrix
        src = activeDrawing.images[hashReference(self.url)]
        x, y = self.pointList[0][0], self.pointList[0][1]

        # Fast path: pure (non-negative) scale with no rotation/shear. Resample
        # the image to its on-screen size once, cache it, and blit that 1:1 on
        # subsequent frames instead of resampling every frame.
        if mat[0][1] == 0 and mat[1][0] == 0 and mat[0][0] > 0 and mat[1][1] > 0:
            tw = round(src.width * mat[0][0])
            th = round(src.height * mat[1][1])
            if tw == src.width and th == src.height:
                image = src
            else:
                cache = getattr(self, '_scaledImage', None)
                if cache is None or cache[0] != (tw, th):
                    cache = ((tw, th), scaledImage(src, tw, th))
                    self._scaledImage = cache
                image = cache[1]
            ctx.translate(x, y)
            ctx.draw_image(image, 0, 0, self.opacity / 100)
            return
        ctx.translate(x, y)
        ctx.transform(mat[0][0], mat[1][0], mat[0][1], mat[1][1], 0, 0)
        ctx.draw_image(src, 0, 0, self.opacity / 100)

    def toString(self):
        args = [self.left, self.top, self.width, self.height]
        return t('Image{{args}}', {'args': utils.roundedTupleString(args, 2)})


class Oval(PolygonWithTransform):
    def __init__(self, attrs):
        attrs['initialPoints'] = utils.flatten(
            utils.getArcPoints(
                attrs['centerX'],
                attrs['centerY'],
                attrs['width'],
                attrs['height'],
                attrs.get('startAngle', None),
                attrs.get('sweepAngle', None),
                None,
                attrs['isMvc'],
            )
        )
        attrs['transformMatrix'] = [
            [attrs['width'] / 2, 0],
            [0, attrs['height'] / 2],
        ]
        attrs['translation'] = [attrs['centerX'], attrs['centerY']]
        if 'startAngle' not in attrs:
            attrs['startAngle'] = 0
        if 'sweepAngle' not in attrs:
            attrs['sweepAngle'] = 360
        attrs['bezierPoints'] = Oval.getBezierPoints(
            attrs['startAngle'], attrs['sweepAngle'], attrs['isMvc']
        )
        super().__init__(attrs)

    # The Bezier points only depend on the angles, which are usually the same
    # for every oval, so remember them. Each oval gets its own copy, since the
    # lists are mutable. The key includes the argument types, so for example
    # 90 and 90.0 have separate entries.
    _bezierPointsCache = {}

    @staticmethod
    def getBezierPoints(startAngle, sweepAngle, isMvc):
        points = Oval.sharedBezierPoints(startAngle, sweepAngle, isMvc)
        if points is not None:
            return [[x, y] for (x, y) in points]
        return Oval._computeBezierPoints(startAngle, sweepAngle, isMvc)

    @staticmethod
    def sharedBezierPoints(startAngle, sweepAngle, isMvc):
        """getBezierPoints, as a tuple of (x, y) tuples shared by every call
        with the same arguments, or None for arguments it doesn't remember."""
        if type(startAngle) in (int, float) and type(sweepAngle) in (int, float):
            cache = Oval._bezierPointsCache
            key = (
                startAngle,
                type(startAngle),
                sweepAngle,
                type(sweepAngle),
                bool(isMvc),
            )
            points = cache.get(key)
            if points is None:
                if len(cache) >= 4096:
                    cache.clear()
                points = cache[key] = tuple(
                    (x, y)
                    for [x, y] in Oval._computeBezierPoints(
                        startAngle, sweepAngle, isMvc
                    )
                )
            return points
        return None

    @staticmethod
    def _computeBezierPoints(startAngle, sweepAngle, isMvc):
        offset = utils.toRadians(startAngle)
        remaining = sweepAngle
        bp = []
        while remaining > 0:
            bp.extend(
                Oval.getBezierFragment(
                    utils.toRadians(min(90, remaining)), offset, isMvc
                )
            )
            offset += math.pi / 2
            remaining -= 90
        return bp

    @staticmethod
    def getBezierFragment(sweepAngle, offsetAngle, isMvc):
        # Return a cubic Bezier curve that approximates up to 90 degrees of a circle.
        # https://www.tinaja.com/glib/bezcirc2.pdf
        result = [[0, 0], [0, 0], [0, 0], [0, 0]]
        result[3][0] = math.cos(sweepAngle / 2)
        result[3][1] = math.sin(sweepAngle / 2)
        result[0][0] = result[3][0]
        result[0][1] = -result[3][1]

        result[2][0] = (4 - result[3][0]) / 3
        result[2][1] = ((1 - result[3][0]) * (3 - result[3][0])) / (3 * result[3][1])
        result[1][0] = result[2][0]
        result[1][1] = -result[2][1]

        angle = (sweepAngle / 2) + offsetAngle
        if not isMvc:
            angle -= math.pi / 2

        result = utils.rotatePoints(result, utils.toDegrees(angle), 0, 0)

        if isMvc:
            result = [[pair[0], -pair[1]] for pair in result]
        return result

    def get_bezierPoints(self):
        return self.get('bezierPoints')

    def set_bezierPoints(self, v):
        return self.set({'bezierPoints': v})

    bezierPoints = attr_property('bezierPoints', get_bezierPoints, set_bezierPoints)

    def get_translation(self):
        return self.get('translation')

    def set_translation(self, v):
        return self.set({'translation': v})

    translation = attr_property('translation', get_translation, set_translation)

    def makePath(self, ctx):
        # this code used to use translate, but now performs translation as part of bp calculation
        ctx.new_path()
        tx, ty = self.translation[0], self.translation[1]
        # Read the matrix once, instead of four times per point
        [[m00, m01], [m10, m11]] = self.transformMatrix
        bp = [
            [m00 * p[0] + m01 * p[1] + tx, m10 * p[0] + m11 * p[1] + ty]
            for p in self.bezierPoints
        ]
        if isinstance(self, Arc):
            ctx.move_to(tx, ty)
            ctx.line_to(bp[0][0], bp[0][1])
        else:
            ctx.move_to(bp[0][0], bp[0][1])

        for i in range(0, len(bp) // 4):
            i2 = i * 4
            ctx.curve_to(
                bp[i2 + 1][0],
                bp[i2 + 1][1],
                bp[i2 + 2][0],
                bp[i2 + 2][1],
                bp[i2 + 3][0],
                bp[i2 + 3][1],
            )

        ctx.close_path()

    def addxy(self, varName, d):
        super().addxy(varName, d)
        if d == 0:
            return
        varIndex = 0 if varName == 'x' else 1
        self.translation[varIndex] += d
        self.translation = self.translation

    def scalexy(self, varName, k, scaleAnchor=None):
        super().scalexy(varName, k, scaleAnchor)
        if k == 1:
            return
        i = 0 if varName == 'x' else 1

        cxy = (scaleAnchor or self.getScaleAnchor())[i]
        self.translation[i] = cxy + (self.translation[i] - cxy) * k
        self.translation = self.translation

    def doRotate(self, degrees, cx, cy):
        super().doRotate(degrees, cx, cy)
        self.translation = utils.rotatePoint(self.translation, degrees, cx, cy)

    def toString(self):
        args = [self.centerX, self.centerY, self.width, self.height]
        return t('Oval{{args}}', {'args': utils.roundedTupleString(args, 2)})


class Arc(Oval):
    def __init__(self, attrs):
        super().__init__(attrs)
        self.ovalWidth = attrs['width']
        self.ovalHeight = attrs['height']

    def get_ovalWidth(self):
        return self.get('ovalWidth')

    def set_ovalWidth(self, v):
        return self.set({'ovalWidth': v})

    ovalWidth = attr_property('ovalWidth', get_ovalWidth, set_ovalWidth)

    def get_ovalHeight(self):
        return self.get('ovalHeight')

    def set_ovalHeight(self, v):
        return self.set({'ovalHeight': v})

    ovalHeight = attr_property('ovalHeight', get_ovalHeight, set_ovalHeight)

    def doRotate(self, degrees, cx, cy):
        super().doRotate(degrees, cx, cy)

    def scalexy(self, varName, k, scaleAnchor=None):
        super().scalexy(varName, k, scaleAnchor)
        if k == 1 or self.ovalWidth is None or self.ovalHeight is None:
            return

        if self.rotateAngle != 0:
            self.ovalWidth = None
            self.ovalHeight = None
            return

        if varName == 'x':
            self.ovalWidth *= k
        elif varName == 'y':
            self.ovalHeight *= k

    def get_startAngle(self):
        return self.get('startAngle')

    def set_startAngle(self, v):
        self.set({'startAngle': v})
        self.regeneratePoints()
        return v

    startAngle = attr_property('startAngle', get_startAngle, set_startAngle)

    def get_sweepAngle(self):
        return self.get('sweepAngle')

    def set_sweepAngle(self, v):
        self.set({'sweepAngle': v})
        self.regeneratePoints()
        return v

    sweepAngle = attr_property('sweepAngle', get_sweepAngle, set_sweepAngle)

    def get_isMvc(self):
        return self.get('isMvc')

    isMvc = attr_property('isMvc', get_isMvc)

    def regeneratePoints(self):
        self.pointList = utils.getArcPoints(
            0,
            0,
            2,
            2,
            self.startAngle,
            self.sweepAngle,
            (self.width + self.height) / 2,
            self.isMvc,
        )
        for pt in self.pointList:
            newPt = [
                self.transformMatrix[0][0] * pt[0] + self.transformMatrix[0][1] * pt[1],
                self.transformMatrix[1][0] * pt[0] + self.transformMatrix[1][1] * pt[1],
            ]
            pt[0] = newPt[0] + self.translation[0]
            pt[1] = newPt[1] + self.translation[1]
        self.pointList = self.pointList
        self.bezierPoints = Oval.getBezierPoints(
            self.startAngle, self.sweepAngle, self.isMvc
        )

    def getRotateAnchor(self):
        return [self.pointList[0][0], self.pointList[0][1]]

    def get_centerX(self):
        return utils.round2(self.pointList[0][0])

    def set_centerX(self, v):
        self.addx(v - self.centerX)

    centerX = shape_property(get_centerX, set_centerX)

    def get_centerY(self):
        return utils.round2(self.pointList[0][1])

    def set_centerY(self, v):
        self.addy(v - self.centerY)

    centerY = shape_property(get_centerY, set_centerY)

    def toString(self):
        args = [
            self.centerX,
            self.centerY,
            self.ovalWidth,
            self.ovalHeight,
            self.startAngle,
            self.sweepAngle,
        ]
        return t('Arc{{args}}', {'args': utils.roundedTupleString(args, 2)})


class Circle(Oval):
    def __init__(self, attrs):
        attrs['width'] = attrs['height'] = 2 * attrs['radius']
        super().__init__(attrs)
        self._exactRadius = attrs['radius']

    def get_radius(self):
        if self._exactRadius is not None:
            return self._exactRadius
        return (self.get('width') + self.get('height')) / 4

    def set_radius(self, v):
        super().set_width(2 * v)
        super().set_height(2 * v)
        self._exactRadius = v
        return v

    radius = shape_property(get_radius, set_radius)

    def get__exactRadius(self):
        return self.get('_exactRadius')

    def set__exactRadius(self, v):
        return self.set({'_exactRadius': v})

    _exactRadius = attr_property('_exactRadius', get__exactRadius, set__exactRadius)

    def get_width(self):
        return super().get_width()

    def set_width(self, v):
        self._exactRadius = None
        super().set_width(v)
        return v

    width = shape_property(get_width, set_width)

    def get_height(self):
        return super().get_height()

    def set_height(self, v):
        self._exactRadius = None
        super().set_height(v)
        return v

    height = shape_property(get_height, set_height)

    def toString(self):
        args = [self.centerX, self.centerY, self.radius]
        return t('Circle{{attrs}}', {'attrs': utils.roundedTupleString(args, 2)})

    def scalexy(self, varName, k, scaleAnchor=None):
        super().scalexy(varName, k, scaleAnchor)
        if k == 1:
            return
        self._exactRadius = None


objConstructors = {
    'Arc': Arc,
    'Circle': Circle,
    'Gradient': Gradient,
    'Group': Group,
    'CMUImage': CMUImage,
    'Label': Label,
    'Line': Line,
    'Oval': Oval,
    'Polygon': Polygon,
    'Rect': Rect,
    'RegularPolygon': RegularPolygon,
    'RGB': RGB,
    'Star': Star,
}

BACKGROUND_POINTS = [
    [0, 0],
    [400, 0],
    [0, 400],
    [400, 400],
]
BACKGROUND_DUMMY = object()


class Inspector(object):
    def __init__(self, app):
        self.app = app
        self.keyPoints = None
        self.keyPointsToShapes = None
        self.bestX = self.bestY = self.mouseX = self.mouseY = None

    def getKeyPoints(self, shape):
        x0 = shape.left
        y0 = shape.top
        x1 = shape.right
        y1 = shape.bottom

        points = [
            [x0, y0],
            [x0, y1],
            [x1, y0],
            [x1, y1],
        ]

        if isinstance(shape, Arc):
            points = []
            points.append([shape.pointList[0][0], shape.pointList[0][1]])
            points.append([shape.pointList[1][0], shape.pointList[1][1]])
            numPoints = len(shape.pointList)
            points.append(
                [
                    shape.pointList[numPoints - 1][0],
                    shape.pointList[numPoints - 1][1],
                ]
            )
        elif (
            (
                shape.rotateAngle % 360 != 0
                and (isinstance(shape, Oval) or isinstance(shape, Rect))
            )
            or isinstance(shape, Circle)
            or isinstance(shape, Oval)
            or isinstance(shape, Star)
            or isinstance(shape, RegularPolygon)
            or isinstance(shape, Label)
        ):
            points = [[shape.centerX, shape.centerY]]
        elif isinstance(shape, Line):
            points = [
                [shape.x1, shape.y1],
                [shape.x2, shape.y2],
            ]
        elif isinstance(shape, Polygon):
            points = []
            for i in range(len(shape.pointList)):
                points.append([shape.pointList[i][0], shape.pointList[i][1]])

        return list(map(lambda pt: [round(pt[0]), round(pt[1])], points))

    def getKeyPointKey(self, point):
        return '%d-%d' % (point[0], point[1])

    def ensureKeyPointToShapesMap(self):
        if self.keyPointsToShapes is not None:
            return
        self.keyPointsToShapes = dict()
        self.keyPoints = list()

        def addKeyPointTo(shape):
            def addKeyPoint(keyPoint):
                key = self.getKeyPointKey(keyPoint)
                if self.keyPointsToShapes.get(key, None) is None:
                    self.keyPointsToShapes[key] = []
                    self.keyPoints.append(keyPoint)
                self.keyPointsToShapes[key].append(shape)

            return addKeyPoint

        def processShape(shape):
            if shape.isGroup:
                list(map(processShape, shape._shapes))
                return
            if shape.doNotInspect:
                return

            list(map(addKeyPointTo(shape), self.getKeyPoints(shape)))

        processShape(self.app._tlg._shape)
        if self.app.background is not None:
            list(map(addKeyPointTo(BACKGROUND_DUMMY), BACKGROUND_POINTS))

    def getKeyPointExtraShapeInfo(self, kx, ky):
        key = self.getKeyPointKey([kx, ky])
        attrVals = dict()

        def msgsAdd(attr, value):
            if attrVals.get(attr, None) is None:
                attrVals[attr] = set()
            if utils.isNumber(value):
                value = utils.round2(value)
            elif value is True:
                value = t('True')
            elif value is False:
                value = t('False')
            attrVals[attr].add(value)

        if self.keyPointsToShapes.get(key, None) is None:
            return ''

        def pointEqualsKey(pt):
            px = round(pt[0])
            py = round(pt[1])
            return kx == px and ky == py

        def gradientToString(color):
            result = ''
            for value in color.colors:
                if isinstance(value, str):
                    result += value
                    result += ', '
                elif isinstance(value, RGB):
                    result += value._strVal
                    result += ', '
                else:
                    result += value.attrs['strVal']
                    result += ', '
            return result[:-2]

        for shape in self.keyPointsToShapes[key]:
            if shape is BACKGROUND_DUMMY:
                if isinstance(self.app.background, Gradient):
                    msgsAdd(t('background'), gradientToString(self.app.background))
                else:
                    msgsAdd(t('background'), self.app.background)
                continue

            for attr in ['fill', 'border']:
                color = getattr(shape, attr)
                if color is not None:
                    if isinstance(color, Gradient):
                        msgsAdd(t('gradient'), gradientToString(color))
                    else:
                        msgsAdd(t('color'), color)
                elif attr == 'fill' and not isinstance(shape, CMUImage):
                    msgsAdd(t('color'), t('None'))

            def checkAttrDefaults(attrDefaults):
                for attr, defaultVal in attrDefaults:
                    try:
                        val = getattr(shape, attr)
                        if val is not None and val != defaultVal:
                            msgsAdd(attr, val)
                    except Exception:
                        pass

            checkAttrDefaults(
                [
                    ['opacity', 100],
                    ['lineWidth', 2],
                    ['radius', None],
                    ['dashes', False],
                ]
            )
            if isinstance(shape, Label):
                checkAttrDefaults(
                    [
                        ['font', 'Arial'],
                        ['size', 12],
                        ['style', 'normal'],
                        ['bold', False],
                        ['italic', False],
                    ]
                )
            if isinstance(shape, Line):
                checkAttrDefaults([['arrowStart', False], ['arrowEnd', False]])
            if not isinstance(shape, Label) and not isinstance(shape, Line):
                checkAttrDefaults([['borderWidth', 2]])
            if (
                isinstance(shape, Polygon)
                and not isinstance(shape, PolygonWithTransform)
                and not isinstance(shape, Line)
                and not isinstance(shape, Rect)
                and not isinstance(shape, PolygonInCircle)
            ):
                pointNum = 1
                for pt in shape.pointList:
                    if pointEqualsKey(pt):
                        break
                    else:
                        pointNum += 1
                if pointNum <= len(shape.pointList):
                    msgsAdd(t('point number'), str(pointNum))

            if isinstance(shape, Star):
                checkAttrDefaults(
                    [
                        ['roundness', utils.getDefaultRoundness(shape.points)],
                    ]
                )
            if isinstance(shape, Star) or isinstance(shape, RegularPolygon):
                checkAttrDefaults([['points', None]])
            if shape.rotateAngle % 360 != 0:
                msgsAdd('rotateAngle', shape.rotateAngle)
            if isinstance(shape, Arc):
                checkAttrDefaults(
                    [
                        ['sweepAngle', None],
                        ['startAngle', None],
                    ]
                )
                if shape.ovalWidth is not None and shape.ovalHeight is not None:
                    msgsAdd(
                        t('oval size'),
                        '(%d, %d)'
                        % (
                            utils.round2(shape.ovalWidth),
                            utils.round2(shape.ovalHeight),
                        ),
                    )
            if (
                isinstance(shape, Oval)
                and not isinstance(shape, Circle)
                and not isinstance(shape, Arc)
            ) or (shape.rotateAngle % 360 != 0 and isinstance(shape, Rect)):
                pts = shape.getApproxPoints()
                unrotatedPoints = utils.rotatePoints(
                    pts, -shape.rotateAngle, shape.centerX, shape.centerY
                )
                bounds = utils.getBoxDims(unrotatedPoints)
                msgsAdd(
                    t('size'),
                    '(%d, %d)'
                    % (utils.round2(bounds['width']), utils.round2(bounds['height'])),
                )
        msgs = [self.getPointStr(kx, ky)]
        for attr in attrVals:
            for val in attrVals[attr]:
                msgs.append('%s: %s' % (attr, str(val)))
        return '\n'.join(msgs)

    def getPointStr(self, x, y):
        return '(%d, %d)' % (x, y)

    def nearestKeyPoint(self, x, y):
        bestD = 100000000
        bestX = None
        bestY = None
        for pt in self.keyPoints:
            d = (pt[0] - x) ** 2 + (pt[1] - y) ** 2
            if d < bestD:
                bestD = d
                [bestX, bestY] = pt
        return [bestX, bestY]

    def reset(self):
        self.mouseX = self.mouseY = None
        self.clearCache()

    def clearCache(self):
        self.keyPoints = self.keyPointsToShapes = None
        self.bestX = self.bestY = None

    def setMousePosition(self, x, y):
        self.mouseX = x
        self.mouseY = y
        self.bestX = self.bestY = None

    def computeBestPoint(self):
        if self.mouseX is None or self.mouseX is None:
            return
        self.ensureKeyPointToShapesMap()
        bestX, bestY = self.nearestKeyPoint(self.mouseX, self.mouseY)

        if (
            bestX is None
            or utils.distance(self.mouseX, self.mouseY, bestX, bestY) > 300
        ):
            self.bestX = self.bestY = None
        else:
            self.bestX = bestX
            self.bestY = bestY

    def draw(self, ctx):
        self.computeBestPoint()
        if self.bestX is None or self.bestY is None:
            return

        # in the 0-1 range set_source_rgb/set_source_rgba expect
        black = (0, 0, 0)
        red = (1, 0, 0)
        gold = (1, 215 / 255, 0)
        white = (1, 1, 1)

        for pt in self.keyPoints:
            ctx.new_path()
            ctx.arc(pt[0], pt[1], 2, 0, 2 * math.pi)
            ctx.close_path()
            ctx.set_source_rgba(*black)
            ctx.set_line_width(2)
            ctx.stroke_preserve()
            ctx.set_source_rgba(*gold)
            ctx.fill()

        ctx.set_source_rgba(*red)
        for r in [5, 4, 3, 2, 1]:
            ctx.set_source_rgb(*(red if r % 2 == 1 else black))
            ctx.new_path()
            ctx.arc(self.bestX, self.bestY, r, 0, 2 * math.pi)
            ctx.close_path()
            ctx.fill()

        def textWidth(text):
            return ctx.text_extents(text)[2]

        def drawCenteredText(text, x, y):
            x, y = int(x), int(y)
            _, _, width, _, _, _ = ctx.text_extents(text)
            ctx.move_to(x - width / 2, y)
            ctx.show_text(text)

        ctx.select_font_face(*getFont('arial'))
        ctx.set_font_size(12)
        pointLabelText = self.getPointStr(self.bestX, self.bestY)
        w = textWidth(pointLabelText)
        h = 12
        margin = 10
        pointLabelCenterX = min(
            self.app.width - margin - w / 2, max(margin + w / 2, self.bestX - 10)
        )
        pointLabelCenterY = min(
            self.app.height - margin - h / 2, max(margin + h / 2, self.bestY - 10)
        )

        ctx.set_source_rgba(*white, 0.5)
        ctx.rectangle(
            pointLabelCenterX - w / 2 - 2,
            pointLabelCenterY - h / 2 - 2,
            w + 4,
            h + 4,
        )
        ctx.fill()

        ctx.set_source_rgba(*black)
        drawCenteredText(
            pointLabelText,
            pointLabelCenterX,
            pointLabelCenterY + h / 2 - 2,
        )

        minTop = 10
        if pointLabelCenterX > 300 and pointLabelCenterY < 50:
            minTop = pointLabelCenterY + margin
        info = self.getKeyPointExtraShapeInfo(self.bestX, self.bestY)
        infoLines = info.split('\n')
        ctx.set_source_rgba(*white, 0.5)
        infoWidth = 0
        newLines = []
        maxWidth = 300

        def shortenLine(line):
            splitLine = line.split(',')
            return [splitLine.pop(), ''.join(splitLine)]

        for line in infoLines:
            if textWidth(line) < maxWidth:
                newLines.append(line)
            else:
                leftover = ''
                while textWidth(line) > maxWidth:
                    lastWord, line = shortenLine(line)
                    if len(leftover) > 0:
                        leftover = ',' + leftover
                    leftover = lastWord + leftover
                if len(leftover) > 0:
                    line = line + ','
                newLines.append(line, leftover)

        for line in newLines:
            infoWidth = max(infoWidth, textWidth(line))

        lineHeight = 12
        infoHeight = lineHeight * len(newLines)
        ctx.rectangle(
            self.app.width - 2 * margin - infoWidth,
            minTop,
            infoWidth + 2 * margin,
            infoHeight + margin,
        )
        ctx.fill()
        ctx.set_source_rgba(*black)
        verticalOffset = 0
        for line in newLines:
            firstword = line[0 : line.find(':') + 1]
            newline = line[line.find(':') + 1 :]
            ctx.select_font_face(*getFont('arial', isBold=True))
            firstwordWidth = textWidth(firstword)
            ctx.select_font_face(*getFont('arial'))
            newlineWidth = textWidth(newline)
            ctx.select_font_face(*getFont('arial', isBold=True))

            drawCenteredText(
                firstword,
                self.app.width
                - margin
                - infoWidth / 2
                - (newlineWidth + firstwordWidth) / 2
                + firstwordWidth / 2,
                minTop + lineHeight + verticalOffset,
            )

            ctx.select_font_face(*getFont('arial'))
            drawCenteredText(
                newline,
                self.app.width
                - margin
                - infoWidth / 2
                + (newlineWidth + firstwordWidth) / 2
                - newlineWidth / 2,
                minTop + lineHeight + verticalOffset,
            )
            verticalOffset += lineHeight


# In CPCS Mode, redrawAll makes all of the app's shapes again every frame,
# usually with the same arguments as the frame before (think of the cells of a
# grid, or a background). Making a shape from scratch takes a lot of type
# checking and geometry, so remember what each drawing call made, and copy it
# when the same call happens again.
#
# Making a shape only depends on its class, its arguments, and the language,
# so a template is only used for a call with exactly the same ones: the same
# values, of the same types (so 1, 1.0, and True are different), with keyword
# arguments in the same order. Templates are only made for calls whose
# arguments are all numbers, strings, booleans, or None, and only for shapes
# whose state is made of those and lists and dicts of them.
#
# Past MAX_SHAPE_TEMPLATES templates (or keys seen once), the ones that weren't
# used in the previous frame are dropped when the next frame starts. So the
# shapes an app draws every frame always keep their templates, however many
# there are, and templates for shapes it stopped drawing go away.
MAX_SHAPE_TEMPLATES = 4096
# Template keys to templates
SHAPE_TEMPLATES = {}
# Keys of calls seen once, to the frame they were seen in
SEEN_SHAPE_TEMPLATE_KEYS = {}
_shapeTemplateFrame = 0


def startShapeTemplateFrame():
    # Called before each redrawAll
    global _shapeTemplateFrame
    _shapeTemplateFrame += 1
    oldest = _shapeTemplateFrame - 1
    if len(SHAPE_TEMPLATES) > MAX_SHAPE_TEMPLATES:
        for key in [k for k, v in SHAPE_TEMPLATES.items() if v.lastUsed < oldest]:
            del SHAPE_TEMPLATES[key]
    if len(SEEN_SHAPE_TEMPLATE_KEYS) > MAX_SHAPE_TEMPLATES:
        for key in [k for k, v in SEEN_SHAPE_TEMPLATE_KEYS.items() if v < oldest]:
            del SEEN_SHAPE_TEMPLATE_KEYS[key]


_TEMPLATE_IMMUTABLE_TYPES = frozenset((int, float, str, bool, type(None)))


class _NotTemplatable(Exception):
    pass


def _templateKeyParts(values):
    # Each value with its type, so that values that compare equal but behave
    # differently (1, 1.0, and True; 0.0 and -0.0) get different keys. hex()
    # tells apart floats that compare equal.
    parts = []
    for value in values:
        valueType = type(value)
        if valueType is float:
            parts.append(value.hex())
        elif valueType in _TEMPLATE_IMMUTABLE_TYPES:
            parts.append(value)
        else:
            raise _NotTemplatable()
        parts.append(valueType)
    return tuple(parts)


def shapeTemplateKey(clsName, args, kwargs, isMvc):
    # Shape objects (as opposed to drawing functions) are usually made once,
    # so they don't use templates. Images depend on files, and visible changes
    # the group a shape is in, so neither uses templates either.
    if isMvc is not True or clsName == 'Image' or 'visible' in kwargs:
        return None
    font = kwargs.get('font')
    # Setting a font can print a warning (once), which a template would skip
    if type(font) is str and font.lower() in FONTS_SHOW_WARNING:
        return None
    try:
        return (
            clsName,
            cmuGraphicsLanguage,
            _templateKeyParts(args),
            tuple(kwargs),
            _templateKeyParts(kwargs.values()),
        )
    except _NotTemplatable:
        return None


# Parts of a shape's state that instantiate() sets itself
_TEMPLATE_GROUP_FIELDS = frozenset(
    ('id', '_group', 'oldGroup', 'shapesToBeInFrontOf', 'shapesInOldGroup', 'zindex')
)


def _copyShapeState(value, memo):
    valueType = type(value)
    if valueType in _TEMPLATE_IMMUTABLE_TYPES:
        return value
    valueId = id(value)
    if valueId in memo:
        return memo[valueId]
    if valueType is list:
        result = memo[valueId] = []
        for item in value:
            result.append(_copyShapeState(item, memo))
        return result
    if valueType is dict:
        result = memo[valueId] = {}
        for k, v in value.items():
            if type(k) not in _TEMPLATE_IMMUTABLE_TYPES:
                raise _NotTemplatable()
            result[k] = _copyShapeState(v, memo)
        return result
    raise _NotTemplatable()


def _hasSharedContainers(value, seen):
    # Whether any list or dict is reachable twice from value
    valueType = type(value)
    if valueType is list or valueType is dict:
        if id(value) in seen:
            return True
        seen.add(id(value))
        items = value if valueType is list else value.values()
        return any(_hasSharedContainers(item, seen) for item in items)
    return False


def _copyList(value):
    return value[:]


def _copyPointList(value):
    return [point[:] for point in value]


def _makeCopier(value):
    # Returns a function that copies values shaped like value, or None if
    # value is immutable and can be shared
    valueType = type(value)
    if valueType in _TEMPLATE_IMMUTABLE_TYPES:
        return None
    if valueType is list:
        if all(type(item) in _TEMPLATE_IMMUTABLE_TYPES for item in value):
            return _copyList
        if all(
            type(item) is list
            and all(type(x) in _TEMPLATE_IMMUTABLE_TYPES for x in item)
            for item in value
        ):
            return _copyPointList
        return lambda v: _copyShapeState(v, {})
    if valueType is dict:
        mutableItems = [
            (k, copier)
            for k, copier in ((k, _makeCopier(v)) for k, v in value.items())
            if copier is not None
        ]

        def copyDict(v):
            result = v.copy()
            for k, copier in mutableItems:
                result[k] = copier(result[k])
            return result

        return copyDict
    raise _NotTemplatable()


class ShapeTemplate(object):
    def __init__(self, cls, fieldNames, state, copiers):
        self.cls = cls
        # The last frame (see startShapeTemplateFrame) the template was used in
        self.lastUsed = 0
        # The order of the shape's fields, so copies match exactly
        self.fieldNames = fieldNames
        self.state = state
        # None if some list or dict is shared within the state, in which case
        # everything is copied together with _copyShapeState to keep it shared.
        # Otherwise, for each field: None for the fields instantiate() sets
        # itself, or (value, copier), where copier is None if the value is
        # immutable and can be shared.
        if copiers is None:
            self.fields = None
        else:
            self.fields = []
            for name in fieldNames:
                if name in _TEMPLATE_GROUP_FIELDS:
                    self.fields.append((name, None))
                elif name == 'attrDefaults':
                    self.fields.append((name, (shapeAttrDefaults, None)))
                else:
                    self.fields.append((name, (state[name], copiers[name])))

    @staticmethod
    def make(shape):
        fieldNames = list(vars(shape))
        state = {}
        try:
            memo = {}
            for name in fieldNames:
                if name in _TEMPLATE_GROUP_FIELDS:
                    continue
                value = vars(shape)[name]
                if name == 'attrDefaults':
                    # The module wide defaults, which copies share
                    if value is not shapeAttrDefaults:
                        return None
                    continue
                state[name] = _copyShapeState(value, memo)
            if _hasSharedContainers(list(state.values()), set()):
                copiers = None
            else:
                copiers = {name: _makeCopier(value) for name, value in state.items()}
        except _NotTemplatable:
            return None
        return ShapeTemplate(type(shape), fieldNames, state, copiers)

    def instantiate(self):
        # A copy of the template, plus what Shape.__init__ does to every shape
        shape = self.cls.__new__(self.cls)
        fields = shape.__dict__
        if self.fields is not None:
            for name, field in self.fields:
                if field is None:
                    fields[name] = None
                else:
                    value, copier = field
                    fields[name] = value if copier is None else copier(value)
        else:
            memo = {}
            for name in self.fieldNames:
                if name in _TEMPLATE_GROUP_FIELDS:
                    fields[name] = None
                elif name == 'attrDefaults':
                    fields[name] = shapeAttrDefaults
                else:
                    fields[name] = _copyShapeState(self.state[name], memo)
        fields['id'] = activeDrawing.nextShapeId
        activeDrawing.nextShapeId += 1
        fields['_group'] = fields['oldGroup'] = None
        fields['shapesToBeInFrontOf'] = []
        fields['shapesInOldGroup'] = {}
        fields['zindex'] = -1
        if activeDrawing.tlg is not None:
            addToTopLevelGroup(shape)
        return shape


# In CPCS Mode, most shapes are made by a drawing call, drawn once, and thrown
# away, without anything else looking at them. So drawRect, drawOval, and
# drawCircle calls with ordinary arguments make a LazyShape instead of the
# real shape: a stand-in that joins the group like the real shape would (and
# takes its id), and draws itself with exactly the canvas calls the real
# shape's draw() would make. Anything else that looks at it (the inspector,
# app.group, hit testing...) turns it into the real shape first, made by the
# same drawing call, so nothing can tell the difference.
#
# lazyShapePlan checks the arguments and works out what to draw. It returns
# None for anything it doesn't handle exactly like the real shape (including
# any argument the real shape would reject), and the real shape is made as
# usual.

# Attributes that LazyShape answers itself: the ones groups use to keep
# track of their shapes, which it sets up like Shape.__init__ does
_LAZY_FIELDS = frozenset(
    (
        '__dict__',
        '__class__',
        '_lazy',
        'draw',
        'id',
        '_group',
        'oldGroup',
        'shapesToBeInFrontOf',
        'shapesInOldGroup',
        'isGroup',
        'zindex',
    )
)
# Attributes that real shapes that LazyShapes stand in for don't have
_LAZY_MISSING = frozenset(('_shape', '_shapes'))
_setObjectClass = object.__dict__['__class__'].__set__


class LazyShape(Shape):
    def __getattribute__(self, attr):
        if attr in _LAZY_FIELDS:
            return object.__getattribute__(self, attr)
        if attr in _LAZY_MISSING:
            raise AttributeError(attr)
        materializeLazyShape(self)
        # Now a real shape
        return object.__getattribute__(self, attr)

    @property
    def __class__(self):
        # So isinstance(lazyCircle, Circle) is True
        return object.__getattribute__(self, '_lazy')[0]

    def draw(self, ctx):
        fields = object.__getattribute__(self, '__dict__')
        cls, drawFn, drawArgs, makeShape = fields['_lazy']
        drawFn(ctx, *drawArgs)
        fields['_lazyDrawn'] = True


def addLazyShape(plan, makeShape):
    """Adds a LazyShape for a plan from lazyShapePlan to the top level group.
    makeShape() makes the real shape (not added to any group)."""
    cls, drawFn, drawArgs = plan
    shape = LazyShape.__new__(LazyShape)
    # What Shape.__init__ sets, in the same order
    fields = object.__getattribute__(shape, '__dict__')
    fields['_lazy'] = (cls, drawFn, drawArgs, makeShape)
    fields['id'] = activeDrawing.nextShapeId
    activeDrawing.nextShapeId += 1
    fields['_group'] = fields['oldGroup'] = None
    fields['shapesToBeInFrontOf'] = []
    fields['shapesInOldGroup'] = {}
    fields['isGroup'] = False
    fields['zindex'] = -1
    if activeDrawing.tlg is not None:
        tlgShape = _topLevelGroupShape()
        if isinstance(tlgShape, Group):
            tlgShape.addNewShape(shape)
        else:
            activeDrawing.tlg.add(shape)
    return shape


def materializeLazyShape(shape):
    fields = object.__getattribute__(shape, '__dict__')
    makeShape = fields['_lazy'][3]
    real = makeShape()
    if fields.get('_lazyDrawn') and isinstance(real, Label):
        # What Shape.draw does to a Label it draws
        if str(real.value) != real.valueStr:
            real.valueStr = str(real.value)
            real.setDims()
    # The real shape's state, except for its place in the group and its id,
    # which the LazyShape already has
    newFields = {}
    for name, value in vars(real).items():
        if name in _TEMPLATE_GROUP_FIELDS:
            newFields[name] = fields[name]
        else:
            newFields[name] = value
    fields.clear()
    fields.update(newFields)
    _setObjectClass(shape, type(real))
    # The student's version of the shape (if anything asks for it) refers to
    # this shape, which is the one in the group
    studentShape = fields.get('studentShape')
    if studentShape is not None:
        studentShape.__dict__['_shape'] = shape


# Set by cmu_graphics: makeDrawnShape(shape, args, kwargs, language) makes the
# real shape for a drawing call (see cmu_graphics._makeDrawnShape)
makeDrawnShape = None


class TopLevelGroup(Group):
    """The app's group (the one drawing calls add shapes to).

    A CPCS Mode drawing call that a LazyShape can stand in for doesn't make
    the LazyShape right away. It adds a record of the call to _pending (see
    addPendingShape), which is all that drawing and clearing the group need:
    nearly every frame, the group is cleared, the records are drawn, and
    nothing else looks at them. Anything else that looks at the group's
    shapes (through _shapes) first turns the records into the LazyShapes
    they stand for, in order, after the shapes already in the group, as if
    each had been added when its drawing call was made.

    The group's own list of shapes is _ownShapes, which _shapes returns."""

    @property
    def _shapes(self):
        fields = self.__dict__
        if fields['_pending']:
            self._addPendingShapes()
        return fields['_ownShapes']

    @_shapes.setter
    def _shapes(self, value):
        fields = self.__dict__
        if fields.get('_pending'):
            self._addPendingShapes()
        fields['_ownShapes'] = value

    def _addPendingShapes(self):
        fields = self.__dict__
        pending = fields['_pending']
        drawnCount = fields['_pendingDrawn']
        fields['_pending'] = []
        fields['_pendingDrawn'] = 0
        ownShapes = fields['_ownShapes']
        for index, record in enumerate(pending):
            if record[0] is None:
                # A real shape (see addNewShape)
                ownShapes.append(record[1])
                continue
            drawFn, drawArgs, cls, shapeId, makeArgs = record
            shape = LazyShape.__new__(LazyShape)
            # What addLazyShape and then addNewShape set
            shapeFields = object.__getattribute__(shape, '__dict__')
            shapeFields['_lazy'] = (
                cls,
                drawFn,
                drawArgs,
                lambda makeArgs=makeArgs: makeDrawnShape(*makeArgs),
            )
            shapeFields['id'] = shapeId
            shapeFields['_group'] = self
            shapeFields['oldGroup'] = None
            shapeFields['shapesToBeInFrontOf'] = []
            shapeFields['shapesInOldGroup'] = {}
            shapeFields['isGroup'] = False
            shapeFields['zindex'] = -1
            if index < drawnCount:
                shapeFields['_lazyDrawn'] = True
            ownShapes.append(shape)

    def addNewShape(self, shape):
        fields = self.__dict__
        pending = fields['_pending']
        if not pending:
            Group.addNewShape(self, shape)
            return
        # A real shape drawn after records (like a rotated Label in CPCS
        # Mode) goes after them as a record of its own, (None, shape), so
        # the records don't all have to become LazyShapes. Otherwise this
        # is the same as Group.addNewShape.
        _countShapeAdded()
        pending.append((None, shape))
        shape._group = self
        shape.zindex = -1
        shape.oldGroup = None
        shape.shapesToBeInFrontOf = []
        shape.shapesInOldGroup = {}

    def clear(self):
        # Nothing but this group knows about the records, so dropping them is
        # all that clearing would do to the LazyShapes they stand for
        fields = self.__dict__
        fields['_pending'] = []
        fields['_pendingDrawn'] = 0
        Group.clear(self)

    def draw(self, ctx):
        fields = self.__dict__
        pending = fields['_pending']
        if not pending or self.db != '':
            Shape.draw(self, ctx)
            return
        # Shape.draw for a group (without a db), with each record drawn the
        # way its LazyShape would draw itself
        ctx.save()
        for s in fields['_ownShapes']:
            s.draw(ctx)
        drawers = _FAST_DRAWERS if type(ctx) is _CANVAS_TYPE else None
        if drawers:
            get = drawers.get
            for record in pending:
                drawFn = record[0]
                if drawFn is None:
                    record[1].draw(ctx)
                else:
                    get(drawFn, drawFn)(ctx, *record[1])
        else:
            for record in pending:
                if record[0] is None:
                    record[1].draw(ctx)
                else:
                    record[0](ctx, *record[1])
        fields['_pendingDrawn'] = len(pending)
        ctx.restore()


def makeTopLevelGroup(group):
    """Makes a new, empty Group into a TopLevelGroup."""
    fields = group.__dict__
    fields['_ownShapes'] = fields.pop('_shapes')
    fields['_pending'] = []
    fields['_pendingDrawn'] = 0
    _setObjectClass(group, TopLevelGroup)


def addPendingShape(plan, makeArgs):
    """Adds a LazyShape for a plan from lazyShapePlan to the top level group,
    as a record if it's a TopLevelGroup (see TopLevelGroup). makeArgs are
    makeDrawnShape's arguments, for making the real shape."""
    tlg = activeDrawing.tlg
    tlgShape = getattr(tlg, '_shape', tlg)
    if type(tlgShape) is not TopLevelGroup:
        return addLazyShape(plan, lambda: makeDrawnShape(*makeArgs))
    drawing = activeDrawing
    shapeId = drawing.nextShapeId
    drawing.nextShapeId = shapeId + 1
    # _countShapeAdded, with the check every 100 shapes inlined
    count = drawing.addCounter + 1
    drawing.addCounter = count
    if count % 100 == 0:
        drawing.addCounter = count - 1
        _countShapeAdded()
    tlgShape.__dict__['_pending'].append((plan[1], plan[2], plan[0], shapeId, makeArgs))


def _approxOptions(value):
    """The approximate drawing optimizations that CMU_GRAPHICS_APPROX turns
    on: speedups whose output is very close to, but not always exactly the
    same as, the normal drawing. '1' or 'all' turns on all of them, or it can
    name them, separated by commas. A name with a '-' in front turns that one
    off, as in 'all,-text'."""
    options = set()
    for name in value.replace(' ', '').lower().split(','):
        if name in ('1', 'all', 'on', 'true', 'yes'):
            options |= APPROX_OPTIONS
        elif name.startswith('-'):
            options.discard(name[1:])
        elif name in APPROX_OPTIONS:
            options.add(name)
    return frozenset(options)


# The approximate drawing optimizations (see _approxOptions):
#   text:    draw labels from Skia's glyph cache instead of filling their
#            outlines (antialiased a little differently)
#   borders: draw borders of shapes that are drawn the same way again and
#            again from cached coverage masks (rounded a little differently)
#   thread:  record each frame, and draw it on another thread while the
#            program works on the next frame, so frames are shown one frame
#            later than they would be
APPROX_OPTIONS = frozenset(('text', 'borders', 'thread'))
APPROX = _approxOptions(os.environ.get('CMU_GRAPHICS_APPROX', ''))
# (Canvases from before approximate drawing don't have these)
_APPROX_TEXT = 'text' in APPROX and hasattr(wyvern.Canvas, 'draw_text_approx')
_APPROX_BORDERS = 'borders' in APPROX and hasattr(wyvern.Canvas, 'draw_text_approx')
APPROX_THREAD = 'thread' in APPROX and hasattr(wyvern.Canvas, 'begin_frame')


# Faster versions of LazyShape draw functions, by the draw function, for
# drawing on a wyvern Canvas (see TopLevelGroup.draw). Filled in below.
_FAST_DRAWERS = {}
_CANVAS_TYPE = wyvern.Canvas


_LAZY_SHAPE_KWARGS = frozenset(('fill', 'border', 'borderWidth', 'opacity', 'dashes'))
_USE_DEFAULT = object()


_PLAIN_NUMBER_TYPES = (int, float)


def _isPlainNumber(value):
    # Limited to where sizes of at least _MIN_LAZY_SIZE are always more than
    # the spacing between floats, so shapes made with them never end up with
    # a width or height of 0 (which some shapes reject)
    return (type(value) is int or type(value) is float) and -1e9 <= value <= 1e9


_MIN_LAZY_SIZE = 1e-6


def _lazyColor(value):
    # A fill or border that checkColor accepts and the fast path can draw:
    # None, an RGB, or a color name. Returns False otherwise.
    if value is None or type(value) is RGB:
        return True
    if type(value) is str:
        return toEnglish(value, 'color').lower() in CSS3_COLORS_TO_RGB
    return False


def _truncated(value):
    # What shape attribute properties return (see attr_property)
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


# (red / 255, green / 255, blue / 255) of color names, by language and name
_lazyColorNames = {}


def _lazyRgba(color, opacity):
    # Shape.getFillOrStrokeStyle for a color name or an RGB
    if isinstance(color, str):
        byName = _lazyColorNames.get(cmuGraphicsLanguage)
        if byName is None:
            byName = _lazyColorNames[cmuGraphicsLanguage] = {}
        rgb = byName.get(color)
        if rgb is None:
            rgbColor = CSS3_COLORS_TO_RGB[toEnglish(color, 'color').lower()]
            if len(byName) >= 4096:
                byName.clear()
            rgb = byName[color] = (
                rgbColor._red / 255,
                rgbColor._green / 255,
                rgbColor._blue / 255,
            )
        return rgb + (opacity / 100,)
    return (
        color._red / 255,
        color._green / 255,
        color._blue / 255,
        opacity / 100,
    )


class LazyStyle(object):
    """A LazyShape's style keyword arguments: values is (fill, border,
    borderWidth, opacity, dashes), with _USE_DEFAULT for ones not given.
    Styles are shared by every drawing call with the same arguments, and
    remember what they resolve to in each language (see resolved)."""

    __slots__ = ('values', 'byLanguage')

    def __init__(self, values):
        self.values = values
        self.byLanguage = {}

    def resolved(self):
        """(fill, border, borderWidth, opacity, dashes, fill's
        set_source_rgba arguments, border's, closed shape arguments), with
        the values Shape.draw reads (see _lazyStyle). The colors' arguments
        are None for no color. The closed shape arguments are the fill,
        border, border_width, and dashed arguments of
        Canvas.draw_closed_shape for drawing a closed shape the way
        _lazyFillAndBorder does."""
        resolved = self.byLanguage.get(cmuGraphicsLanguage)
        if resolved is None:
            fill, border, borderWidth, opacity, dashes = _lazyStyle(self)
            fillRgba = None if fill is None else _lazyRgba(fill, opacity)
            borderRgba = None if border is None else _lazyRgba(border, opacity)
            bw = borderWidth if border else 0
            resolved = self.byLanguage[cmuGraphicsLanguage] = (
                fill,
                border,
                borderWidth,
                opacity,
                dashes,
                fillRgba,
                borderRgba,
                (
                    fillRgba if fill else None,
                    borderRgba if bw else None,
                    bw * 2 if bw else 0,
                    bool(dashes),
                ),
            )
        return resolved


def _lazyStyle(style):
    """The values Shape.draw reads, as it reads them, from a LazyStyle."""
    fill, border, borderWidth, opacity, dashes = style.values
    if _USE_DEFAULT in style.values:
        defaults = _lazyDefaults.get(cmuGraphicsLanguage)
        if defaults is None:
            defaults = _lazyDefaults[cmuGraphicsLanguage] = tuple(
                translatedDefault(shapeAttrDefaults, name)
                for name in ('fill', 'border', 'borderWidth', 'opacity', 'dashes')
            )
        if fill is _USE_DEFAULT:
            fill = defaults[0]
        if border is _USE_DEFAULT:
            border = defaults[1]
        if borderWidth is _USE_DEFAULT:
            borderWidth = defaults[2]
        if opacity is _USE_DEFAULT:
            opacity = defaults[3]
        if dashes is _USE_DEFAULT:
            dashes = defaults[4]
    return fill, border, _truncated(borderWidth), _truncated(opacity), dashes


# Translated defaults of the style attributes, by language
_lazyDefaults = {}


def _lazyFillAndBorder(ctx, style):
    # The part of Shape.draw after the path is made, for a closed shape with
    # more than 2 points, that isn't an Arc or an Image
    fill, border, borderWidth, opacity, dashes, fillRgba, borderRgba, _ = (
        style.resolved()
    )
    bw = borderWidth if border else 0
    ctx.close_path()
    if fill:
        ctx.set_source_rgba(*fillRgba)
        ctx.fill_preserve()
    if bw:
        bw *= 2
        ctx.clip_preserve()
        ctx.set_source_rgba(*borderRgba)
        ctx.set_dash([5, 5] if dashes else [])
        ctx.set_line_width(bw)
        ctx.stroke()
    ctx.restore()


def _drawLazyFlatPolygon(ctx, coords, style):
    # Shape.draw for a Polygon (utils.makePolygonPath makes the path), with
    # the points' x and y in one flat sequence
    ctx.save()
    ctx.new_path()
    ctx.move_to(coords[-2], coords[-1])
    for i in range(0, len(coords), 2):
        ctx.line_to(coords[i], coords[i + 1])
    _lazyFillAndBorder(ctx, style)


def _drawLazyFlatOval(ctx, coords, style):
    # Shape.draw for an Oval, with the points of Oval.makePath (their x and y
    # in one flat sequence)
    ctx.save()
    ctx.new_path()
    ctx.move_to(coords[0], coords[1])
    for i in range(0, len(coords) // 8):
        i2 = i * 8
        ctx.curve_to(
            coords[i2 + 2],
            coords[i2 + 3],
            coords[i2 + 4],
            coords[i2 + 5],
            coords[i2 + 6],
            coords[i2 + 7],
        )
    ctx.close_path()
    _lazyFillAndBorder(ctx, style)


def _fastDrawLazyFlatPolygon(ctx, coords, style):
    # _drawLazyFlatPolygon with one Canvas call
    fill, border, bw, dashed = style.resolved()[7]
    ctx.draw_closed_shape(0, coords, fill, border, bw, dashed)


def _fastDrawLazyFlatOval(ctx, coords, style):
    # _drawLazyFlatOval with one Canvas call
    fill, border, bw, dashed = style.resolved()[7]
    ctx.draw_closed_shape(1, coords, fill, border, bw, dashed)


def _approxDrawLazyFlatPolygon(ctx, coords, style):
    # _fastDrawLazyFlatPolygon, with approximate drawing's 'borders'
    fill, border, bw, dashed = style.resolved()[7]
    ctx.draw_closed_shape(0, coords, fill, border, bw, dashed, border is not None)


def _approxDrawLazyFlatOval(ctx, coords, style):
    # _fastDrawLazyFlatOval, with approximate drawing's 'borders'
    fill, border, bw, dashed = style.resolved()[7]
    ctx.draw_closed_shape(1, coords, fill, border, bw, dashed, border is not None)


def _drawLazyLine(ctx, x1, y1, x2, y2, lineWidth, style):
    # Shape.draw for a Line without arrows
    ctx.save()
    fill, border, borderWidth, opacity, dashes, fillRgba, borderRgba, _ = (
        style.resolved()
    )
    if fill:
        ctx.new_path()
        ctx.set_source_rgba(*fillRgba)
        ctx.set_dash([5, 5] if dashes else [])
        ctx.set_line_width(lineWidth)
        ctx.move_to(x1, y1)
        ctx.line_to(x2, y2)
        ctx.stroke()
    ctx.restore()


def _lazyKwargsStyle(kwargs):
    """The style for keyword arguments (already translated to English), or
    None if they aren't ones the fast path handles exactly."""
    for name in kwargs:
        if name not in _LAZY_SHAPE_KWARGS:
            return None
    fill = kwargs.get('fill', _USE_DEFAULT)
    border = kwargs.get('border', _USE_DEFAULT)
    borderWidth = kwargs.get('borderWidth', _USE_DEFAULT)
    opacity = kwargs.get('opacity', _USE_DEFAULT)
    dashes = kwargs.get('dashes', _USE_DEFAULT)
    if fill is not _USE_DEFAULT and not _lazyColor(fill):
        return None
    if border is not _USE_DEFAULT and not _lazyColor(border):
        return None
    if borderWidth is not _USE_DEFAULT and not (
        _isPlainNumber(borderWidth) and borderWidth >= 0
    ):
        return None
    if opacity is not _USE_DEFAULT and not (
        _isPlainNumber(opacity) and 0 <= opacity <= 100
    ):
        return None
    if dashes is not _USE_DEFAULT and type(dashes) is not bool:
        return None
    return LazyStyle((fill, border, borderWidth, opacity, dashes))


def lazyShapeStyle(kwargs):
    """The style for a LazyShape made with these keyword arguments (with
    English names), or None if they need a real shape. Only depends on the
    arguments and the language."""
    return _lazyKwargsStyle(kwargs)


def _lazyAlignedPoints(pointList, x, y, align):
    """Moves pointList (in place) the way Shape.doAlign(x, y, align) moves a
    Polygon's points: through Polygon's left, right, and centerX (and top,
    bottom, and centerY) properties, with its centerX and centerY attributes
    kept up to date as setDims would. (See _lazyAlignedRect.)"""
    box = utils.getBoxDims(pointList)
    center = [box['left'] + box['width'] / 2, box['top'] + box['height'] / 2]

    def move(varIndex, d):
        # Polygon.addxy, then setDims (through the pointList setter)
        if d == 0:
            return
        for point in pointList:
            point[varIndex] += d
        box = utils.getBoxDims(pointList)
        center[0] = box['left'] + box['width'] / 2
        center[1] = box['top'] + box['height'] / 2

    # Reading the properties truncates integer floats (see shape_property)
    for varIndex, (attr, v) in enumerate(zip(getAlignAttrs(align), (x, y))):
        values = [point[varIndex] for point in pointList]
        if attr in ('left', 'top'):
            move(varIndex, v - _truncated(utils.min_or_inf(values)))
        elif attr in ('right', 'bottom'):
            move(varIndex, v - _truncated(max(values)))
        else:
            move(varIndex, v - _truncated(center[varIndex]))
            center[varIndex] = v


def _lazyRotatedMatrix(matrix, degrees):
    """PolygonWithTransform.doRotate's change to transformMatrix (multMat)."""
    cos = utils.intCos(-degrees)
    sin = utils.intSin(-degrees)
    trans = [[cos, sin], [-sin, cos]]
    newTrans = [[0, 0], [0, 0]]
    for i in range(2):
        for j in range(2):
            for k in range(2):
                newTrans[i][j] += matrix[k][j] * trans[i][k]
    return newTrans


def _drawLazyImage(ctx, url, pointList, matrix, opacity):
    # Shape.draw for an Image (with no fill or border, and not resized), with
    # CMUImage.drawImage
    if opacity is _USE_DEFAULT:
        opacity = translatedDefault(shapeAttrDefaults, 'opacity')
    opacity = _truncated(opacity)
    ctx.save()
    ctx.new_path()
    lastPt = pointList[-1]
    ctx.move_to(lastPt[0], lastPt[1])
    for pt in pointList:
        ctx.line_to(pt[0], pt[1])
    ctx.close_path()
    src = activeDrawing.images[hashReference(url)]
    x, y = pointList[0][0], pointList[0][1]
    mat = matrix
    if mat[0][1] == 0 and mat[1][0] == 0 and mat[0][0] > 0 and mat[1][1] > 0:
        # Not resized, so drawImage draws the image itself
        ctx.translate(x, y)
        ctx.draw_image(src, 0, 0, opacity / 100)
    else:
        ctx.translate(x, y)
        ctx.transform(mat[0][0], mat[1][0], mat[0][1], mat[1][1], 0, 0)
        ctx.draw_image(src, 0, 0, opacity / 100)
    ctx.restore()


def _lazyImagePlan(args, style, rotateAngle, align):
    if len(args) != 3:
        return None
    url, left, top = args
    fill, border, borderWidth, opacity, dashes = style.values
    if not (
        fill is _USE_DEFAULT
        and border is _USE_DEFAULT
        and borderWidth is _USE_DEFAULT
        and dashes is _USE_DEFAULT
    ):
        return None
    if not (
        (type(url) is str or type(url) is PILWrapper)
        and _isPlainNumber(left)
        and _isPlainNumber(top)
    ):
        return None
    try:
        # Loads the image like CMUImage.__init__ does (it's cached after the
        # first time). For a bad url, the real shape raises the error.
        size = loadImage(url)
    except Exception:
        return None
    # CMUImage.__init__'s points and transform
    right = left + size['width']
    bottom = top + size['height']
    pointList = [[left, top], [right, top], [right, bottom], [left, bottom]]
    matrix = [[1, 0], [0, 1]]
    if rotateAngle is not _USE_DEFAULT:
        degrees = rotateAngle - 0
        pointList = _lazyRotatedPoints(pointList, degrees)
        matrix = _lazyRotatedMatrix(matrix, degrees)
    if align is not _USE_DEFAULT:
        _lazyAlignedPoints(pointList, left, top, align)
    for value in (coord for point in pointList for coord in point):
        if not _isPlainNumber(value):
            return None
    return (CMUImage, _drawLazyImage, (url, pointList, matrix, opacity))


def _lazyLabelDims(centerX, centerY, stringValue, extents):
    """Label.setDims for an unrotated label: (approxPoints, xAdjust, width,
    height)."""
    xBearing, yBearing, width, height, xAdvance, yAdvance = extents
    height = -yBearing
    unrotatedWidth = width
    hasOuterSpaces = len(stringValue) > 0 and (
        stringValue[0] == ' ' or stringValue[-1] == ' '
    )
    if hasOuterSpaces:
        unrotatedWidth = max(unrotatedWidth, xAdvance)
    unrotatedHeight = height
    x0 = centerX - unrotatedWidth / 2
    y0 = centerY - unrotatedHeight / 2
    x1 = centerX + unrotatedWidth / 2
    y1 = centerY + unrotatedHeight / 2
    pts = [
        [x0, y0],
        [(x0 + x1) / 2, y0],
        [x1, y0],
        [x1, (y0 + y1) / 2],
        [x1, y1],
        [(x0 + x1) / 2, y1],
        [x0, y1],
        [x0, (y0 + y1) / 2],
    ]
    box = utils.getBoxDims(pts)
    return pts, 0 if hasOuterSpaces else xBearing, box['width'], box['height']


def _drawLazyLabel(ctx, text, font, size, bold, italic, target, xAdjust, style):
    # Shape.draw for an unrotated Label (whose dimensions setDims has already
    # worked out)
    ctx.save()
    fill, border, borderWidth, opacity, dashes, fillRgba, borderRgba, _ = (
        style.resolved()
    )
    if font is _USE_DEFAULT:
        font = translatedDefault(shapeAttrDefaults, 'font')
    bw = borderWidth if border else 0
    targetX, targetY = target
    ctx.select_font_face(*getFont(font, bold, italic))
    ctx.set_font_size(size)
    ctx.new_path()
    ctx.move_to(targetX - xAdjust, targetY)
    ctx.text_path(text)
    # getFillOrStrokeStyle draws a fill of None as black
    ctx.set_source_rgba(*((0, 0, 0, 1) if fill is None else fillRgba))
    ctx.fill_preserve()
    if bw:
        ctx.set_source_rgba(*borderRgba)
        ctx.set_line_width(bw)
        ctx.stroke()
    ctx.restore()


def _fastDrawLazyLabel(ctx, text, font, size, bold, italic, target, xAdjust, style):
    # _drawLazyLabel with one Canvas call
    resolved = style.resolved()
    fill, border, borderWidth = resolved[0], resolved[1], resolved[2]
    if font is _USE_DEFAULT:
        font = translatedDefault(shapeAttrDefaults, 'font')
    bw = borderWidth if border else 0
    family, weight, slant = getFont(font, bold, italic)
    if not bw and _APPROX_TEXT:
        ctx.draw_text_approx(
            text,
            target[0] - xAdjust,
            target[1],
            family,
            weight,
            slant,
            size,
            (0, 0, 0, 1) if fill is None else resolved[5],
        )
        return
    ctx.draw_text(
        text,
        target[0] - xAdjust,
        target[1],
        family,
        weight,
        slant,
        size,
        # getFillOrStrokeStyle draws a fill of None as black
        (0, 0, 0, 1) if fill is None else resolved[5],
        resolved[6] if bw else None,
        bw,
    )


if hasattr(wyvern.Canvas, 'draw_closed_shape') and hasattr(wyvern.Canvas, 'draw_text'):
    if _APPROX_BORDERS:
        _FAST_DRAWERS[_drawLazyFlatPolygon] = _approxDrawLazyFlatPolygon
        _FAST_DRAWERS[_drawLazyFlatOval] = _approxDrawLazyFlatOval
    else:
        _FAST_DRAWERS[_drawLazyFlatPolygon] = _fastDrawLazyFlatPolygon
        _FAST_DRAWERS[_drawLazyFlatOval] = _fastDrawLazyFlatOval


_LAZY_LABEL_VALUE_TYPES = frozenset((str, int, float, bool, type(None)))


# Label plans by their arguments (see _lazyLabelPlan)
_lazyLabelPlans = {}
_LABEL_KEY_TYPES = frozenset((str, int, float, bool, type(None)))


def _lazyLabelPlan(args, style, geometry):
    """Labels are slow to plan (measuring the text, then working out where
    it goes), and usually drawn with the same arguments frame after frame,
    so their plans are remembered. A plan only depends on the arguments, the
    style, the geometry keyword arguments (with their types, since 1, 1.0,
    and True are equal but can make different plans) and the language. Calls
    with an argument equal to 0 aren't remembered, since 0.0 and -0.0 are
    equal (and have the same type) but can make plans with different
    points."""
    if len(args) != 3 or 'rotateAngle' in geometry:
        return None
    key = None
    argTypes = tuple(map(type, args))
    geometryTypes = tuple(map(type, geometry.values()))
    # Only keyed by values that hashing and comparing can't run student code
    # for (anything else can't be planned anyway)
    if _LABEL_KEY_TYPES.issuperset(argTypes) and _LABEL_KEY_TYPES.issuperset(
        geometryTypes
    ):
        key = (
            args,
            argTypes,
            style,
            tuple(geometry.items()),
            geometryTypes,
            cmuGraphicsLanguage,
        )
        plan = _lazyLabelPlans.get(key)
        if plan is not None:
            return plan
    plan = _makeLazyLabelPlan(args, style, geometry)
    if plan is not None and key is not None and 0 not in args:
        if len(_lazyLabelPlans) >= 1024:
            _lazyLabelPlans.clear()
        _lazyLabelPlans[key] = plan
    return plan


def _makeLazyLabelPlan(args, style, geometry):
    value, centerX, centerY = args
    if not (
        type(value) in _LAZY_LABEL_VALUE_TYPES
        and _isPlainNumber(centerX)
        and _isPlainNumber(centerY)
    ):
        return None
    dashes = style.values[4]
    if dashes is not _USE_DEFAULT:
        return None
    font = geometry.get('font', _USE_DEFAULT)
    size = geometry.get('size', _USE_DEFAULT)
    bold = geometry.get('bold', _USE_DEFAULT)
    italic = geometry.get('italic', _USE_DEFAULT)
    if font is not _USE_DEFAULT:
        # Setting a font can print a warning (once), which a LazyShape would skip
        if type(font) is not str or font.lower() in FONTS_SHOW_WARNING:
            return None
    if size is not _USE_DEFAULT and not (_isPlainNumber(size) and size >= 0):
        return None
    for flag in (bold, italic):
        if flag is not _USE_DEFAULT and type(flag) is not bool:
            return None
    # The values the Label's properties have
    fontValue = (
        translatedDefault(shapeAttrDefaults, 'font') if font is _USE_DEFAULT else font
    )
    size = _truncated(
        translatedDefault(shapeAttrDefaults, 'size') if size is _USE_DEFAULT else size
    )
    bold = (
        translatedDefault(shapeAttrDefaults, 'bold') if bold is _USE_DEFAULT else bold
    )
    italic = (
        translatedDefault(shapeAttrDefaults, 'italic')
        if italic is _USE_DEFAULT
        else italic
    )
    stringValue = str(_truncated(value))
    fontCtx.select_font_face(*getFont(fontValue, bold, italic))
    fontCtx.set_font_size(size)
    extents = fontCtx.text_extents(stringValue)
    pts, xAdjust, width, height = _lazyLabelDims(centerX, centerY, stringValue, extents)

    align = geometry.get('align', _USE_DEFAULT)
    if align is not _USE_DEFAULT:
        # doAlign(centerX, centerY, align), through Shape's left, right, top,
        # and bottom properties and Label's centerX and centerY setters (which
        # call setDims). Properties truncate integer floats.
        x, y = centerX, centerY
        xattr, yattr = getAlignAttrs(align)
        if xattr == 'left':
            d = x - _truncated(_truncated(centerX) - _truncated(width) / 2)
            if d != 0:
                centerX = _truncated(centerX) + d
                pts, xAdjust, width, height = _lazyLabelDims(
                    centerX, centerY, stringValue, extents
                )
        else:
            centerX = x - _truncated(width) / 2 if xattr == 'right' else x
            pts, xAdjust, width, height = _lazyLabelDims(
                centerX, centerY, stringValue, extents
            )
        if yattr == 'top':
            centerY = y + _truncated(height) / 2
        elif yattr == 'bottom':
            centerY = y - _truncated(height) / 2
        else:
            centerY = y
        pts, xAdjust, width, height = _lazyLabelDims(
            centerX, centerY, stringValue, extents
        )
    return (
        Label,
        _drawLazyLabel,
        (stringValue, font, size, bold, italic, pts[6], xAdjust, style),
    )


if _FAST_DRAWERS:
    _FAST_DRAWERS[_drawLazyLabel] = _fastDrawLazyLabel


def _lazyAlignedRect(left, top, right, bottom, x, y, align):
    """Where Shape.doAlign(x, y, align) moves a Rect's points, [[left, top],
    [right, top], [right, bottom], [left, bottom]], with left < right and
    top < bottom (see _isPositiveSize). Returns the new (left, top, right,
    bottom).

    doAlign sets the Rect's left, right, or centerX property (then top,
    bottom, or centerY), which moves all of its points by the difference
    (Polygon.addxy), then updates its centerX and centerY attributes from
    their bounding box (setDims). The bounding box getBoxDims finds for a
    Rect's points is left, top, right - left, and bottom - top. Setting
    centerX also sets the centerX attribute itself."""
    edges = [left, right, top, bottom]  # low x, high x, low y, high y
    center = [left + (right - left) / 2, top + (bottom - top) / 2]
    for varIndex, (attr, v) in enumerate(zip(getAlignAttrs(align), (x, y))):
        low, high = edges[2 * varIndex], edges[2 * varIndex + 1]
        if attr in ('left', 'top'):
            d = v - _truncated(low)
        elif attr in ('right', 'bottom'):
            d = v - _truncated(high)
        else:
            d = v - _truncated(center[varIndex])
        if d != 0:
            # Polygon.addxy, then setDims
            edges[2 * varIndex] = low + d
            edges[2 * varIndex + 1] = high + d
            center[0] = edges[0] + (edges[1] - edges[0]) / 2
            center[1] = edges[2] + (edges[3] - edges[2]) / 2
        if attr not in ('left', 'top', 'right', 'bottom'):
            center[varIndex] = v
    return edges[0], edges[2], edges[1], edges[3]


def _lazyRotatedPoints(pointList, degrees):
    """The points after Shape._rotate(degrees) for a Polygon with these
    points and no rotation yet: around its centroid, rounded by round6."""
    cx, cy = utils.getPolygonCentroid(pointList)
    return utils.rotatePoints(pointList, degrees, utils.round6(cx), utils.round6(cy))


def _isPositiveSize(value):
    return _isPlainNumber(value) and value >= _MIN_LAZY_SIZE


def lazyShapePlan(clsName, args, style, geometry):
    """For a drawing call a LazyShape can stand in for, returns
    (shape class, draw function, draw arguments). Otherwise None.

    style comes from lazyShapeStyle. geometry has the call's rotateAngle and
    align keyword arguments (with English names), if it had any."""
    if not geometry:
        # The most common calls, with the checks inlined
        if clsName == 'Rect' and len(args) == 4:
            left, top, width, height = args
            if (
                type(left) in _PLAIN_NUMBER_TYPES
                and type(top) in _PLAIN_NUMBER_TYPES
                and type(width) in _PLAIN_NUMBER_TYPES
                and type(height) in _PLAIN_NUMBER_TYPES
                and -1e9 <= left <= 1e9
                and -1e9 <= top <= 1e9
                and _MIN_LAZY_SIZE <= width <= 1e9
                and _MIN_LAZY_SIZE <= height <= 1e9
            ):
                right = left + width
                bottom = top + height
                # Rect.__init__'s points
                coords = (left, top, right, top, right, bottom, left, bottom)
                return (Rect, _drawLazyFlatPolygon, (coords, style))
            if clsName == 'Polygon':
                return _lazyPolygonPlan(args, style, _USE_DEFAULT)
            return None
        rotateAngle = align = _USE_DEFAULT
    else:
        rotateAngle = geometry.get('rotateAngle', _USE_DEFAULT)
        align = geometry.get('align', _USE_DEFAULT)
        if rotateAngle is not _USE_DEFAULT and not _isPlainNumber(rotateAngle):
            return None
        if align is not _USE_DEFAULT:
            if type(align) is not str:
                return None
            align = toEnglish(align, 'align')
            if align not in aligns:
                return None

    if clsName == 'Image':
        return _lazyImagePlan(args, style, rotateAngle, align)
    if clsName == 'Label':
        if align is not _USE_DEFAULT:
            geometry = dict(geometry, align=align)
        return _lazyLabelPlan(args, style, geometry)

    if clsName == 'Rect':
        if len(args) != 4 or rotateAngle is not _USE_DEFAULT:
            return None
        left, top, width, height = args
        if not (
            _isPlainNumber(left)
            and _isPlainNumber(top)
            and _isPositiveSize(width)
            and _isPositiveSize(height)
        ):
            return None
        # Rect.__init__'s points
        right = left + width
        bottom = top + height
        if align is not _USE_DEFAULT:
            left, top, right, bottom = _lazyAlignedRect(
                left, top, right, bottom, args[0], args[1], align
            )
        coords = (left, top, right, top, right, bottom, left, bottom)
        return (Rect, _drawLazyFlatPolygon, (coords, style))

    if clsName in ('Circle', 'Oval'):
        if rotateAngle is not _USE_DEFAULT or align is not _USE_DEFAULT:
            return None
        if clsName == 'Circle':
            if len(args) != 3:
                return None
            centerX, centerY, radius = args
            if not (
                _isPlainNumber(centerX)
                and _isPlainNumber(centerY)
                and _isPositiveSize(radius)
            ):
                return None
            # Circle.__init__
            width = height = 2 * radius
            cls = Circle
        else:
            if len(args) != 4:
                return None
            centerX, centerY, width, height = args
            if not (
                _isPlainNumber(centerX)
                and _isPlainNumber(centerY)
                and _isPositiveSize(width)
                and _isPositiveSize(height)
            ):
                return None
            cls = Oval
        # Oval.__init__'s transform, and Oval.makePath's points
        m00, m01, m10, m11 = width / 2, 0, 0, height / 2
        coords = []
        for px, py in Oval.sharedBezierPoints(0, 360, True):
            coords.append(m00 * px + m01 * py + centerX)
            coords.append(m10 * px + m11 * py + centerY)
        return (cls, _drawLazyFlatOval, (coords, style))

    if clsName == 'Line':
        lineWidth = geometry.get('lineWidth', _USE_DEFAULT)
        if (
            len(args) != 4
            or rotateAngle is not _USE_DEFAULT
            or align is not _USE_DEFAULT
            or geometry.get('arrowStart', False) is not False
            or geometry.get('arrowEnd', False) is not False
            or (lineWidth is not _USE_DEFAULT and not _isPositiveSize(lineWidth))
        ):
            return None
        x1, y1, x2, y2 = args
        if not (
            _isPlainNumber(x1)
            and _isPlainNumber(y1)
            and _isPlainNumber(x2)
            and _isPlainNumber(y2)
        ):
            return None
        # Line's x1, y1, x2, and y2 properties return the arguments (from
        # exactValues), truncated. Its lineWidth property is the distance
        # across the points around the line, which Line.__init__ makes 2
        # wide, and setting lineWidth remakes from the properties.
        x1, y1, x2, y2 = (_truncated(v) for v in args)
        if lineWidth is _USE_DEFAULT:
            pts = utils.getLinePoints(args[0], args[1], args[2], args[3], 2)
        else:
            pts = utils.getLinePoints(x1, y1, x2, y2, lineWidth)
        width = _truncated(utils.distance(pts[0][0], pts[0][1], pts[3][0], pts[3][1]))
        return (Line, _drawLazyLine, (x1, y1, x2, y2, width, style))

    if align is not _USE_DEFAULT:
        return None
    if clsName in ('RegularPolygon', 'Star'):
        if len(args) != 4:
            return None
        centerX, centerY, radius, points = args
        if not (
            _isPlainNumber(centerX)
            and _isPlainNumber(centerY)
            and _isPositiveSize(radius)
            and type(points) is int
            and points >= 3
        ):
            return None
        if clsName == 'RegularPolygon':
            pts = utils.getRegularPolygonPoints(centerX, centerY, radius, points, 0)
            cls = RegularPolygon
        else:
            pts = utils.getStarPoints(centerX, centerY, radius, points, None, 0)
            cls = Star
    elif clsName == 'Polygon':
        return _lazyPolygonPlan(args, style, rotateAngle)
    else:
        return None
    if rotateAngle is not _USE_DEFAULT:
        # Setting rotateAngle rotates the points from 0 (even to 0)
        pts = _lazyRotatedPoints(pts, rotateAngle - 0)
    return (cls, _drawLazyFlatPolygon, ([v for pt in pts for v in pt], style))


_PLAIN_NUMBER_TYPE_SET = frozenset(_PLAIN_NUMBER_TYPES)


def _pyPlainNumbers(values):
    """Whether every value in the tuple _isPlainNumber: all ints and floats,
    none less than -1e9 or more than 1e9, and no NaN (which min and max can
    skip, but which makes the sum NaN; the sum of numbers in that range can't
    overflow)."""
    if not (
        _PLAIN_NUMBER_TYPE_SET.issuperset(map(type, values))
        and (not values or (-1e9 <= min(values) and max(values) <= 1e9))
    ):
        return False
    total = sum(values)
    return total == total


# wyvern.plain_numbers is the same check, in one call
_plainNumbers = getattr(wyvern, 'plain_numbers', _pyPlainNumbers)


def _lazyRectPlan(args, style):
    # lazyShapePlan for a Rect without geometry keyword arguments
    if len(args) != 4 or not _plainNumbers(args):
        return None
    left, top, width, height = args
    if not (width >= _MIN_LAZY_SIZE and height >= _MIN_LAZY_SIZE):
        return None
    right = left + width
    bottom = top + height
    # Rect.__init__'s points
    coords = (left, top, right, top, right, bottom, left, bottom)
    return (Rect, _drawLazyFlatPolygon, (coords, style))


def lazyPlanner(clsName):
    """A function (args, style) that does lazyShapePlan(clsName, args,
    style, {}), for drawing calls without geometry keyword arguments."""
    if clsName == 'Rect':
        return _lazyRectPlan
    if clsName == 'Polygon':
        return lambda args, style: _lazyPolygonPlan(args, style, _USE_DEFAULT)
    return lambda args, style: lazyShapePlan(clsName, args, style, {})


def _lazyPolygonPlan(args, style, rotateAngle):
    # drawPolygon's arguments are the points' coordinates
    if len(args) < 6 or len(args) % 2 != 0:
        return None
    if not _plainNumbers(args):
        return None
    if rotateAngle is _USE_DEFAULT:
        return (Polygon, _drawLazyFlatPolygon, (args, style))
    pts = [[args[i], args[i + 1]] for i in range(0, len(args), 2)]
    # Setting rotateAngle rotates the points from 0 (even to 0)
    pts = _lazyRotatedPoints(pts, rotateAngle - 0)
    return (Polygon, _drawLazyFlatPolygon, ([v for pt in pts for v in pt], style))


class ShapeLogicInterface(object):
    def toEnglish(self, *args, **kwargs):
        return toEnglish(*args, **kwargs)

    def accentCombinations(self, *args, **kwargs):
        return accentCombinations(*args, **kwargs)

    def t(self, *args, **kwargs):
        return t(*args, **kwargs)

    def setLanguage(self, language):
        global cmuGraphicsLanguage
        if language in supportedLanguages:
            cmuGraphicsLanguage = language

    def rgb(self, r, g, b):
        return RGB(r, g, b)

    def gradient(self, *colors, start=None, **kwargs):
        for keyword in kwargs:
            if toEnglish(keyword, 'shape-attr') == 'start':
                start = kwargs[keyword]
            else:
                raise Exception(
                    "TypeError: %s() got an unexpected keyword argument '%s'"
                    % (t('gradient'), keyword)
                )

        return Gradient(list(colors), 'center' if start is None else start)

    def slNew(self, className, args):
        return (objConstructors[className])(args)

    def slApply(self, slObj, method, args, kwargs):
        args = list(args)
        # 1. replace student shapes with sl shapes
        for i in range(len(args)):
            if hasattr(args[i], '_shape'):
                args[i] = args[i]._shape
        # 2. make the call
        result = (getattr(slObj, method))(*args, **kwargs)
        # 3. replace sl shapes with student shapes and return
        if isinstance(result, Shape):
            if hasattr(result, 'studentShape'):
                utils.internalError('Need to wrap new sl shape in student shape')
            result = result.studentShape
        return result

    def slGet(self, slObj, attr):
        if not hasattr(slObj, attr):
            pyThrow(t('No such attribute: {{attr}}', {'attr': attr}))
        result = getattr(slObj, attr)
        if callable(result):

            def result(*args, **kwargs):
                return self.slApply(slObj, attr, args, kwargs)
        elif hasattr(result, 'studentShape'):
            result = result.studentShape

        # This matches the behavior of deepcopy() in the JS implementation.
        # JSON.stringify(Infinity) returns 'null'
        # And is needed to return None for an empty polygon's left, right, etc
        if result == math.inf:
            result = None

        return result

    def slSetWithTypeCheck(self, obj, attr, val):
        className = obj.__class__.__name__
        if shapeAttrs.get(attr, None) is not None:
            shapeAttrs[attr].typeCheckFn(obj, attr, val, False)
            setattr(obj, attr, val)
        elif hasattr(obj, attr) and callable(getattr(obj, attr)):
            pyThrow(
                t(
                    "{{methodName}} is a function. You can't assign to it.",
                    {
                        'methodName': f'{className}.{attr}',
                    },
                )
            )
        else:
            utils.internalError(f'No type check function found for {className}.{attr}')
        return val

    def slSetAppProperty(app, propName, value):
        if propName == 'maxShapeCount':
            checkNonNegative(t('app'), propName, value, False)
        elif propName == 'beatsPerMinute':
            checkNumber(t('app'), propName, value, False)
        elif propName == 'background':
            checkColor(t('app'), propName, value, False)
        activeDrawing.appProperties[propName] = value

    def slGetAppProperty(app, propName):
        return activeDrawing.appProperties[propName]

    def slInitShape(self, clsName, argNames, args, kwargs, isMvc):
        key = shapeTemplateKey(clsName, args, kwargs, isMvc)
        if key is None:
            return self._slInitShape(clsName, argNames, args, kwargs, isMvc)

        template = SHAPE_TEMPLATES.get(key)
        if template is not None:
            template.lastUsed = _shapeTemplateFrame
            return template.instantiate()

        idBefore = activeDrawing.nextShapeId
        addsBefore = activeDrawing.addCounter
        shape = self._slInitShape(clsName, argNames, args, kwargs, isMvc)
        # Only remember shapes the second time they're drawn, so shapes that
        # move every frame don't pay to make templates. Making the shape must
        # have had no side effects other than taking an id and joining the top
        # level group, which instantiate() repeats.
        if key in SEEN_SHAPE_TEMPLATE_KEYS:
            if (
                activeDrawing.nextShapeId == idBefore + 1
                and activeDrawing.addCounter == addsBefore + 1
                and shape.id == idBefore
                and shape._group is _topLevelGroupShape()
            ):
                template = ShapeTemplate.make(shape)
                if template is not None:
                    template.lastUsed = _shapeTemplateFrame
                    SHAPE_TEMPLATES[key] = template
        else:
            SEEN_SHAPE_TEMPLATE_KEYS[key] = _shapeTemplateFrame
        return shape

    def _slInitShape(self, clsName, argNames, args, kwargs, isMvc):
        actualClass = clsName
        if clsName == 'Image':
            actualClass = 'CMUImage'
        checkArgCount(clsName, None, argNames, args)
        for attr in kwargs:
            if shapeAttrs.get(attr, None) is None:
                pyThrow(
                    t(
                        '"{{attr}}" is not a valid shape constructor argument',
                        {'attr': attr},
                    )
                )
        if kwargs.get('align', None) is not None and actualClass == 'Polygon':
            pyThrow(
                t(
                    '"{{align}}" is not a valid Polygon constructor argument',
                    {'align': t('align')},
                )
            )
        constructorArgs = dict()
        for i in range(0, len(argNames)):
            attr = argNames[i]
            shapeAttrs[attr].typeCheckFn(clsName, attr, args[i], False)
            constructorArgs[argNames[i]] = args[i]
        constructorArgs['isMvc'] = isMvc
        shape = self.slNew(actualClass, constructorArgs)
        try:
            align = None
            if 'align' in kwargs:
                align = kwargs['align']
                del kwargs['align']
            for attr in kwargs:
                self.slSetWithTypeCheck(shape, attr, kwargs[attr])
            if align is not None:
                checkAlign(shape, t('align'), align, False)
                xPoint = (
                    constructorArgs.get('left', None)
                    if constructorArgs.get('centerX', None) is None
                    else constructorArgs['centerX']
                )
                yPoint = (
                    constructorArgs.get('top', None)
                    if constructorArgs.get('centerY', None) is None
                    else constructorArgs['centerY']
                )
                shape.doAlign(xPoint, yPoint, align)
        except Exception as e:
            activeDrawing.tlg.remove(shape)
            raise e
        return shape

    def setTopLevelGroup(self, tlg):
        activeDrawing.tlg = tlg
